"""One stylesheet for the app. Local fonts; native Material icons remain untouched."""
import base64
from functools import lru_cache
from pathlib import Path

@lru_cache(maxsize=1)
def font_faces():
    assets=Path(__file__).resolve().parents[1]/'assets'
    faces=[]
    for file,family,weight in [('UI-Regular.ttf','CreditCheck UI',400),('UI-Bold.ttf','CreditCheck UI',700),('Display-Regular.ttf','CreditCheck Display',400)]:
        encoded=base64.b64encode((assets/file).read_bytes()).decode()
        faces.append('@font-face{font-family:"'+family+'";src:url(data:font/ttf;base64,'+encoded+') format("truetype");font-weight:'+str(weight)+';font-style:normal;font-display:swap;}')
    return ''.join(faces)

CSS = r'''
:root{--cc-ink:#102A43;--cc-copy:#42576B;--cc-muted:#5C7082;--cc-gold:#916A20;--cc-teal:#067981;--cc-border:#DCE5ED;--cc-ui:"CreditCheck UI","Segoe UI",Arial,sans-serif;--cc-display:"CreditCheck Display",Georgia,serif;}
.stApp,[data-testid="stAppViewContainer"]{background:radial-gradient(ellipse at 0% 0%,#F5EBD7 0,transparent 38%),radial-gradient(ellipse at 100% 12%,#DFEFEC 0,transparent 42%),linear-gradient(160deg,#FAF7F0,#EDF4F3 55%,#F7F4EE)!important;color:var(--cc-ink);font-family:var(--cc-ui);}
.stApp h1,.stApp h2,.stApp h3,.stApp h4,.stApp p,.stApp label,.stApp input,.stApp textarea,.stApp select,.stApp button,
.stApp [data-testid="stText"],.stApp [data-testid="stMetricValue"],.stApp [data-testid="stMarkdownContainer"]{font-family:var(--cc-ui)!important;}
.stApp h1,.stApp h2,.stApp h3,.stApp h4{color:var(--cc-ink);line-height:1.35;letter-spacing:-.025em;font-weight:700;}
.stApp h1{font-size:34px;}.stApp h2{font-size:27px;}.stApp h3{font-size:23px;}
.stApp p{font-size:16px;line-height:1.7;color:var(--cc-copy);}
.stApp label p{font-size:15px;font-weight:400;color:var(--cc-ink);}
.stApp [data-testid="stCaptionContainer"] p{font-size:13px!important;line-height:1.65;color:var(--cc-muted)!important;}
.stApp input,.stApp textarea{font-size:16px!important;color:var(--cc-ink)!important;background:white;}
.stApp input::placeholder,.stApp textarea::placeholder{color:#64788B!important;opacity:1;}
.stApp [data-baseweb="select"]{color:var(--cc-ink);}
.stApp [data-testid="stCode"] pre,.stApp code{font-family:"DejaVu Sans Mono",Consolas,monospace;}
.block-container{max-width:1360px;padding:1rem 3rem 2.5rem;}
.st-key-cc_header{backdrop-filter:blur(12px);background:#FFFFFFC9;border-radius:16px;border-bottom:1px solid var(--cc-border);padding:14px 18px 17px;margin-bottom:30px;}
.st-key-cc_brand [data-testid="stHorizontalBlock"]{gap:12px;}
.st-key-cc_brand button{border:none!important;padding:0!important;min-height:30px!important;background:transparent!important;}
.st-key-cc_brand button p{font-size:23px!important;font-weight:700!important;color:var(--cc-ink)!important;letter-spacing:-.035em;}
.st-key-cc_brand [data-testid="stCaptionContainer"] p{font-size:11px!important;letter-spacing:.08em;margin:0;}
.st-key-cc_header [role="radiogroup"]{display:flex;gap:4px;flex-wrap:wrap;align-items:center;}
.st-key-cc_header [data-testid="stRadioOption"]{padding:10px 12px;border-radius:9px;min-height:44px;margin:0;border:1px solid transparent;cursor:pointer;transition:background .16s ease,border-color .16s ease;}
/* Preserve the actual focusable radio input. Hide only its decorative circle. */
.st-key-cc_header [data-testid="stRadioOption"]>div>div:not([data-testid="stMarkdownContainer"]){display:none;}
.st-key-cc_header [data-testid="stRadioOption"]>div{gap:0;}
.st-key-cc_header [data-testid="stRadioOption"] p{font-size:15px!important;font-weight:700!important;white-space:nowrap;line-height:1.4;color:var(--cc-copy)!important;}
.st-key-cc_header [data-testid="stRadioOption"][data-selected="true"]{background:#E8F2F4;border-color:#CFDFE4;box-shadow:inset 0 -2px var(--cc-teal);}
.st-key-cc_header [data-testid="stRadioOption"][data-selected="true"] p{color:#075B62!important;}
.st-key-cc_header [data-testid="stRadioOption"]:hover{background:#F0F5F8;}
.st-key-cc_header [data-testid="stRadioOption"]:focus-within{outline:2px solid var(--cc-teal);outline-offset:2px;}
.stApp button{border-radius:10px;min-height:46px;border:1px solid #CFDBE5;box-shadow:0 1px 2px #102A4306;transition:transform .16s ease,box-shadow .16s ease;}
.stApp button p{font-size:15px;line-height:1.4;font-weight:700;}
.stApp button:not(:disabled):hover{transform:translateY(-1px);box-shadow:0 5px 14px #102A4310;}
.stApp button:disabled{opacity:.58;}
.stApp button[kind="primary"],.stApp button[kind="primaryFormSubmit"]{background:var(--cc-teal)!important;border-color:var(--cc-teal)!important;color:#FFF!important;}
/* Specific descendant rule: Streamlit nests a Markdown container inside button labels. */
.stApp button[kind="primary"] p,.stApp button[kind="primary"] [data-testid="stMarkdownContainer"],
.stApp button[kind="primaryFormSubmit"] p,.stApp button[kind="primaryFormSubmit"] [data-testid="stMarkdownContainer"]{color:#FFF!important;}
.stApp button[kind="secondary"],.stApp button[kind="secondaryFormSubmit"]{background:white!important;color:var(--cc-ink)!important;}
.stApp button[kind="secondary"] p,.stApp button[kind="secondary"] [data-testid="stMarkdownContainer"]{color:var(--cc-ink)!important;}
.st-key-cc_landing{padding:34px 28px 35px;border:1px solid #E1E6DF;border-radius:24px;background:radial-gradient(ellipse at 0 0,#FFF5DCB0,transparent 55%),radial-gradient(ellipse at 100% 100%,#BBDDD54D,transparent 60%),#FFFFFF80;box-shadow:0 18px 60px #294D4B08;}
.st-key-cc_landing button{min-height:52px;}
.st-key-cc_landing button[kind="primary"]{background:var(--cc-ink)!important;border-color:var(--cc-ink)!important;box-shadow:0 7px 20px #102A4320;}
.cc-home-label{font-size:12px;font-weight:700;color:#087981;letter-spacing:.14em;line-height:1.65;margin-bottom:19px;}
.stApp h1.cc-home-title{font-family:var(--cc-display)!important;font-size:clamp(40px,4.2vw,58px)!important;font-weight:400!important;line-height:1.22;letter-spacing:-.035em;color:var(--cc-ink);margin:0 0 21px;}
.cc-home-title em{color:var(--cc-gold);font-style:normal;}
.stApp p.cc-home-copy{font-size:17px;line-height:1.8;max-width:640px;color:var(--cc-copy);margin-bottom:24px;}
.cc-intro-line{font-size:13px;line-height:1.7;color:var(--cc-muted);margin:15px 0 0;}
.cc-doc-stack{position:relative;isolation:isolate;margin:12px 0 0 20px;border:1px solid #D9E6EA;border-radius:22px;padding:22px;background:radial-gradient(ellipse at 100% 0,#FFF8E9 0,transparent 57%),linear-gradient(145deg,#F4F9FA,#E7F0F3);box-shadow:0 18px 45px #173B500C;}
.cc-doc-label{font-size:12px;letter-spacing:.12em;font-weight:700;color:var(--cc-muted);margin-bottom:19px;line-height:1.6;}
.cc-document{display:flex;align-items:center;gap:16px;padding:19px;background:#FFF;border:1px solid #DBE6EB;border-radius:12px;margin-bottom:12px;box-shadow:0 3px 7px #173B5005;}
.cc-document span{font-size:12px;color:#7C5916;background:#F7F1E3;padding:12px 9px;border-radius:8px;font-weight:700;min-width:43px;text-align:center;}
.cc-document strong{font-size:16px;line-height:1.55;color:var(--cc-ink);display:block;font-weight:700;}
.cc-document small{font-size:13px;line-height:1.65;color:var(--cc-muted);display:block;margin-top:3px;}
.cc-document:last-of-type{margin-bottom:0;}
.cc-engine-note{padding-top:19px;margin-top:18px;border-top:1px solid #CCDDE1;color:#365E68;font-size:12px;line-height:1.7;text-align:center;}
.cc-section-label{font-size:12px;color:#087981;letter-spacing:.12em;line-height:1.7;margin:23px 0 10px;font-weight:700;}
.cc-card-number{font-size:12px;color:var(--cc-gold);font-weight:700;letter-spacing:.07em;line-height:1.7;margin-bottom:14px;}
.st-key-cc_features [data-testid="stVerticalBlockBorderWrapper"]{background:white;border-color:#DCE5ED;border-radius:16px;box-shadow:0 7px 22px #173B5005;}
.cc-feature{min-height:160px;}
.cc-feature h3{font-size:24px;line-height:1.35;margin:0 0 12px;}
.cc-feature p{font-size:16px;line-height:1.75;color:var(--cc-copy);margin:0 0 14px;}
.cc-process{padding:20px 0;border-top:2px solid #DCE7EB;}
.cc-process strong{display:block;font-size:17px;color:var(--cc-ink);line-height:1.6;margin:8px 0;}
.cc-process p{font-size:15px;line-height:1.8;color:var(--cc-copy);}
.cc-footer{margin-top:36px;padding:22px 0;border-top:1px solid var(--cc-border);font-size:13px;line-height:1.7;color:var(--cc-muted);display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;}
.cc-work-title h1{font-size:34px;line-height:1.4;margin:6px 0 14px;}
.cc-work-title p{font-size:15px;line-height:1.8;color:var(--cc-muted);margin-bottom:25px;}
.st-key-cc_steps{margin:10px 0 15px;}
[data-testid="stMetric"]{background:white;border:1px solid #DCE5ED;padding:18px 20px;border-radius:14px;box-shadow:0 3px 12px #102A4303;}
.stApp [data-testid="stMetricLabel"] p{font-size:14px;line-height:1.6;color:var(--cc-copy);font-weight:400;}
.stApp [data-testid="stMetricValue"],.stApp [data-testid="stMetricValue"] p{font-size:28px!important;font-weight:700;color:var(--cc-ink)!important;line-height:1.5;}
[data-testid="stExpander"]{background:white;border:1px solid #DCE5ED;border-radius:12px;}
[data-testid="stExpander"] summary p{font-size:15px;font-weight:700;}
.stApp [data-testid="stAlert"] p{font-size:15px;line-height:1.75;}
@media(max-width:1050px){
 .st-key-cc_header [data-testid="stRadioOption"]{padding:9px 7px;}
 .st-key-cc_header [data-testid="stRadioOption"] p{font-size:14px!important;}
 .block-container{padding-left:1.5rem;padding-right:1.5rem;}
 .cc-doc-stack{margin-left:0;}
}
@media(max-width:760px){
 .block-container{padding-left:1rem;padding-right:1rem;}
 .st-key-cc_header{margin-bottom:19px;}
 .stApp h1.cc-home-title{font-size:36px!important;line-height:1.27;letter-spacing:-.035em;}
 .st-key-cc_landing{padding:20px 16px 24px;}
 .cc-doc-stack{padding:19px;margin:18px 0 0;}
 .cc-document{padding:16px;gap:12px;}
 .cc-feature{min-height:0;}
 .cc-home-label,.cc-section-label{font-size:11px;letter-spacing:.08em;}
 .cc-work-title h1{font-size:27px;}
 .st-key-cc_header [role="radiogroup"]{gap:4px;}
}
.cc-scene{height:145px;margin:-8px -10px 15px;background-image:var(--cc-scene);background-size:contain;background-position:center;background-repeat:no-repeat;}
.cc-process{background:#FFFFFF80;padding:21px 18px;border-radius:0 0 14px 14px;min-height:170px;}
.st-key-cc_features [data-testid="stVerticalBlockBorderWrapper"]{background:linear-gradient(135deg,#FFFFFF,#F7FAF5);}
.cc-footer{background:#FFFFFF60;border-radius:12px;padding:20px;}
@media(max-width:760px){.cc-scene{height:120px;}.cc-process{min-height:0;}.st-key-cc_header{padding:12px;}}

/* Landing motion: progressive CSS enhancement, no injected scripts. */
@keyframes cc-enter{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:translateY(0)}}
@keyframes cc-scroll-enter{from{opacity:.35;transform:translateY(24px)}to{opacity:1;transform:translateY(0)}}
@keyframes cc-glow{from{opacity:.28;transform:scale(.96)}to{opacity:.58;transform:scale(1.04)}}
.st-key-cc_landing .cc-home-label{animation:cc-enter .6s ease-out both;}
.st-key-cc_landing .cc-home-title{animation:cc-enter .7s ease-out .08s both;}
.st-key-cc_landing .cc-home-copy{animation:cc-enter .7s ease-out .16s both;}
.st-key-cc_landing .cc-intro-line{animation:cc-enter .7s ease-out .24s both;}
.st-key-cc_landing .cc-doc-stack{animation:cc-enter .8s ease-out .12s both;}
.cc-doc-stack::before{content:"";position:absolute;inset:-18px;z-index:-1;border-radius:32px;background:radial-gradient(ellipse at 80% 15%,#E8CF9238,transparent 65%);pointer-events:none;animation:cc-glow 5s ease-in-out 2 alternate;}
.cc-document{transition:transform .25s ease,box-shadow .25s ease,border-color .25s ease;}
@media(hover:hover) and (pointer:fine){
 .cc-document:hover{transform:translateX(5px);border-color:#BED4DB;box-shadow:0 9px 24px #173B5010;}
 .st-key-cc_features [data-testid="stVerticalBlockBorderWrapper"]:hover{transform:translateY(-5px);border-color:#C5A767;box-shadow:0 16px 36px #173B5012;}
 .st-key-cc_features [data-testid="stVerticalBlockBorderWrapper"]:hover::after{transform:scaleX(1);}
}
.st-key-cc_features [data-testid="stVerticalBlockBorderWrapper"]{position:relative;transition:transform .28s ease,box-shadow .28s ease,border-color .28s ease;}
.st-key-cc_features [data-testid="stVerticalBlockBorderWrapper"]::after{content:"";position:absolute;bottom:0;left:14px;right:14px;height:3px;border-radius:4px;background:linear-gradient(90deg,#916A20,#D8BC7C);transform:scaleX(0);transform-origin:left;transition:transform .3s ease;pointer-events:none;}
.st-key-cc_features [data-testid="stVerticalBlockBorderWrapper"]:focus-within{border-color:#C5A767;}
/* Unsupported browsers show every section normally. */
@supports(animation-timeline:view()){
 .cc-feature,.cc-process{animation:cc-scroll-enter linear both;animation-timeline:view();animation-range:entry 0% entry 85%;}
}
@media(prefers-reduced-motion:reduce){
 .st-key-cc_landing .cc-home-label,.st-key-cc_landing .cc-home-title,.st-key-cc_landing .cc-home-copy,.st-key-cc_landing .cc-intro-line,.st-key-cc_landing .cc-doc-stack,.cc-doc-stack::before,.cc-feature,.cc-process{animation:none!important;opacity:1!important;transform:none!important;}
 .cc-document,.st-key-cc_features [data-testid="stVerticalBlockBorderWrapper"],.st-key-cc_features [data-testid="stVerticalBlockBorderWrapper"]::after{transition:none!important;transform:none!important;}
}

@media(prefers-reduced-motion:reduce){.stApp button,.st-key-cc_header [data-testid="stRadioOption"]{transition:none!important;transform:none!important;}}
'''

def stylesheet():
    assets=Path(__file__).resolve().parents[1]/'assets'
    values=[]
    for name,file in [('cc-scene','creditcheck_scene.svg'),('cc-city','finance_skyline.svg'),('cc-shield','privacy_watermark.svg')]:
        encoded=base64.b64encode((assets/file).read_bytes()).decode()
        values.append('--'+name+':url("data:image/svg+xml;base64,'+encoded+'");')
    return '<style>'+font_faces()+':root{'+''.join(values)+'}'+CSS+PREMIUM_CSS+(assets/'controls.css').read_text(encoding='utf-8')+(assets/'workflow.css').read_text(encoding='utf-8')+(assets/'typography.css').read_text(encoding='utf-8')+(assets/'assistant.css').read_text(encoding='utf-8')+'</style>'

PREMIUM_CSS = r''' 
/* Toolbar occupies the top 60px. Keep the entire brand below it. */
.stApp .block-container{padding-top:88px!important;max-width:1440px;}
.st-key-cc_header{backdrop-filter:none;background:#FFFFFFF5;border:1px solid #E0E8E6;box-shadow:0 8px 30px #183F4710;margin-bottom:28px;padding:18px 20px;}
.st-key-cc_brand img{object-fit:contain!important;max-width:100%;height:auto;border-radius:12px;}
.st-key-cc_brand button p{font-size:22px!important;white-space:nowrap;}
.st-key-cc_brand [data-testid="stCaptionContainer"] p{color:#52697A!important;font-size:10px!important;letter-spacing:.06em;}
.st-key-cc_header [data-testid="stRadioOption"]{padding:10px 9px;}
.st-key-cc_landing{position:relative;isolation:isolate;border-radius:26px;padding:54px 38px 42px;border:1px solid #294E60;background:linear-gradient(90deg,#091E30F5 0%,#0B263BDD 48%,#123E46B8 100%),var(--cc-city),#102D40;background-size:cover;background-position:center;box-shadow:0 25px 65px #0A24352A;}
.st-key-cc_landing::after{content:"";position:absolute;inset:0;z-index:-1;border-radius:inherit;pointer-events:none;background:radial-gradient(ellipse at 5% 0,#DAAE5424,transparent 45%),var(--cc-city);background-size:cover;background-position:center;}
.st-key-cc_landing .cc-home-label{color:#C9EAE3;font-size:11px;letter-spacing:.14em;}
.stApp .st-key-cc_landing h1.cc-home-title{color:#FFFFFF!important;font-size:clamp(38px,4vw,58px)!important;line-height:1.25;letter-spacing:-.04em;text-shadow:0 3px 20px #00000015;}
.st-key-cc_landing .cc-home-title em{color:#F0CF83;}
.stApp .st-key-cc_landing p.cc-home-copy{color:#E1ECEF!important;font-size:16px;line-height:1.85;}
.st-key-cc_landing .cc-intro-line{color:#C8DADF;font-size:13px;}
.st-key-cc_landing button[kind="primary"]{background:linear-gradient(120deg,#F3D991,#DDB45C)!important;border-color:#E8C875!important;box-shadow:0 8px 24px #DDB45C24;}
.stApp .st-key-cc_landing button[kind="primary"] p,.stApp .st-key-cc_landing button[kind="primary"] [data-testid="stMarkdownContainer"]{color:#102A43!important;}
.st-key-cc_landing button[kind="secondary"]{background:#FFFFFF0D!important;border-color:#9FB9C2!important;}
.stApp .st-key-cc_landing button[kind="secondary"] p,.stApp .st-key-cc_landing button[kind="secondary"] [data-testid="stMarkdownContainer"]{color:#F1F7F8!important;}
.st-key-cc_landing .cc-doc-stack{margin:0;border:1px solid #91B8BE66;background:linear-gradient(145deg,#FFFFFF15,#D1EFEB0A);box-shadow:0 15px 35px #00000010;backdrop-filter:blur(6px);padding:20px;}
.st-key-cc_landing .cc-scene{height:135px;filter:drop-shadow(0 8px 12px #00000020);}
.st-key-cc_landing .cc-doc-label{color:#D7E9EB;font-size:11px;}
.st-key-cc_landing .cc-document{background:#FAFDFCF2;border-color:#FFFFFF55;padding:15px;box-shadow:0 6px 15px #0000000D;}
.st-key-cc_landing .cc-engine-note{color:#D7E9EB;border-color:#91B8BE55;font-size:11px;}
.st-key-cc_landing .cc-doc-stack::before{display:none;}
.st-key-cc_credit_card,.st-key-cc_privacy_card{padding:26px!important;min-height:275px;border-radius:20px!important;border:1px solid #D4E1DF!important;box-shadow:0 12px 35px #123B4609;}
.st-key-cc_credit_card{background:linear-gradient(90deg,#FFFFFFFA,#F5FAF3CC),var(--cc-scene) right center/340px no-repeat!important;}
.st-key-cc_privacy_card{background:linear-gradient(90deg,#FFFFFFF5,#F0F7F3B3),var(--cc-shield) right center/260px no-repeat!important;}
.cc-feature{min-height:170px;}
.cc-feature h3{font-size:25px;letter-spacing:-.025em;}
.cc-feature p{max-width:420px;color:#364E60!important;}
.cc-card-number{color:#805D1E;}
.cc-section-label{margin-top:32px;color:#076771;}
.cc-process{background:linear-gradient(140deg,#FFFFFF,#EDF5F1);border-top:3px solid #B69651;padding:24px 20px;box-shadow:0 8px 25px #173B5006;border-radius:0 0 16px 16px;}
.cc-process .cc-card-number{font-size:22px;color:#8A682D;}
.cc-process p{color:#42576B;}
.cc-work-title{padding:28px 30px;border:1px solid #D5E4E3;border-left:4px solid #A6833D;border-radius:16px;margin:12px 0 25px;background:linear-gradient(90deg,#FFFFFFF5,#EEF7F3D9),var(--cc-scene) right center/280px no-repeat;}
.cc-work-title .cc-section-label{margin:0;}
.cc-work-title p{margin-bottom:0;color:#42576B;}
.cc-footer{background:#102D40;color:#D8E7EA;border:1px solid #294A5E;border-radius:16px;padding:25px 28px;}
.cc-footer strong{color:#F0CF83;}
@media(max-width:1050px){.st-key-cc_landing{padding:32px 24px;}.st-key-cc_header [data-testid="stRadioOption"]{padding:9px 6px;}.st-key-cc_brand button p{font-size:20px!important;}}
@media(max-width:760px){.stApp .block-container{padding-top:80px!important;}.st-key-cc_header{padding:14px;}.st-key-cc_landing{padding:28px 20px;border-radius:20px;}.stApp .st-key-cc_landing h1.cc-home-title{font-size:36px!important;}.st-key-cc_landing .cc-doc-stack{margin-top:20px;}.st-key-cc_credit_card,.st-key-cc_privacy_card{padding:22px!important;min-height:0;}.cc-feature{min-height:0;}.cc-work-title{padding:22px 18px;}.cc-footer{padding:22px;}}
'''

"""Modeless assistant drawer using native Streamlit controls and existing API guards."""
import streamlit as st
from gemini_service import chat

SUGGESTIONS=[('Tôi làm gì tiếp?','Tôi cần làm gì tiếp theo ở bước hiện tại? Nêu dữ liệu còn thiếu và bước con người cần kiểm tra.'),
             ('Giải thích cảnh báo','Giải thích cảnh báo của hồ sơ hiện tại, nêu căn cứ và điều cần xác minh.'),
             ('DTI tính thế nào?','DTI của hồ sơ hiện tại được tính từ những số nào? Nếu chưa tính được, giải thích thông tin còn thiếu.')]

def set_open(opened):
    st.session_state['_cc_chat_open']=opened

def fill_question(question):
    st.session_state['_cc_drawer_question']=question

def open_full(go):
    set_open(False)
    go('Trợ lý hồ sơ')

def save_consent(cid,key):
    st.session_state.setdefault('_cc_drawer_consents',{})[cid]=bool(st.session_state[key])

def clear_history():
    st.session_state.messages=[]

def floating_assistant(state,page,reserve_call,go):
    # The full page already has a chat; never mount two chat widgets for it.
    if page=='Trợ lý hồ sơ':
        return
    if not st.session_state.get('_cc_chat_open',False):
        with st.container(key='cc_chat_launcher'):
            st.button('Hỏi trợ lý',icon=':material/chat_bubble_outline:',on_click=set_open,args=(True,),key='cc_chat_open',type='primary',help='Hỏi về hồ sơ đang mở mà không rời bước hiện tại')
        return
    cid=state['case']['case_id']
    if st.session_state.get('_cc_drawer_case')!=cid:
        st.session_state['_cc_drawer_question']=''
        st.session_state['_cc_drawer_case']=cid
    if st.session_state.pop('_cc_clear_drawer_question',False):
        st.session_state['_cc_drawer_question']=''
    with st.container(key='cc_chat_drawer'):
        with st.container(key='cc_chat_drawer_head'):
            title,close=st.columns([4,1],vertical_alignment='center')
            with title:
                st.markdown('**Trợ lý CreditCheck**')
                st.caption('Hồ sơ '+cid+' · '+page)
            with close:
                st.button('Đóng',on_click=set_open,args=(False,),key='cc_chat_close',type='tertiary')
        if page=='Bảo mật Excel':
            st.caption('Trợ lý đọc hồ sơ vay '+cid+', không đọc file Excel trong trang này.')
        st.caption('Hỏi về nguồn, cảnh báo hoặc chỉ số. Trợ lý không sửa hồ sơ hay xác nhận thay bạn.')
        consents=st.session_state.setdefault('_cc_drawer_consents',{})
        consent_key='cc_drawer_consent_'+cid
        st.session_state[consent_key]=consents.get(cid,False)
        consent=st.checkbox('Đồng ý gửi câu hỏi và ngữ cảnh hồ sơ giả lập đến Gemini.',key=consent_key,on_change=save_consent,args=(cid,consent_key))
        consents[cid]=consent
        with st.container(key='cc_chat_suggestions'):
            for i,(label,question) in enumerate(SUGGESTIONS):
                st.button(label,type='tertiary',key='cc_chat_suggest_'+str(i),on_click=fill_question,args=(question,))
        if st.session_state.messages:
            with st.container(key='cc_chat_drawer_history'):
                for index,entry in enumerate(st.session_state.messages):
                    with st.chat_message('user'):st.text(entry['question'])
                    with st.chat_message('assistant'):
                        for row in entry['answer']:
                            st.text(row['text']);st.caption('Căn cứ: '+', '.join(row['refs']))
                        with st.expander('Mở dữ liệu tham chiếu'):
                            st.json(entry['references'])
        else:
            st.info('Chọn câu hỏi gợi ý hoặc nhập câu hỏi. Bấm Gửi mới gọi Gemini.')
        with st.form('cc_drawer_form'):
            question=st.text_area('Câu hỏi của bạn',key='_cc_drawer_question',height=90,placeholder='Ví dụ: Vì sao hồ sơ này cần rà soát?')
            submitted=st.form_submit_button('Gửi câu hỏi',type='primary',disabled=not consent)
        if submitted:
            if not consent:
                st.warning('Cần đồng ý gửi ngữ cảnh trước khi hỏi.')
            elif not question.strip():
                st.warning('Nhập câu hỏi trước khi gửi.')
            else:
                try:
                    client=reserve_call()
                    with st.spinner('Gemini đang giải thích…'):
                        entry=chat(state,question.strip(),st.session_state.messages,client,page=page)
                    st.session_state.messages=(st.session_state.messages+[entry])[-20:]
                    st.session_state['_cc_clear_drawer_question']=True
                    st.rerun()
                except (ValueError,TypeError,KeyError) as exc:
                    st.error(str(exc))
                    st.caption('Chưa có câu trả lời mới. Câu hỏi và lịch sử cũ được giữ để bạn thử lại.')
        wide,clear=st.columns(2)
        with wide:st.button('Mở rộng',type='tertiary',on_click=open_full,args=(go,),key='cc_chat_wide')
        with clear:st.button('Xóa hội thoại',type='tertiary',on_click=clear_history,key='cc_chat_clear')

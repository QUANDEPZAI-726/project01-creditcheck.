"""CreditCheck 0.5 — per-browser session, Gemini tasks and grounded chat."""
import base64
import copy
import hashlib
import hmac
import io
import json
import os
from pathlib import Path
import sys
import threading
import time
import zipfile
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'app'))
from core import make_state, public_state, edit_field, LABELS, now
from phase2 import review_extraction_phase2, verify_income, edit_classification, set_rate
from phase3 import report_text, summary_prompt, import_summary
from phase2 import classification_prompt, import_classification
from assisted_io import read_result, rule_draft
from traceability import sync
from gemini_service import GeminiClient, run_task, chat
from privacy_excel import protect_excel, rule_rows
from ui_shell import navigation, shell_styles, landing, guide, work_title, footer, WORK_PAGES, scroll_on_page_change, render_steps, task_brief
from assistant_ui import floating_assistant
from input_security import (session_key, seal_session, open_session, pack_inputs, unpack_inputs,
                            encrypt_export, decrypt_export, validate_connection)

def encryption_key():
    if '_encryption_key' not in st.session_state:
        st.session_state['_encryption_key'] = session_key()
    return st.session_state['_encryption_key']

def protect_inputs(case_id, files, coverage=None):
    packed = pack_inputs(case_id, files, coverage)
    protected = seal_session(packed, encryption_key(), 'input:'+case_id)
    # Authenticate/decrypt before parsing; the working dossier is plaintext in RAM.
    clear = open_session(protected, encryption_key(), 'input:'+case_id)
    cid, restored_files, restored_coverage = unpack_inputs(clear)
    result = make_state(cid, restored_files, restored_coverage)
    vault = st.session_state.setdefault('_input_vault', {})
    vault[cid] = protected
    if st.session_state.get('_encrypted_download',{}).get('case_id') == cid:
        st.session_state.pop('_encrypted_download',None)
    return result

def save_personal_connection():
    try:
        key, model = validate_connection(st.session_state.get('_api_key_input',''),
                                         st.session_state.get('_model_input',''))
        st.session_state['_personal_key'] = seal_session(key.encode(), encryption_key(), 'gemini-key')
        st.session_state['_personal_model'] = model
        st.session_state['_api_key_input'] = ''
        st.session_state['_connection_error'] = ''
    except ValueError as exc:
        st.session_state['_connection_error'] = str(exc)

def clear_personal_connection():
    for key in ('_personal_key','_personal_model','_connection_error'):
        st.session_state.pop(key,None)
    st.session_state['_api_key_input'] = ''

def prepare_encrypted_download(case_id):
    try:
        blob = st.session_state.get('_input_vault',{}).get(case_id)
        if not blob:
            raise ValueError('Chưa có bản đầu vào mã hóa cho hồ sơ này.')
        clear = open_session(blob, encryption_key(), 'input:'+case_id)
        encrypted = encrypt_export(clear, st.session_state.get('_export_password',''))
        st.session_state['_encrypted_download'] = {'case_id':case_id,'data':encrypted}
        st.session_state['_export_password'] = ''
        st.session_state['_encryption_notice'] = 'Đã tạo bản mã hóa. Giữ mật khẩu riêng để nhập lại ở phiên khác.'
        st.session_state.pop('_encryption_error',None)
    except ValueError as exc:
        st.session_state.pop('_encrypted_download',None)
        st.session_state['_encryption_error'] = str(exc)

def restore_encrypted_inputs():
    try:
        uploaded = st.session_state.get('_encrypted_upload')
        if uploaded is None:
            raise ValueError('Chọn tệp .ccenc trước.')
        clear = decrypt_export(uploaded.getvalue(),st.session_state.get('_import_password',''))
        case_id, files, coverage = unpack_inputs(clear)
        # New dossier: never restore someone else's human confirmations from input files.
        result = protect_inputs(case_id,files,coverage)
        sync(result)
        old = st.session_state.dossier
        st.session_state.portfolio[old['case']['case_id']] = copy.deepcopy(old)
        st.session_state.dossier = result
        st.session_state.messages = []
        st.session_state['_import_password'] = ''
        st.session_state['_encryption_notice'] = 'Giải mã và nhập đầu vào thành công. Cần đối chiếu và xác minh lại.'
        st.session_state.pop('_encryption_error',None)
    except (ValueError,TypeError,KeyError) as exc:
        st.session_state['_encryption_error'] = str(exc)

def encryption_ui(case_id):
    with st.expander('Mã hóa thông tin đầu vào · AES-256-GCM'):
        blob = st.session_state.get('_input_vault',{}).get(case_id)
        if blob:
            st.success('Đã tạo bản mã hóa tài liệu đầu vào cho hồ sơ '+case_id+'.')
            st.caption('Bản đầu vào mã hóa được giữ trong phiên. Dữ liệu xử lý và màn hình vẫn là bản rõ trong bộ nhớ; Gemini nhận nội dung cần xử lý qua kết nối HTTPS.')
            with st.expander('Xem một phần bản mã để demo'):
                st.code(base64.b64encode(blob[12:]).decode()[:160]+'…',language=None)
        else:
            st.info('Mở hoặc tải hồ sơ ở bước Hồ sơ để tạo bản đầu vào mã hóa.')
        st.write('Tải bản đầu vào mã hóa để cất giữ hoặc chuyển sang phiên khác. Tệp này không chứa API key, mật khẩu, báo cáo hoặc xác nhận của người kiểm tra.')
        with st.form('encrypt_input_export'):
            st.text_input('Mật khẩu mã hóa đầu vào (ít nhất 12 ký tự)',type='password',key='_export_password')
            st.form_submit_button('Tạo tệp đầu vào mã hóa',on_click=prepare_encrypted_download,args=(case_id,))
        saved=st.session_state.get('_encrypted_download')
        if saved and saved['case_id']==case_id:
            st.download_button('Tải đầu vào mã hóa .ccenc',saved['data'],case_id+'_inputs.ccenc','application/octet-stream',key='download_encrypted')
        with st.form('decrypt_input_import'):
            st.file_uploader('Nhập lại tệp đầu vào .ccenc',type=['ccenc'],key='_encrypted_upload')
            st.text_input('Mật khẩu giải mã đầu vào',type='password',key='_import_password')
            st.form_submit_button('Giải mã và mở hồ sơ',on_click=restore_encrypted_inputs)
        if st.session_state.get('_encryption_error'):st.error(st.session_state['_encryption_error'])
        elif st.session_state.get('_encryption_notice'):st.info(st.session_state['_encryption_notice'])
        st.caption('PDF/ZIP thường vẫn là bản rõ. Chỉ tệp .ccenc được bảo vệ bằng mật khẩu; giữ mật khẩu riêng, ứng dụng không khôi phục được mật khẩu đã mất.')

def configured_connection():
    if st.session_state.get('_api_source','API key của tôi') == 'API key của tôi':
        if not st.session_state.get('_personal_key'):
            raise ValueError('Mở Kết nối Gemini, nhập API key của bạn rồi bấm Lưu kết nối.')
        key = open_session(st.session_state['_personal_key'], encryption_key(), 'gemini-key').decode()
        return validate_connection(key, st.session_state['_personal_model'])
    code = secret('DEMO_ACCESS_CODE')
    if not code or not st.session_state.get('api_unlocked'):
        raise ValueError('Mở quyền dùng API key nhóm bằng mã truy cập trước.')
    key = secret('GEMINI_API_KEY')
    if not key or key.startswith('REPLACE_'):
        raise ValueError('Chưa cấu hình API key nhóm trong Secrets.')
    return validate_connection(key, secret('GEMINI_MODEL','gemini-3.5-flash-lite'))

def secret(name, default=''):
    try:
        return str(st.secrets.get(name, os.environ.get(name, default)))
    except (FileNotFoundError, st.errors.StreamlitSecretNotFoundError):
        return os.environ.get(name, default)

@st.cache_resource
def shared_budget():
    # Counters only; never store user dossiers/chats in a shared cache.
    return {'lock': threading.Lock(), 'times': []}

def reserve_call():
    api_key, model = configured_connection()
    personal = st.session_state.get('_api_source','API key của tôi') == 'API key của tôi'
    b = shared_budget()
    current = time.monotonic()
    with b['lock']:
        b['times'] = [x for x in b['times'] if current - x < 3600]
        if not personal and len(b['times']) >= 60:
            raise ValueError('Đã đạt giới hạn demo 60 lượt/giờ trên máy chủ này.')
        if current - st.session_state.get('last_api_call', -100) < 5:
            raise ValueError('Chờ ít nhất 5 giây giữa hai lượt API.')
        if st.session_state.get('api_calls', 0) >= 30:
            raise ValueError('Phiên này đã đạt giới hạn 30 lượt API.')
        if not personal:
            b['times'].append(current)
        st.session_state.last_api_call = current
        st.session_state.api_calls = st.session_state.get('api_calls', 0) + 1
    return GeminiClient(api_key, model)

def sample(cid):
    folder = ROOT / 'runtime/cases' / cid
    manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
    files = {d['source_type']: (folder / d['path']).read_bytes()
             for d in manifest['documents'] if d['available']}
    coverage = next(d for d in manifest['documents'] if d['source_type'] == 'bank_statement')
    state = protect_inputs(cid, files, coverage if coverage['available'] else None)
    sync(state)
    return state

def commit(state, reset_chat=True):
    sync(state)
    st.session_state.dossier = state
    if reset_chat:
        st.session_state.messages = []
    st.session_state.notice = 'Đã cập nhật. Kiểm tra nguồn và trạng thái trước khi tiếp tục.'
    st.rerun()

def mutate(fn, body):
    try:
        state = copy.deepcopy(st.session_state.dossier)
        fn(state, dict(body, expected_version=state['version']))
        commit(state)
    except (ValueError, TypeError, KeyError) as exc:
        st.error(str(exc))

def api_button(task, label, key):
    consent = st.checkbox('Tôi đồng ý gửi dữ liệu giả lập của hồ sơ này đến Google Gemini.', key=key+'_consent')
    current=st.session_state.dossier
    has_result=(bool(current.get('llm_runs')) if task=='extraction' else current['phase2']['classification'] is not None if task=='classification' else current['phase3']['summary'] is not None)
    allowed=task!='classification' or current['extraction_review']['status']=='Reviewed'
    if not allowed:st.caption('Để chạy phân loại: đối chiếu nguồn và xác nhận trích xuất trước.')
    if st.button(label, key=key, type='secondary' if has_result else 'primary', disabled=not consent or not allowed):
        try:
            client = reserve_call()
            with st.spinner('Gemini đang xử lý; Python sẽ kiểm tra kết quả…'):
                state = run_task(st.session_state.dossier, task, client)
            commit(state)
        except (ValueError, TypeError, KeyError) as exc:
            st.error(str(exc))
            st.caption('Dữ liệu cũ được giữ. Không tự dùng kết quả mẫu thay cho API.')

def saved_result_ui(task, state, key):
    label='phân loại giao dịch' if task=='classification' else 'báo cáo'
    with st.expander('Dùng kết quả LLM đã lưu · '+label, expanded=False):
        st.write('Không cần khóa API. Tải prompt hiện tại, dùng ChatGPT bên ngoài rồi nhập kết quả JSON; hoặc chọn ZIP báo cáo cũ. Không tự khôi phục xác nhận của người kiểm tra.')
        if task=='classification' and state['extraction_review']['status']!='Reviewed':
            st.info('Đối chiếu nguồn và xác nhận phần trích xuất trước.');return
        try:
            prompt=classification_prompt(state) if task=='classification' else summary_prompt(state)
        except ValueError as exc:
            st.warning(str(exc));return
        st.download_button('Tải prompt '+label, prompt, state['case']['case_id']+'_'+task+'_prompt.txt',key=key+'prompt')
        with st.expander('Xem prompt để sao chép'):st.code(prompt,language=None)
        with st.form(key+'import'):
            upload=st.file_uploader('JSON hoặc ZIP kết quả '+label,type=['json','zip'])
            raw=st.text_area('Hoặc dán JSON kết quả '+label)
            model=st.text_input('Tên công cụ/model tạo kết quả',placeholder='Ví dụ: ChatGPT — kết quả đã lưu')
            attest=st.checkbox('Đây là kết quả LLM đã nhận; chưa được xác minh bởi con người.')
            if st.form_submit_button('Nhập kết quả '+label):
                try:
                    data=upload.getvalue() if upload is not None else raw.encode('utf-8')
                    obj=read_result(data,task)
                    mutate(import_classification if task=='classification' else import_summary,{'result':obj,'model':model,'attest':attest})
                except (ValueError,TypeError,KeyError) as exc:st.error(str(exc))
        if task=='classification':
            candidate=ROOT/'incoming'/str(state['case']['case_id']+'_classification.json')
            if candidate.exists():
                st.caption('Ứng viên phân loại mẫu do ChatGPT soạn cho nguồn gốc. Chưa xác minh thu nhập; nguồn đã đổi sẽ bị từ chối.')
                st.download_button('Tải JSON phân loại mẫu '+state['case']['case_id'],candidate.read_bytes(),candidate.name,'application/json',key=key+'sample')
                if st.button('Nạp ứng viên ChatGPT đã lưu · '+state['case']['case_id'],key=key+'load'):
                    mutate(import_classification,{'result':read_result(candidate.read_bytes(),task),'model':'ChatGPT — ứng viên mẫu v0.7 đã lưu','attest':True})

def source_view(state, did, suffix):
    src = state['sources'].get(did)
    if not src:
        st.info('Nguồn chưa được cung cấp.')
        return
    st.text(src['text'])
    ext = '.csv' if src['role'] == 'bank_statement' else '.pdf'
    st.download_button('Tải nguồn '+did, base64.b64decode(src['bytes_b64']),
                       file_name=did+ext, key='source_'+suffix+'_'+did)

def archive(state):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('case.json', json.dumps(state['case'], ensure_ascii=False, indent=2))
        z.writestr('review_and_log.json', json.dumps(public_state(state), ensure_ascii=False, indent=2))
        z.writestr('evidence_trace.json', json.dumps(state['traceability'], ensure_ascii=False, indent=2))
        z.writestr('chat.json', json.dumps(st.session_state.messages, ensure_ascii=False, indent=2))
        if state['phase3']['summary']:
            z.writestr('summary.txt', report_text(state))
            z.writestr('summary.pdf', pdf_bytes(copy.deepcopy(state)))
        for did, src in state['sources'].items():
            z.writestr('sources/'+did+('.csv' if src['role']=='bank_statement' else '.pdf'), base64.b64decode(src['bytes_b64']))
    return buf.getvalue()

from html import escape
import pandas as pd
import altair as alt
from phase2 import value
from presentation import money, ratio, checkpoints, workflow, next_action, income_rows, debt_rows
from pdf_report import pdf_bytes

PAGES=['Trang chủ','Hướng dẫn','Tổng quan','1 · Hồ sơ','2 · Kiểm tra','3 · Phân tích','4 · Báo cáo','Trợ lý hồ sơ','Bảo mật Excel']
# Use the same group logo for the browser tab and the in-app brand.
deploy_root=Path(os.environ.get('CREDITCHECK_DEPLOY_ROOT',str(ROOT)))
logo=deploy_root/'logo.png'
if not logo.exists():logo=ROOT/'assets/brand_logo.png'
if not logo.exists():logo=deploy_root/'1790301130067_5325247545233387896_g6287506212488219102_01bae03835e1c999662e363ca9e66ec9.jpg'
from PIL import Image
with Image.open(logo) as logo_image:
    browser_icon=logo_image.copy()
st.set_page_config(page_title='Project 1 · CreditCheck',page_icon=browser_icon,layout='wide')


def go(page):st.session_state.page=page

def commit(state, reset_chat=True):
    sync(state)
    st.session_state.dossier=state
    st.session_state.portfolio[state['case']['case_id']]=copy.deepcopy(state)
    if reset_chat:st.session_state.messages=[]
    st.session_state.notice='Đã lưu thay đổi trong phiên. '+next_action(state)
    st.rerun()

def open_case(cid):
    st.session_state.portfolio[st.session_state.dossier['case']['case_id']]=copy.deepcopy(st.session_state.dossier)
    st.session_state.dossier=copy.deepcopy(st.session_state.portfolio[cid])
    st.session_state.messages=[]
    st.session_state.page='1 · Hồ sơ'

def next_button(target, enabled=True, reason=''):
    st.divider()
    if not enabled:st.info('Chưa thể tiếp tục: '+reason)
    st.button('Bước tiếp theo → '+target.split(' · ')[-1],type='secondary' if st.session_state.page in ['1 · Hồ sơ','4 · Báo cáo'] else 'primary',disabled=not enabled,
              on_click=go,args=(target,),key='next_'+target)

def readable_alerts(s):
    for alert in s['traceability']['alerts']:
        with st.expander(alert['message'],expanded=False):
            st.write(alert['rule'])
            for i,ev in enumerate(alert['evidence']):
                st.caption(ev['document_id']+' · '+ev['locator'])
                st.text(ev.get('quote') or 'Nguồn chưa được cung cấp; không có trích dẫn.')
                with st.expander('Xem tài liệu làm căn cứ '+str(i+1)):
                    source_view(s,ev['document_id'],alert['alert_id']+'_'+str(i))
            with st.expander('Chi tiết quy tắc'):
                st.json(alert['rule_inputs'])
    if not s['traceability']['alerts']:st.info('Chưa có cảnh báo theo các phép kiểm tra hiện tại. Không có nghĩa được duyệt vay.')

def chart(rows,x,y,title):
    if not rows:
        st.info('Chưa có đủ dữ liệu để vẽ biểu đồ này.')
        return
    c=alt.Chart(pd.DataFrame(rows)).mark_bar(color='#087F8C',cornerRadiusEnd=5).encode(
        x=alt.X(x+':Q',title='Đồng'),y=alt.Y(y+':N',sort=None,title=None),tooltip=[y,x]).properties(height=180,title=title)
    c=c.configure_axis(labelColor='#172B4D',titleColor='#52647A',labelFontSize=12).configure_title(color='#172B4D',fontSize=15).configure_view(stroke=None).configure(background='#FFFFFF')
    st.altair_chart(c,width='stretch',theme=None)

def technical_tools(s):
    with st.expander('Dữ liệu, nguồn gốc LLM và nhật ký · nâng cao'):
        st.caption('Không cần đọc JSON để sử dụng quy trình chính.')
        st.json(s['llm_runs'])
        st.json(s['events'])
        st.download_button('Tải dữ liệu JSON',json.dumps(s['case'],ensure_ascii=False,indent=2),s['case']['case_id']+'_case.json','application/json')
        st.download_button('Tải bảng truy vết',json.dumps(s['traceability'],ensure_ascii=False,indent=2),s['case']['case_id']+'_trace.json','application/json')

if 'page' not in st.session_state:st.session_state.page='Trang chủ'
if 'dossier' not in st.session_state:
    st.session_state.dossier=sample('HS01')
if 'messages' not in st.session_state:st.session_state.messages=[]
if 'portfolio' not in st.session_state:
    st.session_state.portfolio={cid:sample(cid) for cid in ['HS01','HS02','HS03','HS04','HS05']}
state=st.session_state.dossier
sync(state)
cid=state['case']['case_id'];prefix=cid+'_'+str(state['version'])+'_'
st.session_state.portfolio[cid]=copy.deepcopy(state)

def connection_ui():
    source=st.radio('Nguồn API key',['API key của tôi','API key của nhóm'],key='_api_source')
    if source == 'API key của tôi':
        st.caption('Key chỉ dùng trong phiên này, không ghi vào PDF/ZIP hoặc nhật ký. Máy chủ dùng key để gọi Google Gemini.')
        with st.form('personal_connection'):
            st.text_input('API key Gemini của bạn',type='password',key='_api_key_input')
            st.text_input('Tên model Gemini',value=st.session_state.get('_personal_model','gemini-3.5-flash-lite'),key='_model_input')
            st.form_submit_button('Lưu kết nối',on_click=save_personal_connection)
        if st.session_state.get('_connection_error'):st.error(st.session_state['_connection_error'])
        if st.session_state.get('_personal_key'):
            st.success('Đã lưu key cho phiên này. Quyền API được kiểm tra khi chạy tác vụ.')
            st.caption('Model đang dùng: '+st.session_state['_personal_model'])
        st.button('Xóa API key khỏi phiên',on_click=clear_personal_connection)
    else:
        st.caption('Đã cấu hình key nhóm' if secret('GEMINI_API_KEY') and not secret('GEMINI_API_KEY').startswith('REPLACE_') else 'Chưa cấu hình key nhóm.')
        code=st.text_input('Mã truy cập API của nhóm',type='password',key='access_input')
        if st.button('Mở quyền chạy API'):
            expected=secret('DEMO_ACCESS_CODE')
            st.session_state.api_unlocked=bool(expected and not expected.startswith('REPLACE_') and hmac.compare_digest(code.encode(),expected.encode()))
            if st.session_state.api_unlocked:st.success('Đã mở quyền cho phiên này.')
            else:st.error('Mã chưa đúng hoặc chưa cấu hình.')
        st.caption('Model nhóm: '+secret('GEMINI_MODEL','gemini-3.5-flash-lite'))

shell_styles()
page=navigation(logo,connection_ui,go)
if page in WORK_PAGES:
    render_steps(state,page,go)

labels={'Tổng quan':('TỔNG QUAN HỒ SƠ','Mỗi hồ sơ, một hành trình rõ ràng.'),
        '1 · Hồ sơ':('BƯỚC 01 / 04','Bắt đầu từ tài liệu của bạn.'),
        '2 · Kiểm tra':('BƯỚC 02 / 04','Kiểm tra những gì hệ thống đã hiểu.'),
        '3 · Phân tích':('BƯỚC 03 / 04','Hiểu chỉ số và căn cứ cảnh báo.'),
        '4 · Báo cáo':('BƯỚC 04 / 04','Đọc, kiểm tra và bàn giao báo cáo.'),
        'Trợ lý hồ sơ':('TRỢ LÝ THEO NGỮ CẢNH','Hỏi về hồ sơ đang mở.'),
        'Bảo mật Excel':('BẢO MẬT DỮ LIỆU EXCEL','Tạo bản dữ liệu đã giả danh hóa.')}
if page in labels:
    eyebrow,title=labels[page]
    work_title(eyebrow,title)
    task_brief(page)
if page in WORK_PAGES or page=='Trợ lý hồ sơ':
    with st.container(key='cc_summary_strip'):
        cols=st.columns(4)
        cols[0].metric('Trạng thái hồ sơ','Thiếu thông tin' if state['phase3']['report_status']=='Insufficient information' else 'Cần rà soát')
        cols[1].metric('Thu nhập đã xác minh',money(state['phase2']['metrics']['validated_monthly_income_vnd']))
        cols[2].metric('DTI · trả nợ / thu nhập',ratio(state['phase2']['metrics']['dti_pct']))
        cols[3].metric('Cảnh báo cần xem',len(state['traceability']['alerts']))
    st.caption(cid+' · '+str(value(state,'full_name') or 'Chưa có tên người vay')+' · '+state['phase3']['report_status'])
    if 'notice' in st.session_state:st.success(st.session_state.pop('notice'))
    if state['traceability']['alerts']:st.warning('Cảnh báo chính: '+state['traceability']['alerts'][0]['message'])
    st.caption('Tiếp theo: '+next_action(state))
    st.caption(str(sum(checkpoints(state)))+'/4 checkpoints hoàn thành · Không phải điểm tín dụng hay khả năng duyệt vay.')

if page=='Trang chủ':
    landing(go)
elif page=='Hướng dẫn':
    guide(go)
elif page=='Tổng quan':
    st.subheader('Tiến độ hồ sơ đang mở')
    a,b=st.columns([1,2])
    done=sum(checkpoints(state))
    with a:
        data=pd.DataFrame({'Trạng thái':['Đã hoàn thành','Cần xử lý'],'Số bước':[done,4-done]})
        ring=alt.Chart(data).mark_arc(innerRadius=65,outerRadius=90).encode(theta='Số bước:Q',
            color=alt.Color('Trạng thái:N',scale=alt.Scale(domain=['Đã hoàn thành','Cần xử lý'],range=['#087F8C','#DCE4EF']),legend=None),tooltip=['Trạng thái','Số bước'])
        text=alt.Chart(pd.DataFrame({'Nhãn':[str(done)+'/4']})).mark_text(fontSize=28,fontWeight='bold',color='#172B4D').encode(text='Nhãn:N')
        st.altair_chart((ring+text).properties(height=220).configure_view(stroke=None).configure(background='#F4F7FB'),width='stretch',theme=None)
    with b:
        st.dataframe(workflow(state),hide_index=True,width='stretch')
        st.caption('Đủ nguồn → Kiểm tra & xác minh thu nhập → Có chỉ số → Báo cáo đã kiểm tra. Hồ sơ lỗi có thể dừng ở checkpoint cần bổ sung.')
    st.subheader('Tất cả hồ sơ trong phiên')
    rows=[]
    for key,s in st.session_state.portfolio.items():
        sync(s)
        rows.append({'Hồ sơ':key,'Người vay':value(s,'full_name') or 'Chưa có',
                     'Nguồn đã nhận':str(sum(d['available'] for d in s['case']['documents']))+'/3',
                     'Trạng thái':'Thiếu thông tin' if s['phase3']['report_status']=='Insufficient information' else 'Cần rà soát',
                     'Tiến độ':str(sum(checkpoints(s)))+'/4', 'Cảnh báo':len(s['traceability']['alerts'])})
    st.dataframe(rows,hide_index=True,width='stretch')
    selection=st.selectbox('Chọn hồ sơ để tiếp tục',list(st.session_state.portfolio),key='overview_case')
    st.button('Mở hồ sơ đã chọn',type='primary',on_click=open_case,args=(selection,))
    st.caption('Các hồ sơ mẫu bắt đầu bằng dữ liệu đọc theo mẫu. Kết quả kiểm tra trong phiên được giữ khi chuyển hồ sơ; chưa lưu lâu dài theo tài khoản.')
    st.subheader('Bạn sẽ làm gì?')
    st.dataframe([{'Bước':'01 · Hồ sơ','Bạn làm':'Chọn/tải ba nguồn; trích xuất thông tin'},
                  {'Bước':'02 · Kiểm tra','Bạn làm':'Đối chiếu dữ liệu; kiểm tra giao dịch và xác minh nguồn thu'},
                  {'Bước':'03 · Phân tích','Bạn làm':'Xem DTI, trả góp, cảnh báo và căn cứ'},
                  {'Bước':'04 · Báo cáo','Bạn làm':'Tạo nháp, đọc và xác nhận; tải PDF'}],hide_index=True,width='stretch')
    next_button('1 · Hồ sơ')

elif page=='1 · Hồ sơ':
    st.subheader('Chọn nguồn tài liệu')
    sample_tab,upload_tab=st.tabs(['Hồ sơ mẫu','Tài liệu của bạn'])
    with sample_tab:
        left,right=st.columns([3,2],gap='large')
        with left:
            selected=st.selectbox('Hồ sơ mẫu',list(st.session_state.portfolio),key='sample_selection')
            st.button('Mở hồ sơ mẫu',on_click=open_case,args=(selected,))
        with right:
            st.caption('Nguồn của hồ sơ đang mở')
            for doc in state['case']['documents']:
                name={'application':'Đơn vay PDF','income_certificate':'Xác nhận thu nhập PDF','bank_statement':'Sao kê CSV'}[doc['source_type']]
                st.write(('✓ ' if doc['available'] else '○ ')+name)
    with upload_tab:
        with st.form('upload'):
            uploaded_cid=st.text_input('Mã hồ sơ mới',value='HS06')
            app=st.file_uploader('Đơn vay PDF',type=['pdf'])
            income=st.file_uploader('Xác nhận thu nhập PDF',type=['pdf'])
            bank=st.file_uploader('Sao kê CSV',type=['csv'])
            if st.form_submit_button('Đọc tài liệu'):
                try:
                    files={k:v.getvalue() for k,v in [('application',app),('income_certificate',income),('bank_statement',bank)] if v}
                    if sum(map(len,files.values()))>10*1024*1024:raise ValueError('Tổng tệp tối đa 10 MB.')
                    commit(protect_inputs(uploaded_cid,files))
                except (ValueError,TypeError,KeyError) as exc:st.error(str(exc))
    st.subheader('Đọc thông tin bằng Gemini')
    st.write('Gemini trả dữ liệu có cấu trúc. Bước tiếp theo bạn sẽ đối chiếu với tài liệu nguồn.')
    api_button('extraction','Chạy Gemini trích xuất',prefix+'extract')
    next_button('2 · Kiểm tra')
    with st.expander('Công cụ phụ · mã hóa, kết quả lưu và nhật ký'):
        encryption_ui(cid)
        with st.expander('Khôi phục kết quả mẫu đã lưu'):
            st.caption('Dùng kết quả LLM đã lưu, không gọi Gemini mới; thay trạng thái hồ sơ đang mở.')
            if st.button('Khôi phục HS01 đã kiểm tra · kết quả lưu v0.4',type='tertiary'):
                commit(json.loads((ROOT/'seed/HS01_session.json').read_text(encoding='utf-8')))
        technical_tools(state)

elif page=='2 · Kiểm tra':
    with st.expander('1. Đối chiếu thông tin với nguồn',expanded=state['extraction_review']['status']!='Reviewed'):
        docs={d['document_id']:d for d in state['case']['documents'] if d['available'] and d['source_type']!='bank_statement'}
        if docs:
            did=st.selectbox('Tài liệu cần kiểm tra',list(docs),key=prefix+'check_doc')
            left,right=st.columns([1,1])
            with left:
                st.caption('Thông tin hệ thống đã đọc')
                st.dataframe([{'Thông tin':LABELS.get(k,k),'Giá trị':str(f['value'])} for k,f in docs[did]['fields'].items()],hide_index=True,width='stretch')
            with right:
                st.caption('Nguồn để đối chiếu')
                source_view(state,did,'check')
            with st.expander('Sửa thông tin đọc sai · cần căn cứ'):
                field=st.selectbox('Trường cần sửa',list(docs[did]['fields']),key=prefix+'field')
                with st.form(prefix+'edit_field'):
                    raw=st.text_input('Giá trị JSON (số hoặc chuỗi trong dấu nháy)',value=json.dumps(docs[did]['fields'][field]['value'],ensure_ascii=False))
                    pg=st.number_input('Trang nguồn',min_value=1,value=1)
                    quote=st.text_input('Trích dẫn nguyên văn')
                    reviewer=st.text_input('Người sửa')
                    reason=st.text_input('Lý do sửa')
                    if st.form_submit_button('Lưu sửa và kiểm tra lại'):
                        try:
                            v=json.loads(raw)
                            ev=[] if v is None else [{'document_id':did,'locator_type':'pdf_page_field','locator':f'page={pg}; field={LABELS[field]}','quote':quote}]
                            mutate(edit_field,{'document_id':did,'field':field,'value':v,'evidence':ev,'reviewer':reviewer,'reason':reason})
                        except ValueError as exc:st.error(str(exc))
        with st.form(prefix+'review_extraction'):
            name=st.text_input('Người kiểm tra')
            note=st.text_area('Ghi chú đối chiếu nguồn')
            checked=st.checkbox('Tôi đã đối chiếu các trường với tài liệu nguồn.')
            if st.form_submit_button('Xác nhận phần trích xuất',type='primary'):
                mutate(review_extraction_phase2,{'reviewer':name,'reason':note,'checked':checked})
        st.caption('Xác nhận này chỉ kiểm tra thông tin đọc đúng tài liệu, chưa xác minh thu nhập.')
    with st.expander('2. Kiểm tra giao dịch và nguồn thu',expanded=state['extraction_review']['status']=='Reviewed'):
        if state['extraction_review']['status']!='Reviewed':st.info('Cần xác nhận trích xuất trước khi nhập phân loại.')
        api_button('classification','Chạy Gemini phân loại',prefix+'classify')
        saved_result_ui('classification',state,prefix+'saved_classification')
        classification=state['phase2']['classification']
        if classification:
            st.dataframe([{'Giao dịch':r['transaction_id'],'Loại':{'salary':'Lương','other':'Khoản khác','uncertain':'Chưa rõ'}[r['label']],
                           'Lý do':r['reason']} for r in classification['rows']],hide_index=True,width='stretch')
            with st.expander('Xem sao kê và sửa nhãn có căn cứ'):
                bank_id=next((k for k,s in state['sources'].items() if s['role']=='bank_statement'),None)
                if bank_id:source_view(state,bank_id,'classify')
                tid=st.selectbox('Giao dịch cần kiểm tra',[r['transaction_id'] for r in classification['rows']],key=prefix+'tid')
                with st.form(prefix+'edit_class'):
                    label=st.selectbox('Nhãn mới',['salary','other','uncertain'],format_func=lambda x:{'salary':'Lương','other':'Khoản khác','uncertain':'Chưa rõ'}[x])
                    reviewer=st.text_input('Người kiểm tra nhãn');reason=st.text_input('Lý do thay đổi');note=st.text_area('Căn cứ bổ sung đã kiểm tra')
                    if st.form_submit_button('Cập nhật nhãn'):mutate(edit_classification,{'transaction_id':tid,'label':label,'reviewer':reviewer,'reason':reason,'supporting_note':note})
        pre=state['phase2'].get('preview')
        if pre:
            st.metric('Lương bình quân xem trước · chưa xác minh',money(pre['mean_salary_vnd']))
            if pre['unresolved_transaction_ids']:st.warning('Còn '+str(len(pre['unresolved_transaction_ids']))+' khoản chưa rõ. Cần căn cứ trước khi xác minh.')
            with st.expander('Chi tiết tổng hợp nguồn thu'):st.json(pre)
        coverage=next(d for d in state['case']['documents'] if d['source_type']=='bank_statement')
        with st.form(prefix+'income_review'):
            start=st.text_input('Từ ngày YYYY-MM-DD',value=coverage.get('coverage_start') or '2026-07-01')
            end=st.text_input('Đến ngày YYYY-MM-DD',value=coverage.get('coverage_end') or '2026-09-30')
            name=st.text_input('Người xác minh thu nhập');note=st.text_area('Ghi chú xác minh và căn cứ dùng thu nhập sao kê')
            checked=st.checkbox('Đã đối chiếu nhãn và nguồn trả lương.');complete=st.checkbox('Đã kiểm tra kỳ sao kê đầy đủ.')
            gap=st.checkbox('Đã xem chênh lệch thu nhập nếu có và ghi căn cứ ở trên.')
            if st.form_submit_button('Xác minh thu nhập và tính chỉ số',type='primary'):
                mutate(verify_income,{'coverage_start':start,'coverage_end':end,'reviewer':name,'reason':note,'checked':checked,'coverage_checked':complete,'acknowledge_gap':gap})
    enabled=state['phase2']['income_review'] is not None
    next_button('3 · Phân tích',enabled,'Cần đủ nguồn, phân loại rõ và xác minh thu nhập. '+next_action(state))
    if not enabled:st.button('Xem cảnh báo và dữ liệu chưa đủ',on_click=go,args=('3 · Phân tích',))

elif page=='3 · Phân tích':
    st.subheader('Thu nhập và nghĩa vụ trả nợ')
    st.metric('Trả góp mới mỗi tháng',money(state['phase2']['metrics']['monthly_payment_vnd']))
    a,b=st.columns(2)
    with a:
        chart(income_rows(state),'Thu nhập (đ)','Nguồn','Thu nhập theo nguồn')
        st.caption('Khai báo và xác nhận là dữ kiện tài liệu; chỉ sao kê đã xác minh mới là đầu vào tính DTI.')
    with b:
        chart(debt_rows(state),'Số tiền (đ)','Khoản','Thu nhập sau nghĩa vụ trả nợ')
        st.caption('Phần còn lại chưa trừ chi phí sinh hoạt, không phải tiền tiết kiệm.')
    st.write('DTI là tổng nợ hiện tại và trả góp mới chia thu nhập đã xác minh. Chỉ số chưa có được giữ trống, không biến thành 0.')
    st.subheader('Cảnh báo và căn cứ')
    readable_alerts(state)
    with st.expander('Giả định và cách tính · có thể điều chỉnh'):
        st.caption('Ngưỡng DTI 40%, độ lệch 20% là giả định bài tập; chưa tính phí/bảo hiểm.')
        with st.form(prefix+'rate'):
            rate=st.number_input('Lãi danh nghĩa %/năm',min_value=0.0,max_value=100.0,value=state['phase2']['config']['annual_nominal_rate']*100)
            name=st.text_input('Người thay giả định');note=st.text_input('Lý do thay lãi suất')
            if st.form_submit_button('Tính lại với lãi suất mới'):mutate(set_rate,{'annual_nominal_rate':rate/100,'reviewer':name,'reason':note})
        st.json(state['phase2'].get('calculation_trace'))
    next_button('4 · Báo cáo')
    st.caption('Có thể tạo báo cáo ghi thiếu thông tin. Điều đó không tự xác minh thu nhập hoặc cho phép duyệt vay.')

elif page=='4 · Báo cáo':
    st.subheader('Báo cáo có thể kiểm tra và bàn giao')
    api_button('summary','Chạy Gemini tạo báo cáo',prefix+'summary')
    saved_result_ui('summary',state,prefix+'saved_summary')
    with st.expander('Công cụ dự phòng · bản nháp bằng quy tắc'):
        st.caption('Để thử PDF khi API chưa sẵn sàng: tạo bản nháp bằng quy tắc, ghi rõ không phải LLM. Không tự xác minh hoặc duyệt vay.')
        if st.button('Tạo bản nháp quy tắc · không dùng API',key=prefix+'rule_draft'):
            mutate(rule_draft,{})
    summary=state['phase3']['summary']
    if summary:
        saved=summary.get('mode')!='API_DIRECT'
        st.caption('Bản nháp bằng quy tắc Python · không phải LLM' if summary.get('mode')=='RULE_BASED' else ('Kết quả LLM đã lưu/nhập trước đó' if saved else 'Báo cáo từ lần gọi Gemini trực tiếp'))
        st.markdown('**Nội dung: '+('Đã kiểm tra' if state['phase3']['content_review'] else 'Bản nháp chưa kiểm tra')+' · '+state['phase3']['report_status']+'**')
        for key,label in [('overview','Tóm tắt hồ sơ'),('metric_explanations','Diễn giải chỉ số'),('limitations','Giới hạn'),('verification_questions','Câu hỏi cần xác minh')]:
            with st.expander(label,expanded=key in ['overview','verification_questions']):
                for row in summary['result'][key]:
                    st.write(row['text'])
                    with st.expander('Căn cứ: '+', '.join(row['refs'])):
                        for ref in row['refs']:
                            st.caption(ref)
                            if ref in state['sources']:source_view(state,ref,'summary_'+key+'_'+str(summary['result'][key].index(row)))
                            else:st.json(state['phase3']['context']['references'][ref])
        with st.form(prefix+'summary_review'):
            name=st.text_input('Người kiểm tra báo cáo');note=st.text_area('Ghi chú kiểm tra nội dung')
            facts=st.checkbox('Đã kiểm tra số liệu, nguồn, cảnh báo và thông tin thiếu.')
            limits=st.checkbox('Đã kiểm tra giới hạn và câu hỏi xác minh; đây không phải quyết định vay.')
            if st.form_submit_button('Xác nhận đã kiểm tra nội dung'):
                from phase3 import review_summary
                mutate(review_summary,{'reviewer':name,'reason':note,'checked_facts':facts,'checked_limits':limits})
        st.subheader('Tải bản báo cáo')
        st.caption('PDF giữ trạng thái bản nháp/đã kiểm tra, nguồn và giới hạn; không phải giấy duyệt vay.')
        st.download_button('Tải báo cáo PDF',pdf_bytes(copy.deepcopy(state)),cid+'_Credit_Review.pdf','application/pdf',type='primary')
        with st.expander('Tải TXT, ZIP và dữ liệu nâng cao'):
            st.download_button('Tải báo cáo TXT',report_text(state),cid+'_Credit_Review_Summary.txt')
            st.download_button('Tải ZIP báo cáo và hồ sơ',archive(state),cid+'_review.zip','application/zip')
            st.json(summary['result'])
    else:
        st.info('Chưa có báo cáo. Chạy Gemini, nhập kết quả LLM đã lưu hoặc tạo bản nháp quy tắc để thử PDF.')
        st.download_button('Tải báo cáo PDF',b'',cid+'_Credit_Review.pdf','application/pdf',disabled=True)
    st.button('Quay về tổng quan hồ sơ',on_click=go,args=('Tổng quan',))

elif page=='Bảo mật Excel':
    st.write('Chọn dữ liệu Excel, bấm xử lý rồi tải kết quả. Giữ nguyên năm và 12 trường tài chính; giữ mã doanh nghiệp cố định giữa các năm trong cùng phiên.')
    st.info('data_encrypted.xlsx chứa dữ liệu đã giả danh hóa, không phải toàn bộ file được mã hóa bằng mật khẩu. Phần này không gọi Gemini và không tính M-Score.')
    with st.expander('Xem bảng quy tắc đã chốt'):
        st.dataframe(rule_rows(),hide_index=True,width='stretch')
    deployed=Path(os.environ.get('CREDITCHECK_DEPLOY_ROOT',str(ROOT)))/'data_raw.xlsx'
    source=st.radio('Nguồn dữ liệu Excel',['Tải file từ máy','data_raw.xlsx trên GitHub'],key='_excel_source')
    upload=st.file_uploader('Chọn data_raw.xlsx',type=['xlsx'],key='_excel_upload',disabled=source!='Tải file từ máy')
    if source=='data_raw.xlsx trên GitHub':
        if deployed.exists():st.caption('Đã tìm thấy data_raw.xlsx cạnh file khởi chạy. Bấm xử lý để dùng file này.')
        else:st.warning('Chưa thấy data_raw.xlsx cạnh file khởi chạy. Chọn Tải file từ máy để dùng file của ní.')
    if st.button('Xử lý bảo mật Excel',type='primary'):
        try:
            if source=='Tải file từ máy':
                if upload is None:raise ValueError('Chọn file Excel trước khi xử lý.')
                data=upload.getvalue()
            else:
                if not deployed.exists():raise ValueError('Chưa có data_raw.xlsx trong thư mục triển khai.')
                if deployed.stat().st_size>10*1024*1024:raise ValueError('File Excel tối đa 10 MB.')
                data=deployed.read_bytes()
            with st.spinner('Đang giả danh hóa và kiểm tra số liệu…'):
                result=protect_excel(data,encryption_key(),st.session_state.get('_excel_staff_map'))
            result['source_hash']=hashlib.sha256(data).hexdigest()
            result['source_choice']=source
            st.session_state['_excel_staff_map']=result.pop('staff_map')
            st.session_state['_excel_result']=result
            st.success('Đã xử lý. Năm và số liệu tài chính giữ nguyên; có thể tải file kết quả.')
        except (ValueError,TypeError,KeyError) as exc:
            st.session_state.pop('_excel_result',None)
            st.error(str(exc))
    result=st.session_state.get('_excel_result')
    # Do not display an old download as the result of a newly selected file.
    current_hash=(hashlib.sha256(upload.getvalue()).hexdigest() if upload is not None else None) if source=='Tải file từ máy' else (hashlib.sha256(deployed.read_bytes()).hexdigest() if deployed.exists() and deployed.stat().st_size<=10*1024*1024 else None)
    if result and result['source_hash']==current_hash and result['source_choice']==source:
        cols=st.columns(3)
        cols[0].metric('Dòng dữ liệu',result['row_count'])
        cols[1].metric('Cột sau xử lý',len(result['headers']))
        cols[2].metric('Doanh nghiệp',result['company_count'])
        st.download_button('Tải data_encrypted.xlsx',result['data'],'data_encrypted.xlsx',
                           'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',type='primary')
        st.subheader('Xem trước dữ liệu sau xử lý')
        st.dataframe(pd.DataFrame(result['rows'][:20],columns=result['headers']),hide_index=True,width='stretch')
        st.caption('Bỏ Ngành, Địa chỉ, Người đại diện; tên phụ trách thành STAFF_001…; tên doanh nghiệp và mã chứng khoán cùng dùng COMP_<HMAC>.')
    elif result:
        st.info('Nguồn đã đổi. Bấm Xử lý bảo mật Excel để tạo kết quả cho file đang chọn.')
    st.caption('Mã giả danh ổn định trong phiên này. Tải lại web tạo khóa mới và mã mới; dùng script offline với khóa riêng nếu cần liên kết giữa nhiều phiên. Không tự gộp doanh nghiệp đổi mã hoặc nhân viên trùng tên.')

else:
    st.write('Hỏi về cảnh báo, dữ liệu còn thiếu hoặc cách tính của '+cid+'. Trợ lý không sửa dữ liệu hay xác nhận thay bạn.')
    consent=st.checkbox('Đồng ý gửi câu hỏi và ngữ cảnh hồ sơ giả lập đến Gemini.',key=prefix+'chat_consent')
    if st.button('Xóa lịch sử chat của phiên'):
        st.session_state.messages=[];st.rerun()
    for entry in st.session_state.messages:
        with st.chat_message('user'):st.text(entry['question'])
        with st.chat_message('assistant'):
            for row in entry['answer']:st.text(row['text']);st.caption('Căn cứ: '+', '.join(row['refs']))
            with st.expander('Mở dữ liệu tham chiếu'):st.json(entry['references'])
    question=st.chat_input('Ví dụ: Vì sao hồ sơ này có cảnh báo?',disabled=not consent)
    if question:
        try:
            client=reserve_call()
            with st.spinner('Gemini đang giải thích…'):entry=chat(state,question,st.session_state.messages,client)
            st.session_state.messages=(st.session_state.messages+[entry])[-20:];st.rerun()
        except (ValueError,TypeError,KeyError) as exc:st.error(str(exc))

footer()
floating_assistant(st.session_state.dossier,page,reserve_call,go)



# Run after page content is rendered; widgets on the same page keep their position.
scroll_on_page_change(page)

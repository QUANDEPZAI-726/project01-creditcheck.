import unittest
from pathlib import Path
from streamlit.testing.v1 import AppTest
ROOT=Path(__file__).resolve().parents[1]

class WorkflowRedesignTests(unittest.TestCase):
    def test_step_progress_reflects_restored_review_not_open_page(self):
        app=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
        app.session_state['page']='1 · Hồ sơ';app.run(timeout=30)
        self.assertFalse(app.exception)
        before='\n'.join(c.value for c in app.caption)
        self.assertIn('✓ Đủ ba nguồn tài liệu',before)
        self.assertIn('Cần kiểm tra & xác minh',before)
        self.assertNotIn('✓ Đã kiểm tra nội dung',before)
        next(b for b in app.button if b.label=='Khôi phục HS01 đã kiểm tra · kết quả lưu v0.4').click().run(timeout=30)
        self.assertFalse(app.exception)
        after='\n'.join(c.value for c in app.caption)
        for text in ['✓ Đã đối chiếu và xác minh','✓ Đã có đủ chỉ số','✓ Đã kiểm tra nội dung']:
            self.assertIn(text,after)

    def test_classification_cannot_run_before_review_and_home_is_read_only(self):
        app=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
        self.assertTrue((ROOT/'assets/HS01_report_preview.pdf').read_bytes().startswith(b'%PDF'))
        self.assertTrue(any(x.value=='Bạn sẽ nhận được gì?' for x in app.subheader))
        self.assertEqual(app.session_state['dossier']['extraction_review']['status'],'Pending')
        app.session_state['page']='2 · Kiểm tra';app.run(timeout=30)
        button=next(b for b in app.button if b.label=='Chạy Gemini phân loại')
        self.assertTrue(button.disabled)
        self.assertFalse(app.exception)

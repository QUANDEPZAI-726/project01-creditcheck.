"""Shared grounded conversation, consent and errors for full page and drawer."""
import streamlit as st
from gemini_service import chat
from experience import case_context, connection_caption, error_guidance, record_api_success

SUGGESTIONS=[('Tôi làm gì tiếp?','Tôi cần làm gì tiếp theo ở bước hiện tại? Nêu dữ liệu còn thiếu và bước con người cần kiểm tra.'),
 ('Giải thích cảnh báo','Giải thích cảnh báo của hồ sơ hiện tại, nêu căn cứ và điều cần xác minh.'),
 ('DTI tính thế nào?','DTI của hồ sơ hiện tại được tính từ những số nào? Nếu chưa tính được, giải thích thông tin còn thiếu.')]

def set_open(opened):st.session_state['_cc_chat_open']=opened

def fill_question(question):st.session_state['_cc_drawer_question']=question

def open_full(go):
    set_open(False);go('Trợ lý hồ sơ')

def save_consent(cid,key):
    st.session_state.setdefault('_cc_drawer_consents',{})[cid]=bool(st.session_state[key])

def clear_history():
    st.session_state.messages=[]
    st.session_state.pop('_cc_chat_error',None)

def conversation_setup(state):
    cid=state['case']['case_id']
    if st.session_state.get('_cc_drawer_case')!=cid:
        st.session_state['_cc_drawer_question']=''
        st.session_state['_cc_drawer_case']=cid
        st.session_state.pop('_cc_chat_error',None)
    if st.session_state.pop('_cc_clear_drawer_question',False):st.session_state['_cc_drawer_question']=''
    return cid

def consent_and_connection(cid):
    consents=st.session_state.setdefault('_cc_drawer_consents',{})
    key='cc_drawer_consent_'+cid
    st.session_state[key]=consents.get(cid,False)
    consent=st.checkbox('Đồng ý gửi câu hỏi và ngữ cảnh hồ sơ giả lập đến Gemini.',key=key,on_change=save_consent,args=(cid,key))
    consents[cid]=consent
    status=connection_caption()
    ready=status.startswith('API đã') or status.startswith('Đã lưu')
    if not ready:st.caption('Mở Gemini trên đầu trang để nhập key và model. '+status+'.')
    elif not consent:st.caption('Tích đồng ý để gửi câu hỏi; chỉ bấm Gửi mới gọi Gemini.')
    return consent and ready

def suggestions(drawer=True):
    if not st.session_state.messages:
        with st.container(key='cc_chat_suggestions'):
            for i,(label,question) in enumerate(SUGGESTIONS):
                st.button(label,type='tertiary',key='cc_chat_suggest_'+str(i),on_click=fill_question,args=(question,))

def history():
    for entry in st.session_state.messages:
        with st.chat_message('user'):st.text(entry['question'])
        with st.chat_message('assistant'):
            for row in entry['answer']:
                st.write(row['text']);st.caption('Căn cứ: '+', '.join(row['refs']))
            with st.expander('Mở dữ liệu tham chiếu'):st.json(entry['references'])

def send_question(state,page,question,reserve_call):
    if not question.strip():st.warning('Nhập câu hỏi trước khi gửi.');return
    try:
        client=reserve_call()
        with st.spinner('Gemini đang giải thích…'):
            entry=chat(state,question.strip(),st.session_state.messages,client,page=page)
        st.session_state.messages=(st.session_state.messages+[entry])[-20:]
        record_api_success(client)
        st.session_state.pop('_cc_chat_error',None)
        st.session_state['_cc_clear_drawer_question']=True
        st.rerun()
    except (ValueError,TypeError,KeyError) as exc:
        st.session_state['_cc_chat_error']=str(exc)
        title,hint=error_guidance(exc);st.error(title);st.caption(hint)

def error_note():
    error=st.session_state.get('_cc_chat_error')
    if error:
        title,hint=error_guidance(error);st.error(title);st.caption(hint)

def onboarding_help(go,drawer=False):
    st.caption('Chưa có hồ sơ · Hướng dẫn có sẵn, không gọi Gemini và không dùng dữ liệu HS01.')
    topic=st.selectbox('Bạn cần hướng dẫn gì?',[
        'Bắt đầu từ đâu?', 'Cần tải những tài liệu nào?', 'Kết nối Gemini thế nào?', 'Mã hóa hồ sơ ở đâu?'],
        key='cc_help_topic_drawer' if drawer else 'cc_help_topic_full')
    answers={
        'Bắt đầu từ đâu?':'Mở Tiếp nhận tài liệu, tải nguồn hoặc chủ động chọn hồ sơ mẫu. Xem bảng đối chiếu và cảnh báo rồi xác nhận tiếp nhận để vào bốn bước.',
        'Cần tải những tài liệu nào?':'Ba nguồn: đơn vay PDF có chữ, xác nhận thu nhập PDF có chữ và sao kê CSV theo mẫu. Có bộ ba tài liệu mẫu để tải ngay trong phần Tiếp nhận.',
        'Kết nối Gemini thế nào?':'Mở Gemini trên đầu trang, nhập API key và tên model rồi Lưu kết nối. Khi có hồ sơ, đồng ý gửi ngữ cảnh và bấm Gửi để hỏi. Lưu cấu hình chưa có nghĩa API đã gọi thành công.',
        'Mã hóa hồ sơ ở đâu?':'Tại Tiếp nhận tài liệu, ứng dụng tạo bản đầu vào mã hóa trong phiên trước khi đọc. Mở Mã hóa hồ sơ để xuất tệp .ccenc có mật khẩu; xử lý vẫn cần bản rõ trong bộ nhớ.'}
    st.write(answers[topic])
    st.button('Đến tiếp nhận tài liệu',on_click=go,args=('Tiếp nhận tài liệu',),
              key='cc_help_intake_drawer' if drawer else 'cc_help_intake_full',type='primary')
    st.caption('Chat theo dữ liệu hồ sơ sẽ khả dụng ngay sau khi nhận tài liệu hoặc chọn mẫu; không cần chờ xác nhận tiếp nhận.')

def full_assistant(state,page,reserve_call,go):
    if state is None:
        with st.container(key='cc_full_chat'):onboarding_help(go)
        return
    cid=conversation_setup(state)
    with st.container(key='cc_full_chat'):
        st.markdown(case_context(state),unsafe_allow_html=True)
        st.caption('Hỏi về chỉ số, nguồn và thông tin còn thiếu. Trợ lý không sửa dữ liệu hay xác nhận thay bạn.')
        ready=consent_and_connection(cid)
        suggestions(False)
        with st.container(height=360,border=False):
            if st.session_state.messages:history()
            else:st.write('Hội thoại sẽ xuất hiện ở đây. Chọn câu hỏi gợi ý hoặc nhập câu hỏi bên dưới.')
        error_note()
        if st.session_state.get('_cc_drawer_question'):
            with st.form('cc_full_suggested_form'):
                question=st.text_area('Câu hỏi của bạn',key='_cc_drawer_question',height=90,max_chars=2000)
                submitted=st.form_submit_button('Thử lại câu hỏi' if st.session_state.get('_cc_chat_error') else 'Gửi câu hỏi',type='primary',disabled=not ready)
            if submitted:send_question(state,page,question,reserve_call)
        question=st.chat_input('Hỏi về hồ sơ '+cid+'…',disabled=not ready,max_chars=2000,key='cc_full_input')
        if question:
            st.session_state['_cc_drawer_question']=question
            send_question(state,page,question,reserve_call)
        with st.expander('Tùy chọn hội thoại'):
            st.caption('Lịch sử dùng chung với trợ lý nổi, tối đa 20 lượt; đổi hồ sơ sẽ bắt đầu hội thoại riêng.')
            st.button('Xóa lịch sử chat của phiên',on_click=clear_history,key='cc_full_clear',type='tertiary')

def floating_assistant(state,page,reserve_call,go):
    if page=='Trợ lý hồ sơ':return
    if not st.session_state.get('_cc_chat_open',False):
        with st.container(key='cc_chat_launcher'):
            st.button('Hỏi trợ lý',icon=':material/chat_bubble_outline:',on_click=set_open,args=(True,),key='cc_chat_open',type='primary',help='Hỏi về hồ sơ đang mở mà không rời bước hiện tại')
        return
    cid=conversation_setup(state) if state else None
    with st.container(key='cc_chat_drawer'):
        with st.container(key='cc_chat_drawer_head'):
            title,close=st.columns([4,1],vertical_alignment='center')
            with title:
                st.markdown('**Trợ lý CreditCheck**');st.caption('Đang đọc hồ sơ '+cid if cid else 'Hướng dẫn bắt đầu')
            with close:st.button('Đóng',on_click=set_open,args=(False,),key='cc_chat_close',type='tertiary')
        if state is None:
            onboarding_help(go,drawer=True)
            st.button('Mở rộng',type='tertiary',on_click=open_full,args=(go,),key='cc_chat_wide')
            return
        if not state.get('_intake_checked'):st.caption('Hồ sơ mới tiếp nhận · chưa xác nhận đối chiếu; trợ lý không xác minh thay bạn.')
        if page=='Bảo mật Excel':st.caption('Chỉ đọc hồ sơ vay '+cid+' · Không đọc file Excel trên trang này.')
        ready=consent_and_connection(cid)
        suggestions()
        with st.container(height=220,border=False,key='cc_chat_drawer_history'):
            if st.session_state.messages:history()
            else:st.caption('Hỏi về nguồn, cảnh báo hoặc DTI. Trợ lý không xác nhận thay bạn.')
        error_note()
        with st.container(horizontal=True,gap='small'):
            st.button('Mở rộng',type='tertiary',on_click=open_full,args=(go,),key='cc_chat_wide')
            with st.popover('Tùy chọn'):
                st.button('Xóa hội thoại',type='tertiary',on_click=clear_history,key='cc_chat_clear')
        with st.form('cc_drawer_form'):
            question=st.text_area('Câu hỏi của bạn',key='_cc_drawer_question',height=80,max_chars=2000,placeholder='Ví dụ: Hồ sơ này còn thiếu gì?')
            submitted=st.form_submit_button('Thử lại câu hỏi' if st.session_state.get('_cc_chat_error') else 'Gửi câu hỏi',type='primary',disabled=not ready)
        if submitted:send_question(state,page,question,reserve_call)

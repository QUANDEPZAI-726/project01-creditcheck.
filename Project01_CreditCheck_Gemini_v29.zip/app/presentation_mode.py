"""Explicit saved-result presentation path. Never calls a network API or approves a loan."""
import copy
import json
from pathlib import Path
from core import ensure, now
from phase2 import import_classification
from phase3 import template, import_summary, context
from traceability import sync

ROOT=Path(__file__).resolve().parents[1]
MODE='PREPARED_AI'

# Explanatory prose authored by ChatGPT for these synthetic scenarios.
# Financial values, flags, context hashes and human reviews are supplied by Python, not this prose.
NOTES={
 'HS01':('Ba nguồn của tình huống cơ sở dùng để đối chiếu thông tin khai báo, xác nhận thu nhập và giao dịch tài khoản. Không có cảnh báo từ các quy tắc hiện tại không chứng minh hồ sơ an toàn hay đủ điều kiện vay.',
         'Nghĩa vụ trả nợ hiện tại đã bao gồm mọi khoản vay và thẻ tín dụng chưa, và cần nguồn độc lập nào để xác minh?'),
 'HS02':('Hồ sơ thiếu sao kê nên chưa có nguồn giao dịch để kiểm tra dòng tiền và xác minh thu nhập. Không được lấy thu nhập khai báo thay cho thu nhập sao kê đã xác minh.',
         'Cần bổ sung sao kê của đúng người vay trong kỳ nào, và tài liệu nào xác nhận kỳ sao kê đầy đủ?'),
 'HS03':('Thu nhập trên đơn và nguồn xác nhận không thống nhất. Cần giữ cả hai giá trị, đối chiếu nguồn lương trên sao kê và giải thích chênh lệch trước khi sử dụng số liệu.',
         'Vì sao thu nhập khai báo khác nguồn đối chiếu; có thu nhập bổ sung hợp lệ hay tài liệu cần bổ sung không?'),
 'HS04':('Mã người vay và mã chủ tài khoản không thống nhất. Việc một giao dịch được gắn nhãn lương không chứng minh tài khoản thuộc người vay; cần nguồn đúng trước khi xác minh thu nhập.',
         'Sao kê thuộc ai, mã định danh nào cần đối chiếu, và có thể cung cấp sao kê đúng chủ tài khoản không?'),
 'HS05':('Một số khoản tiền từ cá nhân ghi nội dung thu nhập tháng nhưng chưa đủ căn cứ xác định là lương. Cần giữ nhãn chưa rõ; không cộng chúng vào thu nhập chỉ vì là tiền vào.',
         'Các khoản tiền từ cá nhân là lương, hoàn tiền, vay mượn hay khoản chuyển khác; cần chứng từ nào để xác minh?'),
 'HS06':('Hồ sơ mới cần đối chiếu thu nhập trong PDF với nguồn lương trên sao kê. Khoản hoàn tiền mua hàng không phải thu nhập lương; các khác biệt phải giữ để người kiểm tra xem xét.',
         'Vì sao thu nhập trong PDF khác dòng lương sao kê, và cần thêm chứng từ nào để xác minh phần chênh lệch?'),
}

def checked_reference(state):
    manifest=json.loads((ROOT/'prepared/reference_manifest.json').read_text())
    cid=state['case']['case_id']
    ensure(cid in manifest,'Chưa có kết quả chuẩn bị cho hồ sơ này. Dùng prompt và nhập kết quả ChatGPT bên ngoài; không mượn kết quả của hồ sơ khác.')
    expected=manifest[cid]
    hashes={did:src['sha256'] for did,src in state['sources'].items()}
    fields={d['document_id']:d['fields'] for d in state['case']['documents'] if d['available'] and d['source_type']!='bank_statement'}
    ensure(hashes==expected['sources'] and fields==expected['fields'],
           'Nguồn hoặc trường dữ liệu đã khác bộ chuẩn bị. Không áp dụng kết quả cũ; tải prompt hiện tại và nhập kết quả LLM mới.')
    return expected

def prepared_task(state,task):
    ensure(task in ('classification','summary'),'Trích xuất đầu vào vẫn do Python hoặc kết quả LLM bạn nhập; không có lần gọi API tự động.')
    checked_reference(state)
    s=copy.deepcopy(state);cid=s['case']['case_id']
    if task=='classification':
        ensure(s['extraction_review']['status']=='Reviewed','Đối chiếu nguồn và xác nhận trích xuất trước khi nạp nhãn đã lưu.')
        path=ROOT/'incoming'/f'{cid}_classification.json'
        ensure(path.exists(),'Hồ sơ này chưa có sao kê/phân loại chuẩn bị. Bổ sung nguồn; không tự tạo giao dịch.')
        obj=json.loads(path.read_text())
        import_classification(s,{'expected_version':s['version'],'result':obj,
            'model':'ChatGPT · ứng viên phân loại đã lưu, đã đối chiếu trong phiên chuẩn bị','attest':True})
        s['phase2']['classification'].update(mode=MODE,provenance='saved_classification_not_live_api')
        text_origin='saved_classification'
    else:
        sync(s)
        if s['phase2']['classification']:
            path=ROOT/'incoming'/f'{cid}_classification.json'
            ensure(path.exists(),'Chưa có nhãn chuẩn bị phù hợp.')
            original=json.loads(path.read_text())
            expected={r['transaction_id']:r['label'] for r in original['transactions']}
            actual={r['transaction_id']:r['label'] for r in s['phase2']['classification']['rows']}
            ensure(actual==expected,'Nhãn đã đổi so với tình huống chuẩn bị. Dùng báo cáo LLM mới hoặc bản nháp quy tắc có nhãn rõ.')
        obj=template(s);ctx=context(s)
        note,question=NOTES[cid]
        obj['overview']=[{'text':note,'refs':['CASE','SCOPE']}]
        obj['metric_explanations']=[{'text':
            'Python tính khoản trả góp theo gốc vay, kỳ hạn và giả định lãi suất. DTI bằng tổng trả nợ hiện tại mỗi tháng cộng trả góp mới, chia thu nhập đã được người dùng xác minh. Độ lệch thu nhập dùng thu nhập đã xác minh làm mẫu số. Số hiện tại nằm trong bảng chỉ số; ngưỡng bài tập không phải chính sách ngân hàng.'
            if ctx['metrics_available'] else
            'Chưa có đủ điều kiện tính chỉ số chính thức. Không thay ô trống bằng không, không lấy thu nhập khai báo để ước tính DTI và không bỏ qua bước xác minh nguồn thu.',
            'refs':['METRICS','CONFIG'] if ctx['metrics_available'] else ['PENDING_METRICS','SCOPE']}]
        obj['limitations']=[{'text':'Diễn giải này do ChatGPT chuẩn bị trước; Python ghép thông tin, số liệu và cảnh báo hiện tại. Không có lần gọi AI mới khi nạp bản này. Người kiểm tra vẫn phải đọc nguồn và kiểm duyệt. Chưa xác minh độc lập danh tính, tài liệu hoặc nghĩa vụ nợ; phép tính chưa gồm phí và bảo hiểm, không phải quyết định tín dụng.','refs':['SCOPE','REVIEW','CONFIG']}]
        obj['verification_questions']=[{'text':question,'refs':['CASE','SCOPE']},
            {'text':'Người thẩm định cần kiểm tra tính xác thực của nguồn, tính liên tục của thu nhập, nghĩa vụ nợ và điều kiện khoản vay bằng những bằng chứng độc lập nào?','refs':['CASE','REVIEW','SCOPE']}]
        import_summary(s,{'expected_version':s['version'],'result':obj,
            'model':'ChatGPT · diễn giải chuẩn bị trước + dữ liệu hiện tại do Python ghép','attest':True})
        s['phase3']['summary'].update(mode=MODE,provenance='prepared_chatgpt_text_plus_current_python_facts')
        text_origin='prepared_chatgpt_narrative_plus_python_template'
    s['llm_runs'][-1].update(mode=MODE,provenance=text_origin,live_api=False,
        note='Kết quả chuẩn bị trước; không gọi Gemini/ChatGPT mới trong ứng dụng. Không tự xác nhận của con người.')
    action='IMPORT_CLASSIFICATION' if task=='classification' else 'IMPORT_SUMMARY'
    event=next(e for e in reversed(s['events']) if e.get('action')==action)
    event.update(provenance=text_origin,live_api=False)
    sync(s)
    return s

def local_guide(state,question,page):
    """Limited deterministic help; explicitly not a fresh LLM answer."""
    sync(state);ctx=context(state);q=question.casefold();m=state['phase2']['metrics']
    if any(k in q for k in ['duyệt','từ chối','phê duyệt']):
        text='Hệ thống không quyết định duyệt hoặc từ chối vay. Xác nhận nội dung báo cáo không thay thế người thẩm định và không xác minh danh tính.';refs=['SCOPE','REVIEW']
    elif any(k in q for k in ['dti','chỉ số','tính thế','tính sao']):
        if m['dti_pct'] is None:
            text='DTI chưa được tính. Cần đủ nguồn, đối chiếu trích xuất, phân loại giao dịch và xác minh thu nhập trước. Không dùng thu nhập khai báo thay mẫu số đã xác minh.';refs=['PENDING_METRICS','REVIEW']
        else:
            f=lambda v:f'{v:,.0f}'.replace(',','.')
            debt=ctx['key_information']['existing_monthly_debt_vnd']
            text=f"Python đang ghi nhận DTI {m['dti_pct']:.2f}%, từ trả nợ hiện tại {f(debt)} đồng/tháng cộng trả góp mới {f(m['monthly_payment_vnd'])} đồng/tháng, chia thu nhập đã xác minh {f(m['validated_monthly_income_vnd'])} đồng/tháng. Python dùng số chưa làm tròn để tính; số trên màn hình đã làm tròn. Đây không phải quyết định vay.";refs=['METRICS','CONFIG','SCOPE']
    elif any(k in q for k in ['cảnh báo','rủi ro','thiếu']):
        flags=ctx['risk_flags']
        text='; '.join(f['message'] for f in flags) if flags else 'Chưa phát hiện cảnh báo từ các phép kiểm tra hiện tại. Điều này không chứng minh đầy đủ hoặc an toàn; cần xem trạng thái xác minh.'
        refs=list(dict.fromkeys('FLAG:'+f['code'] for f in flags))[:4]+['SCOPE']
    elif any(k in q for k in ['nguồn','tài liệu','căn cứ']):
        text='Nguồn đã nhận: '+', '.join(d['document_id'] for d in state['case']['documents'] if d['available'])+'. Mở từng trường và căn cứ để đối chiếu; thiếu tài liệu không có nghĩa được tự tạo trích dẫn.'
        refs=['CASE','SCOPE']
    elif any(k in q for k in ['tiếp','làm gì','bước']):
        if not state.get('_intake_checked'):text='Xem ba nguồn và cảnh báo ban đầu, xác nhận đã xem để vào bước Tổng hợp hồ sơ.'
        elif state['extraction_review']['status']!='Reviewed':text='Sang bước Kiểm tra, đối chiếu các trường với tài liệu nguồn rồi xác nhận trích xuất.'
        elif state['phase2']['classification'] is None:text='Nạp ứng viên phân loại đã lưu hoặc nhập kết quả LLM mới, rồi đối chiếu nhãn giao dịch.'
        elif not state['phase2']['income_review']:text='Kiểm tra nhãn, chủ tài khoản và kỳ sao kê. Chỉ xác minh thu nhập khi đủ căn cứ; xử lý phần thiếu hoặc chưa rõ trước.'
        elif not state['phase3']['summary']:text='Xem các chỉ số và căn cứ cảnh báo, rồi nạp bản tóm tắt để kiểm tra nội dung.'
        else:text='Đọc số liệu, nguồn, cảnh báo và giới hạn của báo cáo. Xác nhận sau khi đã kiểm tra rồi tải PDF/TXT/ZIP; chưa phải quyết định vay.'
        refs=['CASE','REVIEW','SCOPE']
    else:
        text='Đây là hướng dẫn cục bộ theo chủ đề, không phải LLM đang suy luận. Hãy hỏi về DTI, cảnh báo, nguồn hoặc bước tiếp theo. Với câu hỏi mở, dùng prompt ChatGPT bên ngoài ở trang Trợ lý đầy đủ hoặc bật Gemini trực tiếp.';refs=['SCOPE']
    return {'question':question,'answer':[{'text':text,'refs':refs}],'context_hash':ctx['context_hash'],
        'references':{r:ctx['references'][r] for r in refs},
        'api':{'mode':'LOCAL_GUIDANCE','model':'Hướng dẫn quy tắc Python, không gọi AI','live_api':False,'at':now(),'page':page}}

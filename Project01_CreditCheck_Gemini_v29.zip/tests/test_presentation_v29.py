import copy,io,json,sys,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
from streamlit.testing.v1 import AppTest
from pypdf import PdfReader
from ui_test_tools import choose_sample,navigate
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'app'))
from sample_data import load_sample
from core import make_state
from phase2 import review_extraction_phase2,verify_income,edit_classification,set_rate
from phase3 import report_text
from presentation_mode import prepared_task,local_guide
from pdf_report import pdf_bytes

def review(s):
    review_extraction_phase2(s,{'expected_version':s['version'],'checked':True,'reviewer':'OFFLINE TEST','reason':'Synthetic source review only'})
def income(s):
    verify_income(s,{'expected_version':s['version'],'checked':True,'coverage_checked':True,'acknowledge_gap':True,'reviewer':'OFFLINE TEST','reason':'Synthetic income review only','coverage_start':'2026-07-01','coverage_end':'2026-09-30'})

class PreparedLogicTests(unittest.TestCase):
    def test_hs01_requires_review_and_never_auto_verifies(self):
        s=load_sample('HS01');before=copy.deepcopy(s)
        with self.assertRaises(ValueError):prepared_task(s,'classification')
        self.assertEqual(s,before)
        review(s);out=prepared_task(s,'classification')
        self.assertIsNone(out['phase2']['income_review'])
        self.assertTrue(all(v is None for v in out['phase2']['metrics'].values()))
        self.assertEqual(out['llm_runs'][-1]['live_api'],False)
        income(out);report=prepared_task(out,'summary')
        self.assertEqual(report['phase2']['metrics']['dti_pct'],33.54)
        self.assertIsNone(report['phase3']['content_review'])
        self.assertEqual(report['phase3']['summary']['mode'],'PREPARED_AI')
        text='\n'.join(p.extract_text() for p in PdfReader(io.BytesIO(pdf_bytes(report))).pages)
        self.assertIn('không gọi API mới',text)
        self.assertIn('33,54%',text)
        self.assertIn('chuẩn bị trước',report_text(report))

    def test_hs02_hs04_hs05_still_block_income(self):
        for cid in ['HS02','HS04','HS05']:
            s=load_sample(cid)
            if cid=='HS02':
                with self.assertRaises(ValueError):review(s)
            else:
                review(s);s=prepared_task(s,'classification')
                with self.assertRaises(ValueError):income(s)
            report=prepared_task(s,'summary')
            self.assertIsNone(report['phase2']['metrics']['dti_pct'])
            self.assertFalse(report['phase3']['summary']['result']['metrics']['dti_pct'])

    def test_hs03_flags_and_hs06_upload_match_current_sources(self):
        for cid in ['HS03','HS06']:
            if cid=='HS06':
                with zipfile.ZipFile(R/'prepared/HS06_3_NGUON_MOI.zip') as z:
                    s=make_state(cid,{'application':z.read('application.pdf'),'income_certificate':z.read('income_certificate.pdf'),'bank_statement':z.read('bank_statement.csv')})
            else:s=load_sample(cid)
            review(s);s=prepared_task(s,'classification');income(s);s=prepared_task(s,'summary')
            self.assertEqual(s['phase2']['metrics']['dti_pct'],50.31 if cid=='HS03' else 48.05)
            self.assertTrue({'HIGH_DTI','INCOME_MISMATCH'}<={a['code'] for a in s['traceability']['alerts']})

    def test_changed_source_fields_or_case_rejects_reference(self):
        for kind in ['source','field','case']:
            s=load_sample('HS01')
            if kind=='source':s['sources']['HS01-APP']['sha256']='wrong'
            elif kind=='field':s['case']['documents'][0]['fields']['full_name']['value']='Changed'
            else:s['case']['case_id']='UNKNOWN'
            before=copy.deepcopy(s)
            with self.assertRaises(ValueError):prepared_task(s,'summary')
            self.assertEqual(s,before)

    def test_changed_labels_reject_report_but_rate_uses_current_python_values(self):
        s=load_sample('HS01');review(s);s=prepared_task(s,'classification');income(s)
        set_rate(s,{'expected_version':s['version'],'annual_nominal_rate':0,'reviewer':'TEST','reason':'Zero rate boundary'})
        out=prepared_task(s,'summary')
        self.assertEqual(out['phase3']['summary']['result']['metrics']['monthly_payment_vnd'],4166667)
        edit_classification(s,{'expected_version':s['version'],'transaction_id':'HS01-T0701','label':'other','reviewer':'TEST','reason':'Synthetic label change test'})
        with self.assertRaises(ValueError):prepared_task(s,'summary')

    def test_local_guide_is_read_only_and_clearly_not_live_ai(self):
        s=load_sample('HS01');before=copy.deepcopy(s)
        out=local_guide(s,'DTI tính thế nào?','Tiếp nhận tài liệu')
        self.assertIn('chưa được tính',out['answer'][0]['text'])
        self.assertEqual(out['api']['mode'],'LOCAL_GUIDANCE')
        # Sync is idempotent and does not create human reviews or fake API runs.
        self.assertIsNone(s['phase2']['income_review'])
        self.assertEqual(s['llm_runs'],before['llm_runs'])
        self.assertIn('không phải LLM',local_guide(s,'Xin chào','Trang chủ')['answer'][0]['text'])

class PreparedUITests(unittest.TestCase):
    def start(self):
        a=AppTest.from_file(str(R/'streamlit_app.py')).run(timeout=30)
        next(b for b in a.button if b.key=='presentation_start').click().run(timeout=30)
        self.assertFalse(a.exception,[e.message for e in a.exception])
        self.assertIsNone(a.session_state['dossier'])
        choose_sample(a)
        return a

    def test_full_hs01_human_forms_without_api_and_local_assistant(self):
        with patch('gemini_service.GeminiClient.generate') as api,patch('gemini_service.GeminiClient.available_models') as models:
            a=self.start();navigate(a,'2 · Kiểm tra')
            self.assertTrue(next(b for b in a.button if b.label=='Nạp phân loại đã chuẩn bị').disabled)
            next(x for x in a.text_input if x.label=='Người kiểm tra').set_value('TEST')
            next(x for x in a.text_area if x.label=='Ghi chú đối chiếu nguồn').set_value('Checked synthetic PDF source')
            next(x for x in a.checkbox if x.label=='Tôi đã đối chiếu các trường với tài liệu nguồn.').check()
            next(b for b in a.button if b.label=='Xác nhận phần trích xuất').click().run(timeout=30)
            next(x for x in a.checkbox if (x.key or '').endswith('_prepared_ack')).check().run(timeout=30)
            next(b for b in a.button if b.label=='Nạp phân loại đã chuẩn bị').click().run(timeout=30)
            self.assertFalse(a.exception,[e.message for e in a.exception]);self.assertFalse(a.error,[e.value for e in a.error])
            self.assertIsNone(a.session_state['dossier']['phase2']['income_review'])
            next(x for x in a.text_input if x.label=='Người xác minh thu nhập').set_value('TEST')
            next(x for x in a.text_area if x.label.startswith('Ghi chú xác minh')).set_value('Checked three full synthetic months')
            next(x for x in a.checkbox if x.label=='Đã đối chiếu nhãn và nguồn trả lương.').check()
            next(x for x in a.checkbox if x.label=='Đã kiểm tra kỳ sao kê đầy đủ.').check()
            next(b for b in a.button if b.label=='Xác minh thu nhập và tính chỉ số').click().run(timeout=30)
            self.assertFalse(a.error,[e.value for e in a.error])
            self.assertEqual(a.session_state['dossier']['phase2']['metrics']['dti_pct'],33.54)
            navigate(a,'4 · Báo cáo')
            next(x for x in a.checkbox if (x.key or '').endswith('_prepared_ack')).check().run(timeout=30)
            next(b for b in a.button if b.label=='Tạo báo cáo từ diễn giải chuẩn bị + số liệu hiện tại').click().run(timeout=30)
            self.assertFalse(a.exception,[e.message for e in a.exception]);self.assertFalse(a.error,[e.value for e in a.error])
            self.assertIsNone(a.session_state['dossier']['phase3']['content_review'])
            self.assertTrue(any(b.proto.label=='Tải báo cáo PDF' for b in a.get('download_button')))
            next(x for x in a.text_input if x.label=='Người kiểm tra báo cáo').set_value('TEST')
            next(x for x in a.text_area if x.label=='Ghi chú kiểm tra nội dung').set_value('Reviewed current figures, sources and limitations')
            next(x for x in a.checkbox if x.label=='Đã kiểm tra số liệu, nguồn, cảnh báo và thông tin thiếu.').check()
            next(x for x in a.checkbox if x.label=='Đã kiểm tra giới hạn và câu hỏi xác minh; đây không phải quyết định vay.').check()
            next(b for b in a.button if b.label=='Xác nhận đã kiểm tra nội dung').click().run(timeout=30)
            self.assertFalse(a.error,[e.value for e in a.error])
            self.assertIsNotNone(a.session_state['dossier']['phase3']['content_review'])
            exported='\n'.join(p.extract_text() for p in PdfReader(io.BytesIO(pdf_bytes(a.session_state['dossier']))).pages)
            self.assertIn('không gọi API mới',exported)
            self.assertIn('33,54%',exported)
            navigate(a,'Trợ lý hồ sơ')
            a.chat_input[0].set_value('DTI tính thế nào?').run(timeout=30)
            self.assertFalse(a.exception,[e.message for e in a.exception])
            self.assertEqual(a.session_state['messages'][-1]['api']['mode'],'LOCAL_GUIDANCE')
            api.assert_not_called();models.assert_not_called()
            self.assertNotIn('_api_success',a.session_state)

    def test_external_chat_uses_import_validation_and_exit_restores_api_gate(self):
        a=self.start();navigate(a,'Trợ lý hồ sơ')
        next(x for x in a.text_area if x.label=='Câu hỏi gửi ChatGPT bên ngoài').set_value('Hồ sơ còn thiếu gì?').run(timeout=30)
        next(x for x in a.text_area if x.label=='JSON trả lời nhận từ ChatGPT').set_value(json.dumps({'answer':[{'text':'Cần người kiểm tra đối chiếu và xác minh nguồn thu.','refs':['CASE','REVIEW']}]}))
        next(x for x in a.checkbox if x.label.startswith('Tôi đã nhận câu trả lời')).check()
        next(b for b in a.button if b.label=='Nhập câu trả lời ChatGPT').click().run(timeout=30)
        self.assertFalse(a.exception,[e.message for e in a.exception]);self.assertFalse(a.error,[e.value for e in a.error])
        self.assertEqual(a.session_state['messages'][-1]['api']['mode'],'EXTERNAL_CHATGPT')
        next(b for b in a.button if b.key=='presentation_exit').click().run(timeout=30)
        self.assertFalse(a.session_state['_presentation_mode'])
        self.assertTrue(a.chat_input[0].disabled)

if __name__=='__main__':unittest.main()

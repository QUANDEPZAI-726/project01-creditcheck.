"""Upload-first intake. No sample data is created until explicitly requested."""
import hashlib
import io
import json
import zipfile
from html import escape
import streamlit as st
from core import LABELS
from experience import CASE_LABELS, display_value, status_label
from phase2 import value

SOURCES=[('application','01','Đơn đề nghị vay','PDF văn bản','Khoản vay, kỳ hạn, thu nhập khai báo và trả nợ hiện tại.'),
         ('income_certificate','02','Xác nhận thu nhập','PDF văn bản','Nguồn độc lập để đối chiếu việc làm và thu nhập.'),
         ('bank_statement','03','Sao kê tài khoản','CSV giao dịch','Chủ tài khoản, dòng tiền và kỳ sao kê cần xác minh.')]

def normalized_rows(state):
    return [{'Trường':LABELS.get(k,k),'Giá trị':display_value(k,f['value']),
             'Tài liệu':d['document_id'],'Vị trí':'; '.join(e['locator'] for e in f.get('evidence',[])) or 'Chưa có căn cứ'}
            for d in state['case']['documents'] for k,f in d['fields'].items()]

def comparison_rows(state):
    rows=[]
    for field in ['borrower_id','full_name','employer','net_monthly_income_vnd','loan_principal_vnd','term_months','existing_monthly_debt_vnd']:
        a=value(state,field,'application');b=value(state,field,'income_certificate')
        bank='Chưa áp dụng'
        if field=='borrower_id':bank=', '.join(sorted({t['account_holder_id'] for t in state['case']['transactions']})) or 'Chưa có'
        if field=='net_monthly_income_vnd':
            v=state['phase2']['metrics']['validated_monthly_income_vnd']
            bank=display_value(field,v) if v is not None else 'Chưa xác minh nguồn thu'
        rows.append({'Thông tin':LABELS.get(field,field),'Đơn vay':display_value(field,a),
                     'Xác nhận thu nhập':display_value(field,b) if field not in ['loan_principal_vnd','term_months','existing_monthly_debt_vnd'] else 'Không áp dụng',
                     'Sao kê':bank})
    return rows

def sample_files(root):
    manifest=json.loads((root/'runtime/cases/HS01/manifest.json').read_text())
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        for d in manifest['documents']:
            if d['available']:z.write(root/'runtime/cases/HS01'/d['path'],d['path'])
        z.writestr('DOC_TOI_TRUOC.txt','Ba nguồn giả lập HS01. Nhập mã hồ sơ HS01 để khớp mã trong tài liệu. Giải nén rồi chọn từng tệp đúng loại. PDF cần văn bản; CSV UTF-8 giữ nguyên 7 cột. Không đổi mã trong dữ liệu chỉ để né cảnh báo.')
    return buf.getvalue()

def accept_intake(state,commit):
    state['_intake_checked']=True
    st.session_state.page='1 · Hồ sơ'
    commit(state)

def render_intake(state,root,protect,commit,load_sample,restore_demo,api_button,alerts,encryption_ui,go,open_case):
    st.markdown('<div class="cc-work-title"><div class="cc-section-label">TRƯỚC KHI RÀ SOÁT / TIẾP NHẬN</div><h1>Nhận tài liệu. Đối chiếu nguồn.</h1><p>Đọc ba nguồn, nhận diện phần thiếu và xem mâu thuẫn trước khi vào bốn bước.</p></div>',unsafe_allow_html=True)
    st.caption('Bản học tập: dùng tài liệu giả lập. Chưa có tài liệu thì chưa có hồ sơ; không tự điền thông tin HS01.')
    portfolio=st.session_state.get('portfolio',{})
    if portfolio:
        with st.expander('Mở lại hồ sơ trong phiên · giữ kết quả đã làm'):
            existing=st.selectbox('Hồ sơ đã tiếp nhận',list(portfolio),key='intake_resume_case')
            st.button('Tiếp tục hồ sơ đã chọn',on_click=open_case,args=(existing,),key='intake_resume_open')
            st.caption('Giữ các kết quả hiện có. Nút mở mẫu từ đầu bên dưới tạo lại mẫu và xóa kết quả cũ của cùng mã.')
    mode=st.radio('Nguồn hồ sơ',['Tài liệu của bạn','Hồ sơ mẫu giả lập'],horizontal=True,key='_intake_mode')
    pending=False
    if mode=='Tài liệu của bạn':
        with st.container(key='cc_intake_upload'):
            st.markdown('**A · Chọn tài liệu đầu vào**')
            st.caption('Sau khi máy chủ nhận tệp, ứng dụng tạo bản mã hóa AES-256-GCM trước khi đọc dữ liệu. Khi xử lý, bản rõ vẫn tồn tại trong bộ nhớ. Chỉ gửi Gemini khi bạn đồng ý và bấm chạy.')
            case_id=st.text_input('Mã hồ sơ trong tài liệu',value=state['case']['case_id'] if state else '',placeholder='Ví dụ: HS01 — cần khớp mã ghi trong PDF',key='intake_case_id')
            files={}
            for col,(role,n,title,kind,hint) in zip(st.columns(3,gap='medium'),SOURCES):
                with col,st.container(border=True,key='cc_intake_'+role):
                    st.markdown('<div class="cc-source-card"><span>'+n+' / '+kind+'</span><h3>'+title+'</h3><p>'+hint+'</p></div>',unsafe_allow_html=True)
                    f=st.file_uploader(title,type=['csv'] if role=='bank_statement' else ['pdf'],max_upload_size=4,key='intake_file_'+role)
                    if f:
                        files[role]=f.getvalue()
                        st.caption('Đã chọn: '+f.name+' · chưa tiếp nhận' )
                    else:st.caption('Chưa chọn tài liệu')
            st.caption('PDF có chữ, tối đa 10 trang / tệp; CSV theo mẫu 7 cột; tối đa 4 MB / tệp và 10 MB tổng. Chưa hỗ trợ PDF scan/ảnh hoặc mọi mẫu ngân hàng.')
            if state and files:
                active={src['role']:src['sha256'] for src in state['sources'].values()}
                pending=active!={role:hashlib.sha256(data).hexdigest() for role,data in files.items()} or case_id.strip()!=state['case']['case_id']
            if st.button('Tiếp nhận & đọc tài liệu',type='primary',disabled=not files.get('application') or not case_id.strip(),key='intake_receive'):
                try:
                    if sum(map(len,files.values()))>10*1024*1024:raise ValueError('Tổng tệp tối đa 10 MB.')
                    if state and state['case']['case_id']==case_id.strip() and not st.session_state.get('intake_replace_ack'):
                        raise ValueError('Đang có hồ sơ cùng mã. Tích xác nhận thay đầu vào bên dưới trước; các xác nhận và kết quả cũ sẽ được xóa.')
                    result=protect(case_id.strip(),files)
                    result['_source_kind']='upload'
                    result['_intake_checked']=False
                    commit(result)
                except (ValueError,TypeError,KeyError) as exc:st.error(str(exc))
            if state:st.checkbox('Tôi đồng ý thay đầu vào cùng mã và kiểm tra lại từ đầu.',key='intake_replace_ack')
            if not files.get('application'):st.caption('Cần ít nhất đơn vay để tiếp nhận. Có thể ghi nhận hồ sơ thiếu nguồn; bước tính toán sẽ yêu cầu bổ sung.')
            with st.expander('Tải ba tài liệu mẫu và xem định dạng hỗ trợ'):
                st.download_button('Tải bộ ba nguồn giả lập HS01',sample_files(root),'HS01_3_nguon.zip','application/zip',key='intake_templates')
                st.code('transaction_id,date,direction,amount_vnd,account_holder_id,counterparty,description',language=None)
                st.caption('CSV: direction là credit/debit; amount_vnd là số nguyên VND không có dấu phân cách; ngày YYYY-MM-DD. PDF theo nhãn mẫu được Python đọc tự động; PDF khác cần Gemini và đối chiếu thủ công.')
    else:
        st.info('Chỉ mở dữ liệu mẫu khi bạn bấm nút. Mẫu dùng để trình bày và thử các tình huống, không phải hồ sơ khách hàng đã tải lên.')
        choice=st.selectbox('Tình huống mẫu',list(CASE_LABELS),format_func=lambda c:CASE_LABELS[c],key='intake_sample_choice')
        st.button('Mở mẫu để thực hành từ đầu',on_click=load_sample,args=(choice,),key='intake_sample_load',type='primary')
        st.button('Xem kết quả mẫu đã lưu',on_click=restore_demo,key='restore_demo',type='tertiary',help='HS01 có xác nhận giả lập và báo cáo lưu sẵn; không gọi API mới.')
    if state:
        st.divider()
        cid=state['case']['case_id']
        st.subheader('B · Đối chiếu ban đầu · '+cid)
        if pending:st.warning('Các tệp vừa chọn chưa được tiếp nhận. Bảng dưới vẫn thuộc hồ sơ đã nhận trước đó. Bấm Tiếp nhận & đọc tài liệu để cập nhật rồi mới đi tiếp.')
        kind={'sample':'Hồ sơ mẫu giả lập','upload':'Tài liệu bạn đã tải','saved_demo':'Kết quả mẫu đã lưu'}.get(state.get('_source_kind'),'Hồ sơ đã nhập')
        st.caption(kind+' · '+status_label(state)+' · '+state['phase3']['report_status'])
        if st.session_state.get('notice'):st.success(st.session_state.pop('notice'))
        vault=st.session_state.get('_input_vault',{}).get(cid)
        if vault:st.success('Đã tạo bản mã hóa đầu vào AES-256-GCM trong phiên. Bảng bên dưới là dữ liệu đọc từ tài liệu đã nhận.')
        else:st.info('Bản mẫu đã lưu không kèm bản mã đầu vào trong phiên. Mở mẫu từ đầu hoặc tải tài liệu để tạo bản mã.')
        encryption_ui(cid)
        st.dataframe([{'Nguồn':title,'Tài liệu':d['document_id'],'Trạng thái':'Đã nhận' if d['available'] else 'Còn thiếu'}
                      for role,n,title,kind,hint in SOURCES for d in state['case']['documents'] if d['source_type']==role],hide_index=True,width='stretch')
        st.dataframe(comparison_rows(state),hide_index=True,width='stretch')
        st.caption('Đối chiếu ban đầu kiểm tra mã người vay/chủ tài khoản và thu nhập đơn vay–xác nhận. Thu nhập sao kê chỉ được so sánh sau khi phân loại và xác minh ở bước 2; không cộng mọi khoản tiền vào thành lương.')
        with st.expander('Trích xuất bằng Gemini · dành cho PDF khác mẫu hoặc cần đọc lại',expanded=False):
            st.caption('Python đã đọc các nhãn nhận diện được. Gemini chuẩn hóa các trường và cung cấp trích dẫn; kết quả mới vẫn cần con người kiểm tra.')
            api_button('extraction','Chạy Gemini trích xuất',cid+'_'+str(state['version'])+'_intake_extract')
        with st.expander('Bảng trường chuẩn hóa / JSON'):
            st.dataframe(normalized_rows(state),hide_index=True,width='stretch')
            st.download_button('Tải JSON tiếp nhận',json.dumps(state['case'],ensure_ascii=False,indent=2),cid+'_intake.json','application/json')
        st.subheader('C · Cảnh báo ban đầu và căn cứ')
        alerts(state)
        st.caption('Cảnh báo thiếu nguồn dẫn tới danh mục tiếp nhận; tài liệu chưa tồn tại thì không có trích dẫn. Các cảnh báo mâu thuẫn dẫn tới trang PDF hoặc dòng giao dịch cụ thể.')
        checked=st.checkbox('Tôi đã xem ba nguồn, bảng đối chiếu và các thông tin còn thiếu.',key=cid+'_'+str(state['version'])+'_intake_ack')
        st.caption('Xác nhận tiếp nhận không xác minh danh tính, không xác minh nguồn thu và không duyệt vay. Phần chưa đủ được giữ để xử lý trong bốn bước.')
        if st.button('Vào bước 1 · Tổng hợp hồ sơ',type='primary',disabled=not checked or pending,key='intake_continue'):
            accept_intake(state,commit)
    else:
        st.info('Chưa có hồ sơ. Chọn tài liệu hoặc chủ động mở mẫu; bốn bước rà soát sẽ xuất hiện sau khi xem đối chiếu ban đầu.')
        encryption_ui('')

"""Public landing page and horizontal navigation; all operations use native widgets."""
from html import escape
from pathlib import Path
import streamlit as st

WORK_PAGES=['Tổng quan','1 · Hồ sơ','2 · Kiểm tra','3 · Phân tích','4 · Báo cáo']
SECTIONS=['Trang chủ','Rà soát hồ sơ','Bảo mật Excel','Trợ lý','Hướng dẫn']

def section_for(page):
    if page in WORK_PAGES or page=='Tiếp nhận tài liệu':return 'Rà soát hồ sơ'
    return 'Trợ lý' if page=='Trợ lý hồ sơ' else page

def select_section():
    section=st.session_state['_nav_section']
    if section=='Rà soát hồ sơ':
        st.session_state.page=st.session_state.get('_last_work_page','Tiếp nhận tài liệu')
    else:
        st.session_state.page='Trợ lý hồ sơ' if section=='Trợ lý' else section

def shell_styles():
    from design_tokens import stylesheet
    st.markdown(stylesheet(),unsafe_allow_html=True)


def navigation(logo,connection,go):
    page=st.session_state.get('page','Trang chủ')
    if page in WORK_PAGES or page=='Tiếp nhận tài liệu':st.session_state['_last_work_page']=page
    st.session_state['_nav_section']=section_for(page)
    with st.container(key='cc_header'):
        brand,menu,config=st.columns([1.4,3.6,.85],vertical_alignment='center')
        with brand,st.container(key='cc_brand'):
            with st.container(horizontal=True,vertical_alignment='center',gap='small'):
                if logo and Path(logo).exists():st.image(str(logo),width=56)
                with st.container(key='cc_brand_words',gap='small'):
                    st.button('CreditCheck',type='tertiary',on_click=go,args=('Trang chủ',),key='brand_home')
                    st.caption('PROJECT 1 · RÀ SOÁT HỒ SƠ')
        with menu:
            st.radio('Điều hướng chính',SECTIONS,horizontal=True,key='_nav_section',
                     label_visibility='collapsed',on_change=select_section)
        with config,st.container(key='cc_connection'):
            with st.popover('Gemini',help='Kết nối API key và chọn model',width='stretch'):
                connection()
            from experience import connection_caption
            st.caption(connection_caption())
    return st.session_state.page

def line_icon(kind):
    shapes={'credit':'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/>',
            'privacy':'<path d="M12 3l8 3v6c0 5-5 8-8 10-3-2-8-5-8-10V6l8-3Z"/><path d="M8 12l3 3 5-6"/>',
            'assistant':'<path d="M5 4h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-8l-5 3v-3H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z"/><path d="M7 9h10M7 13h6"/>'}
    return '<span class="cc-line-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">'+shapes[kind]+'</svg></span>'

def start_sample():
    st.session_state['_intake_mode']='Hồ sơ mẫu giả lập'
    st.session_state.page='Tiếp nhận tài liệu'

def landing(go):
    assets=Path(__file__).resolve().parents[1]/'assets'
    with st.container(key='cc_landing'):
        intro,visual=st.columns([1.25,1],gap='large',vertical_alignment='center')
        with intro:
            st.markdown('<div class="cc-home-label">PROJECT 1 / CREDITCHECK</div><h1 class="cc-home-title">Hồ sơ rõ ràng.<br><em>Rà soát có căn cứ.</em></h1><p class="cc-home-copy">Từ ba nguồn tài liệu đến một báo cáo có thể kiểm tra. Bạn đối chiếu nguồn; Python tính chỉ số; Gemini hỗ trợ đọc và diễn giải.</p>',unsafe_allow_html=True)
            with st.container(horizontal=True,gap='small'):
                st.button('Bắt đầu rà soát',type='primary',on_click=go,args=('Tiếp nhận tài liệu',),key='home_start')
                st.button('Dùng thử hồ sơ mẫu',type='secondary',on_click=start_sample,key='home_sample')
            st.markdown('<div class="cc-intro-line">Bắt đầu bằng mẫu hoặc PDF/CSV của bạn. Có thể xem quy trình trước khi kết nối Gemini.</div>',unsafe_allow_html=True)
        with visual:
            st.markdown('<div class="cc-evidence-preview"><div class="cc-doc-label">MINH HỌA HS01 · KẾT QUẢ ĐÃ LƯU</div><h3>Ba nguồn, cùng một phép đối chiếu.</h3><table><thead><tr><th>Nguồn</th><th>Thu nhập / tháng</th></tr></thead><tbody><tr><td>Đơn vay</td><td>20.000.000 đ</td></tr><tr><td>Xác nhận thu nhập</td><td>20.000.000 đ</td></tr><tr><td>Sao kê đã xác minh</td><td>20.000.000 đ</td></tr></tbody></table><div class="cc-preview-result"><span>DTI theo dữ liệu mẫu</span><strong>33,54%</strong></div><p>Có căn cứ để diễn giải. Vẫn cần người thẩm định xem xét.</p></div>',unsafe_allow_html=True)
    with st.container(key='cc_journey'):
        st.markdown('<div class="cc-section-label">CÁCH BẠN LÀM VIỆC</div>',unsafe_allow_html=True)
        st.subheader('Nhận tài liệu trước. Rà soát trong bốn bước.')
        stages=[('01','Tổng hợp hồ sơ','Xem bảng thông tin từ các nguồn đã nhận.'),('02','Đối chiếu & xác minh','So dữ liệu với nguồn, xác minh thu nhập.'),('03','Hiểu chỉ số','Xem phép tính và căn cứ cảnh báo.'),('04','Kiểm tra báo cáo','Đọc bản nháp rồi tải bản bàn giao.')]
        for col,(n,title,body) in zip(st.columns(4),stages):
            with col:st.markdown('<div class="cc-process"><span class="cc-card-number">'+n+'</span><strong>'+title+'</strong><p>'+body+'</p></div>',unsafe_allow_html=True)
    with st.container(key='cc_source_story'):
        text,source=st.columns([1,1],gap='large',vertical_alignment='center')
        with text:
            st.markdown('<div class="cc-section-label">TỪ SỐ LIỆU ĐẾN CĂN CỨ</div>',unsafe_allow_html=True)
            st.subheader('Một con số, kiểm tra được từ đâu?')
            st.write('Chọn thông tin đã đọc để tìm đoạn căn cứ trong tài liệu. Người kiểm tra đối chiếu trước khi xác nhận; hệ thống không tự xác minh nguồn thu.')
            st.button('Xem vùng đối chiếu →',type='secondary',on_click=go,args=('2 · Kiểm tra',),key='home_source_check')
        with source:
            st.markdown('<div class="cc-mini-source"><span class="cc-source-label">MINH HỌA HS01-APP · TRANG 1</span><p>Thu nhập thực nhận/tháng (VND)<br><mark>20.000.000</mark></p><p>Nghĩa vụ nợ hiện tại/tháng (VND)<br>2.000.000</p><span class="cc-source-label">Dữ liệu mẫu · Chưa phải xác minh độc lập</span></div>',unsafe_allow_html=True)
    with st.container(key='cc_output_preview'):
        explain,paper=st.columns([1,1],gap='large',vertical_alignment='center')
        with explain:
            st.markdown('<div class="cc-section-label">ĐẦU RA CÓ THỂ KIỂM TRA</div>',unsafe_allow_html=True)
            st.subheader('Bạn sẽ nhận được gì?')
            st.write('Bản tóm tắt gắn thông tin hồ sơ, chỉ số Python, cảnh báo, thông tin còn thiếu và câu hỏi xác minh với căn cứ.')
            for title,copy in [('01 · Chỉ số có phép tính','PMT, DTI và các giả định để người kiểm tra đối chiếu.'),('02 · Nhận định có nguồn','Từ nội dung báo cáo quay lại tài liệu hoặc kết quả tính.'),('03 · Giới hạn rõ ràng','Bản nháp, phần đã kiểm tra và việc còn cần xác minh.')]:
                st.markdown('<div class="cc-output-point"><strong>'+title+'</strong><p>'+copy+'</p></div>',unsafe_allow_html=True)
            st.download_button('Xem PDF mẫu HS01',data=(assets/'HS01_report_preview.pdf').read_bytes(),file_name='HS01_BaoCao_MinhHoa.pdf',mime='application/pdf',key='home_preview_pdf')
            st.caption('PDF thật do ứng dụng xuất từ HS01 giả lập đã lưu; không phải kết quả của hồ sơ đang mở hay lần gọi Gemini mới.')
        with paper:
            st.image(str(assets/'HS01_report_preview.png'),caption='Trang 1 báo cáo mẫu · tải PDF để đọc đầy đủ',width='stretch')
    st.markdown('<div class="cc-section-label cc-tasks-label">CHỌN VIỆC BẠN MUỐN LÀM</div>',unsafe_allow_html=True)
    with st.container(key='cc_features'):
        tasks=[('credit','01 / CREDIT REVIEW','Rà soát hồ sơ vay','Đối chiếu tài liệu, xác minh nguồn thu và kiểm tra báo cáo.','Mở vùng làm việc →','Tiếp nhận tài liệu','home_credit'),('privacy','02 / DATA PRIVACY','Bảo mật dữ liệu Excel','Giả danh hóa trường nhận diện, giữ nguyên số liệu tài chính.','Xử lý file Excel →','Bảo mật Excel','home_excel'),('assistant','03 / CASE ASSISTANT','Trợ lý theo hồ sơ','Hỏi về chỉ số, cảnh báo và dữ liệu còn thiếu của hồ sơ đang mở.','Hỏi trợ lý →','Trợ lý hồ sơ','home_assistant')]
        for col,(kind,label,title,copy,button,page,key) in zip(st.columns(3,gap='large'),tasks):
            with col,st.container(border=True,key='cc_task_'+kind):
                st.markdown(line_icon(kind)+'<div class="cc-feature"><div class="cc-card-number">'+label+'</div><h3>'+title+'</h3><p>'+copy+'</p></div>',unsafe_allow_html=True)
                st.button(button,type='tertiary',on_click=go,args=(page,),key=key)
    with st.expander('LLM, Python và con người làm gì?'):
        st.write('Gemini hỗ trợ đọc tài liệu, đề xuất nhãn và diễn giải. Python tính chỉ số và kiểm tra quy tắc. Con người đối chiếu nguồn, xác minh thu nhập và kiểm tra báo cáo.')
        st.write('Các hồ sơ mẫu phục vụ học tập. Kết quả lưu sẵn khác với lần gọi API mới; ứng dụng không tự duyệt vay.')

def render_steps(state,page,go):
    from presentation import checkpoints
    done=checkpoints(state)
    captions=['Đủ ba nguồn tài liệu','Đã đối chiếu và xác minh','Đã có đủ chỉ số','Đã kiểm tra nội dung']
    pending=['Cần bổ sung nguồn','Cần kiểm tra & xác minh','Cần đầu vào đã xác minh','Cần kiểm tra báo cáo']
    with st.container(key='cc_steps'):
        for i,(col,target,label) in enumerate(zip(st.columns(4),WORK_PAGES[1:],['01 · Tổng hợp','02 · Kiểm tra','03 · Phân tích','04 · Tóm tắt'])):
            active=page==target
            with col,st.container(key='cc_step_'+str(i)+('_active' if active else '_done' if done[i] else '_pending')):
                st.button(label,type='primary' if active else 'tertiary',width='stretch',on_click=go,args=(target,),key='work_nav_'+target,icon=[':material/folder_open:',':material/fact_check:',':material/query_stats:',':material/description:'][i])
                st.caption(('✓ '+captions[i] if done[i] else pending[i])+(' · Đang mở' if active else ''))
    # Overview is placed beside the case context by the workspace, not on its own row.

def task_brief(page):
    text={'1 · Hồ sơ':('Tổng hợp thông tin → Xem phần còn thiếu','Dữ liệu đến từ tài liệu đã tiếp nhận. Bước kế tiếp: kiểm tra và xác minh nguồn thu.'),
          '2 · Kiểm tra':('Đối chiếu dữ liệu → Xác minh nguồn thu','Để tính chỉ số: đủ nguồn, nhãn rõ và đã xác minh kỳ sao kê/thu nhập.'),
          '3 · Phân tích':('Đọc chỉ số và kiểm tra cảnh báo','Có thể lập báo cáo ghi thiếu thông tin; không tự xác minh hoặc duyệt vay.'),
          '4 · Báo cáo':('Đọc bản nháp → Kiểm tra → Tải báo cáo','Chỉ xác nhận sau khi kiểm tra số liệu, nguồn và giới hạn.'),
          'Bảo mật Excel':('Chọn file → Giả danh hóa → Tải kết quả','Giữ nguyên số liệu tài chính; đây là giả danh hóa, chưa phải mã hóa toàn bộ workbook.'),
          'Trợ lý hồ sơ':('Đặt câu hỏi về hồ sơ đang mở','Đối chiếu câu trả lời với căn cứ; trợ lý không xác nhận thay bạn.')}
    if page in text:
        title,body=text[page]
        st.markdown('<div class="cc-task-brief"><strong>'+escape(title)+'</strong><span>'+escape(body)+'</span></div>',unsafe_allow_html=True)


def work_title(eyebrow,title):
    st.markdown('<div class="cc-work-title"><div class="cc-section-label">'+escape(eyebrow)+'</div><h1>'+escape(title)+'</h1></div>',unsafe_allow_html=True)

def guide(go):
    work_title('HƯỚNG DẪN NHANH','Chọn một việc để bắt đầu.')
    st.write('Dùng hồ sơ giả lập để khám phá; chỉ bấm gửi khi bạn đồng ý gọi Gemini. Dữ liệu được giữ trong cùng phiên trình duyệt.')
    with st.expander('Dùng thử trong 3 phút · không cần API key',expanded=True):
        st.markdown('1. Mở **Tiếp nhận tài liệu**, chọn phần mẫu rồi bấm **Xem kết quả mẫu đã lưu**.\n2. Sang **Kiểm tra** để chọn trường và đối chiếu nguồn.\n3. Mở **Phân tích** đọc DTI, rồi **Báo cáo** xem nội dung và tải PDF.')
        st.caption('Đây là kết quả mẫu đã lưu kèm xác nhận giả lập; không chứng minh vừa gọi API hay xác minh ngoài thực tế.')
        st.button('Đến bước Hồ sơ',on_click=go,args=('Tiếp nhận tài liệu',),key='guide_credit',type='primary')
    with st.expander('Chạy một hồ sơ từ đầu bằng Gemini'):
        st.markdown('1. Mở **Gemini** trên đầu trang, nhập key và tên model, rồi **Lưu kết nối**.\n2. Chọn hồ sơ hoặc tải ba nguồn tại Tiếp nhận tài liệu; xem bảng đối chiếu ban đầu, xác nhận đã xem rồi vào bốn bước; đồng ý gửi dữ liệu rồi trích xuất.\n3. Đối chiếu thông tin; phân loại giao dịch; kiểm tra nguồn thu và kỳ sao kê.\n4. Xem phép tính Python, tạo báo cáo và kiểm tra nội dung trước khi bàn giao.')
        st.image(str(Path(__file__).resolve().parents[1]/'assets/HS01_report_preview.png'),caption='Đầu ra mẫu do ứng dụng xuất; dùng bản PDF để đọc đầy đủ.',width=460)
    with st.expander('Tôi muốn bảo vệ file Excel'):
        st.write('Tải file theo bảng quy tắc 20 trường. Ứng dụng kiểm tra đầu vào, giả danh hóa rồi đối chiếu lại năm và 12 trường tài chính. Xem trước/sau và tải data_encrypted.xlsx. File này không có mật khẩu; Excel không được gửi Gemini.')
        st.button('Đến Bảo mật Excel',on_click=go,args=('Bảo mật Excel',),key='guide_excel')
    with st.expander('API bị lỗi hoặc nút chưa bấm được?'):
        st.markdown('- **Nút bị khóa:** xem điều kiện ngay cạnh nút: cấu hình, đồng ý gửi dữ liệu, hoặc xác nhận bước trước.\n- **503:** dịch vụ tạm quá tải; chờ rồi bấm Thử lại.\n- **401/403:** kiểm tra key và quyền. **404:** kiểm tra tên model. **429:** kiểm tra quota.\n- **Mật khẩu .ccenc sai:** dùng mật khẩu lúc tạo tệp; đây không phải API key.')
        st.caption('Đã lưu cấu hình chưa có nghĩa API đã chạy thành công. Chỉ tác vụ thành công mới xác nhận được điều đó.')
    with st.expander('Giữ kết quả và hiểu phạm vi bảo mật'):
        st.write('Tải PDF/ZIP tại Báo cáo; đó là bản rõ. Tệp .ccenc tại Tiếp nhận tài liệu → Mã hóa hồ sơ cần mật khẩu để khôi phục tài liệu, không chứa API key hay xác nhận kiểm tra. Mã giả danh Excel ổn định trong phiên; muốn liên kết nhiều phiên cần dùng khóa riêng trong script offline.')
        st.write('LLM đọc, đề xuất nhãn và diễn giải. Python tính và kiểm tra quy tắc. Con người đối chiếu, xác minh và kiểm tra báo cáo. Ứng dụng học tập không tự duyệt vay.')


def footer():
    st.markdown('<div class="cc-footer"><span><strong>CreditCheck</strong> · Project 1<br>Rà soát hồ sơ vay cá nhân với LLM và Python</span><span>Dữ liệu giả lập phục vụ học tập<br>Không tự duyệt vay · v0.28</span></div>',unsafe_allow_html=True)


def scroll_on_page_change(page):
    """Scroll only on navigation, never on edits or validation reruns."""
    previous=st.session_state.get('_cc_rendered_page')
    st.session_state['_cc_rendered_page']=page
    if previous is None or previous==page:
        return
    serial=st.session_state.get('_cc_scroll_serial',0)+1
    st.session_state['_cc_scroll_serial']=serial
    # All script contents are application-owned; no dossier/user text is injected.
    st.html('<script data-cc-navigation="'+str(serial)+'">'+r"""
    (() => {
      const jump = () => {
        const main = document.querySelector('[data-testid="stMain"]');
        if (main) main.scrollTo({top:0,left:0,behavior:'instant'});
        window.scrollTo({top:0,left:0,behavior:'instant'});
      };
      requestAnimationFrame(jump);
      // One bounded retry after Streamlit lays out the new page.
      setTimeout(jump, 150);
    })();
    """+'</script>',unsafe_allow_javascript=True)


def landing_scroll_reveal(active=True):
    """Reveal individual sections as they enter view, including streamed nodes."""
    if not active:
        st.html("""<script>
        if (window.__ccLandingCleanup) window.__ccLandingCleanup();
        document.querySelectorAll('[data-cc-reveal="pending"]').forEach(
          n => n.setAttribute('data-cc-reveal','shown'));
        </script>""",unsafe_allow_javascript=True)
        return
    st.html(r"""<script>
    (() => {
      const selector = '.st-key-cc_landing, .st-key-cc_source_story, .st-key-cc_journey h3, .st-key-cc_journey .cc-section-label, .st-key-cc_journey .cc-process, .st-key-cc_output_preview [data-testid="stColumn"], [class*="st-key-cc_task_"], .cc-tasks-label, .cc-footer';
      if (window.__ccLandingCleanup) window.__ccLandingCleanup();
      const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
      if (!('IntersectionObserver' in window) || reduced.matches) {
        document.querySelectorAll(selector).forEach(n => n.setAttribute('data-cc-reveal','shown'));
        return;
      }
      const observed = new WeakSet();
      const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.setAttribute('data-cc-reveal','shown');
            observer.unobserve(entry.target);
          }
        });
      }, {root:null, threshold:0.12, rootMargin:'-64px 0px -72px 0px'});
      let frame = null;
      const scan = () => {
        frame = null;
        document.querySelectorAll(selector).forEach(node => {
          if (observed.has(node)) return;
          observed.add(node);
          const rect = node.getBoundingClientRect();
          // Content already above the viewport must remain readable.
          if (rect.bottom <= 64 || node.getAttribute('data-cc-reveal') === 'shown') {
            node.setAttribute('data-cc-reveal','shown');
          } else {
            node.setAttribute('data-cc-reveal','pending');
            observer.observe(node);
          }
        });
      };
      const schedule = () => { if (frame === null) frame = requestAnimationFrame(scan); };
      const mutations = new MutationObserver(schedule);
      const main = document.querySelector('[data-testid="stMain"]');
      if (main) mutations.observe(main,{childList:true,subtree:true});
      const onMotionChange = () => {
        if (reduced.matches) {
          observer.disconnect();
          document.querySelectorAll(selector).forEach(n => n.setAttribute('data-cc-reveal','shown'));
        }
      };
      reduced.addEventListener('change',onMotionChange);
      window.__ccLandingCleanup = () => {
        observer.disconnect(); mutations.disconnect();
        if (frame !== null) cancelAnimationFrame(frame);
        reduced.removeEventListener('change',onMotionChange);
      };
      schedule();
    })();
    </script>""",unsafe_allow_javascript=True)

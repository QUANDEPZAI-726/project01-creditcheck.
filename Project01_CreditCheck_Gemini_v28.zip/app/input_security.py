"""Authenticated encryption for input snapshots; no plaintext files or passwords saved."""
import base64
import binascii
import json
import os
import re
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAX_INPUT = 10 * 1024 * 1024
MAX_ENVELOPE = 22 * 1024 * 1024
FORMAT = 'creditcheck-input-v1'
N, R, P = 2**15, 8, 1

def b64(data):
    return base64.b64encode(data).decode('ascii')

def unb64(value):
    if not isinstance(value, str):
        raise ValueError('Tệp mã hóa sai định dạng.')
    try:
        return base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error):
        raise ValueError('Tệp mã hóa sai định dạng.') from None

def pack_inputs(case_id, files, coverage=None):
    if not isinstance(case_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,40}', case_id):
        raise ValueError('Mã hồ sơ chỉ gồm chữ, số, dấu gạch ngang/gạch dưới; tối đa 40 ký tự.')
    roles = {'application', 'income_certificate', 'bank_statement'}
    if not isinstance(files, dict) or not files or not set(files) <= roles:
        raise ValueError('Cần tài liệu đầu vào thuộc các loại được hỗ trợ.')
    if any(not isinstance(v, bytes) for v in files.values()) or sum(map(len, files.values())) > MAX_INPUT:
        raise ValueError('Tổng tài liệu đầu vào tối đa 10 MB.')
    obj = {'case_id': case_id, 'files': {k: b64(v) for k, v in files.items()}, 'coverage': coverage}
    return json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8')

def unpack_inputs(data):
    if not isinstance(data, bytes) or len(data) > MAX_INPUT * 4 // 3 + 65536:
        raise ValueError('Dữ liệu đầu vào quá lớn.')
    try:
        obj = json.loads(data)
        if not isinstance(obj, dict) or set(obj) != {'case_id', 'files', 'coverage'} or not isinstance(obj['files'], dict):
            raise ValueError()
        files = {k: unb64(v) for k, v in obj['files'].items()}
        pack_inputs(obj['case_id'], files, obj['coverage'])
        coverage = obj['coverage']
        if coverage is not None and not isinstance(coverage, dict):
            raise ValueError()
        return obj['case_id'], files, coverage
    except (ValueError, TypeError, KeyError, UnicodeError, RecursionError):
        raise ValueError('Dữ liệu đã giải mã không phải hồ sơ đầu vào hợp lệ.') from None

def session_key():
    return AESGCM.generate_key(bit_length=256)

def seal_session(data, key, purpose):
    nonce = os.urandom(12)
    return nonce + AESGCM(key).encrypt(nonce, data, purpose.encode('utf-8'))

def open_session(blob, key, purpose):
    try:
        return AESGCM(key).decrypt(blob[:12], blob[12:], purpose.encode('utf-8'))
    except (InvalidTag, ValueError, TypeError):
        raise ValueError('Không giải mã được dữ liệu phiên này.') from None

def _password(password):
    if not isinstance(password, str) or not 12 <= len(password) <= 1024:
        raise ValueError('Mật khẩu mã hóa cần từ 12 đến 1.024 ký tự.')
    return password.encode('utf-8')

def _derive(password, salt):
    return Scrypt(salt=salt, length=32, n=N, r=R, p=P).derive(_password(password))

def _header(salt, nonce):
    return {'format': FORMAT, 'cipher': 'AES-256-GCM', 'kdf': 'scrypt',
            'n': N, 'r': R, 'p': P, 'salt': b64(salt), 'nonce': b64(nonce)}

def _aad(header):
    return json.dumps(header, sort_keys=True, separators=(',', ':')).encode('ascii')

def encrypt_export(data, password):
    unpack_inputs(data)
    salt, nonce = os.urandom(16), os.urandom(12)
    header = _header(salt, nonce)
    ciphertext = AESGCM(_derive(password, salt)).encrypt(nonce, data, _aad(header))
    return json.dumps(dict(header, ciphertext=b64(ciphertext)), separators=(',', ':')).encode('ascii')

def decrypt_export(envelope, password):
    if not isinstance(envelope, bytes) or len(envelope) > MAX_ENVELOPE:
        raise ValueError('Tệp mã hóa tối đa 22 MB.')
    try:
        obj = json.loads(envelope)
        if not isinstance(obj, dict) or set(obj) != {'format','cipher','kdf','n','r','p','salt','nonce','ciphertext'}:
            raise ValueError()
        salt, nonce, ct = unb64(obj['salt']), unb64(obj['nonce']), unb64(obj['ciphertext'])
        header = _header(salt, nonce)
        if {k: v for k, v in obj.items() if k != 'ciphertext'} != header or len(salt) != 16 or len(nonce) != 12 or len(ct) < 16:
            raise ValueError()
    except (ValueError, TypeError, KeyError, UnicodeError, RecursionError):
        raise ValueError('Tệp không đúng định dạng mã hóa CreditCheck.') from None
    try:
        data = AESGCM(_derive(password, salt)).decrypt(nonce, ct, _aad(header))
    except InvalidTag:
        raise ValueError('Sai mật khẩu hoặc tệp đã bị thay đổi; không nhập dữ liệu.') from None
    unpack_inputs(data)
    return data

def validate_connection(api_key, model):
    api_key, model = api_key.strip(), model.strip()
    if model.startswith('models/'):
        model = model[7:]
    if not api_key or len(api_key) > 3000 or any(c.isspace() for c in api_key):
        raise ValueError('Nhập API key Gemini hợp lệ, không chứa khoảng trắng.')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,119}', model):
        raise ValueError('Tên model chỉ gồm chữ, số, dấu chấm, gạch ngang/gạch dưới.')
    return api_key, model

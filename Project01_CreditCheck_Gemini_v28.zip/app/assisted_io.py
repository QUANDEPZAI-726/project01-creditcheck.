"""Bounded saved-result imports; never restore claimed human reviews from uploads."""
import io,json,zipfile
from core import ensure,now
from phase2 import change
from phase3 import sync,template,validate

LIMIT=10*1024*1024

def read_result(data,task):
    ensure(task in ('classification','summary'),'Loại kết quả không hợp lệ.')
    ensure(isinstance(data,bytes) and len(data)<=LIMIT,'Tệp kết quả tối đa 10 MB.')
    try:
        if data.startswith(b'PK'):
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                ensure(len(z.infolist())<=100,'ZIP có quá nhiều tệp.')
                name=task+'.json'
                if name in z.namelist():
                    info=z.getinfo(name);ensure(info.file_size<=LIMIT,'JSON giải nén quá lớn.')
                    obj=json.loads(z.read(info))
                else:
                    info=z.getinfo('review_and_log.json');ensure(info.file_size<=LIMIT,'Nhật ký giải nén quá lớn.')
                    saved=json.loads(z.read(info))
                    if task=='classification':
                        c=saved['phase2']['classification']
                        obj={'case_id':saved['case']['case_id'],'source_sha256':c['source_sha256'],'transactions':c['rows']}
                        obj['transactions']=[{k:r[k] for k in ('transaction_id','label','reason','evidence')} for r in obj['transactions']]
                    else:
                        ensure(saved['phase3']['summary'].get('mode')!='RULE_BASED','Bản nháp quy tắc không được nhập thành kết quả LLM.')
                        obj=saved['phase3']['summary']['result']
        else:obj=json.loads(data.decode('utf-8-sig'))
        ensure(isinstance(obj,dict),'Kết quả phải là JSON object.')
        return obj
    except (KeyError,TypeError,UnicodeError,json.JSONDecodeError,zipfile.BadZipFile,RuntimeError) as exc:
        raise ValueError('Không đọc được kết quả '+task+'. Chọn JSON đúng mẫu hoặc ZIP báo cáo có review_and_log.json.') from exc

def rule_draft(s,body):
    """Transparent deterministic fallback, distinct from LLM imports/API runs."""
    sync(s);obj=template(s);ctx=s['phase3']['context']
    obj['overview']=[{'text':f"Hồ sơ giả lập {obj['case_id']} của {obj['key_information']['full_name']}. Đây là bản nháp tổng hợp bằng quy tắc, chưa có diễn giải LLM mới.",'refs':['CASE','SCOPE']}]
    if ctx['metrics_available']:
        m=obj['metrics']
        text=f"Python tính thu nhập đã xác minh {m['validated_monthly_income_vnd']:,.0f} đồng/tháng, trả góp mới {m['monthly_payment_vnd']:,.0f} đồng/tháng, DTI {m['dti_pct']:.2f}% và độ lệch thu nhập {m['income_gap_pct']:.2f}%. Các ngưỡng chỉ là giả định bài tập."
        refs=['METRICS','CONFIG']
    else:text='Chưa có chỉ số chính thức. Cần đủ nguồn hợp lệ, phân loại giao dịch và xác minh thu nhập; không ước tính DTI.';refs=['PENDING_METRICS']
    obj['metric_explanations']=[{'text':text,'refs':refs}]
    obj['limitations']=[{'text':'Bản nháp bằng quy tắc không phải kết quả LLM hoặc lần gọi Gemini. Nghĩa vụ nợ do người vay khai báo, chưa xác minh độc lập; chưa tính phí và bảo hiểm. Không phải quyết định cấp tín dụng.','refs':['SCOPE','CONFIG']}]
    obj['verification_questions']=[{'text':'Người kiểm tra cần xác minh tính đúng của tài liệu, nguồn lương, kỳ sao kê và nghĩa vụ nợ hiện tại bằng những nguồn nào?','refs':['CASE','REVIEW','SCOPE']}]
    for f in obj['risk_flags']:
        obj['verification_questions'].append({'text':'Cần xử lý và bổ sung căn cứ cho cảnh báo: '+f['message'],'refs':['FLAG:'+f['code']]})
    validate(s,obj)
    s['phase3']['summary']={'mode':'RULE_BASED','model':'Quy tắc Python — không dùng LLM','imported_at':now(),'result':obj,'provenance':'deterministic_rule_draft'}
    s['phase3']['content_review']=None
    change(s,'CREATE_RULE_DRAFT',{'reason':'Bản nháp quy tắc; không gọi LLM và không tự xác nhận.'});sync(s)

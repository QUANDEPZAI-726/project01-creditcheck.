"""Single, ordered design system. All fonts are bundled, including Vietnamese."""
import base64
from pathlib import Path
from functools import lru_cache

@lru_cache(maxsize=1)
def stylesheet():
    assets=Path(__file__).resolve().parents[1]/'assets'
    fonts=''.join('@font-face{font-family:"CreditCheck UI";font-weight:'+str(weight)+';font-style:normal;font-display:swap;src:url(data:font/ttf;base64,'+base64.b64encode((assets/name).read_bytes()).decode()+') format("truetype");}' for name,weight in [('UI-Regular.ttf',400),('UI-Bold.ttf',700)])
    # Only the navigation icon masks are reused; remove the historical style cascade.
    icons=(assets/'navigation_icons.css').read_text()
    return '<style>'+fonts+(assets/'system.css').read_text()+icons+'</style>'

"""Proportional financial comparisons; never substitute zero for missing data."""
import altair as alt
import pandas as pd
from presentation import money


def comparison_domain(incomes, debts):
    values = [r['Thu nhập (đ)'] for r in incomes] + [r['Số tiền (đ)'] for r in debts]
    values = [float(v) for v in values if v is not None]
    return [min([0.0] + values) * 1.32, max([1.0] + values) * 1.32]


def amount_chart(rows, amount, category, title, domain=None):
    data = pd.DataFrame([dict(r, _amount_label=money(r[amount])) for r in rows if r[amount] is not None])
    if domain is None:
        values = list(data[amount])
        domain = [min([0] + values) * 1.32, max([1] + values) * 1.32]
    base = alt.Chart(data).encode(
        x=alt.X(amount+':Q', title='Triệu đồng / tháng',
                scale=alt.Scale(domain=domain, nice=False, zero=True),
                axis=alt.Axis(labelExpr="format(datum.value / 1000000, '~g')", tickCount=5)),
        y=alt.Y(category+':N', sort=None, title=None, axis=alt.Axis(labelLimit=170)),
        tooltip=[alt.Tooltip(category+':N'), alt.Tooltip(amount+':Q', format=',.0f', title='Đồng / tháng')])
    bars = base.mark_bar(color='#087F8C', cornerRadiusEnd=5, size=29)
    positive = base.transform_filter(alt.datum[amount] >= 0).mark_text(
        align='left', dx=7, color='#153E53', fontSize=12).encode(text='_amount_label:N')
    negative = base.transform_filter(alt.datum[amount] < 0).mark_text(
        align='right', dx=-7, color='#153E53', fontSize=12).encode(text='_amount_label:N')
    return (bars+positive+negative).properties(height=200, title=title).configure_axis(
        labelColor='#304F5C', titleColor='#304F5C', labelFont='Arial', titleFont='Arial',
        labelFontSize=13, gridColor='#E2EAE7').configure_title(
        color='#153E53', font='Arial', fontSize=16, anchor='start', offset=18
    ).configure_view(stroke=None).configure(background='#FFFFFF')

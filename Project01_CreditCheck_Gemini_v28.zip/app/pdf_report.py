"""Readable Vietnamese PDF generated from the validated report; no LLM call."""
from pathlib import Path
from io import BytesIO
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.shapes import Drawing, Rect, String
from core import ensure
from phase3 import sync, validate
from presentation import money, ratio, income_rows

ROOT=Path(__file__).resolve().parents[1]
NAVY=colors.HexColor('#172B4D');TEAL=colors.HexColor('#087F8C');MUTED=colors.HexColor('#52647A')

def pdf_bytes(state):
    sync(state)
    summary=state['phase3']['summary']
    ensure(summary is not None,'Tạo bản nháp báo cáo trước khi xuất PDF.')
    validate(state,summary['result'])
    if 'CCSans' not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('CCSans',str(ROOT/'assets/DejaVuSans.ttf')))
        pdfmetrics.registerFont(TTFont('CCSansBold',str(ROOT/'assets/DejaVuSans-Bold.ttf')))
        pdfmetrics.registerFontFamily('CCSans',normal='CCSans',bold='CCSansBold',italic='CCSans',boldItalic='CCSansBold')
    styles=getSampleStyleSheet()
    body=ParagraphStyle('CCBody',fontName='CCSans',fontSize=9.5,leading=14,textColor=NAVY,spaceAfter=7)
    small=ParagraphStyle('CCSmall',parent=body,fontSize=8,leading=11,textColor=MUTED)
    title=ParagraphStyle('CCTitle',parent=body,fontName='CCSansBold',fontSize=22,leading=28,spaceAfter=10)
    heading=ParagraphStyle('CCHeading',parent=body,fontName='CCSansBold',fontSize=12,leading=17,spaceBefore=12,spaceAfter=7,keepWithNext=True)
    p=lambda text,style=body:Paragraph(escape(str(text)).replace('\n','<br/>'),style)
    result=summary['result'];ctx=state['phase3']['context'];metrics=result['metrics']
    story=[p('CREDITCHECK  /  PROJECT 01',small),p('Báo cáo rà soát hồ sơ vay',title),
           p(result['case_id']+' · '+str(result['key_information']['full_name'] or 'Chưa có tên người vay')),
           p('Trạng thái rà soát: '+result['review_status']+' | Nội dung: '+state['case']['review']['summary_status'],small),
           p('Hồ sơ giả lập. Không phải quyết định cấp tín dụng.',small)]
    prov='Bản nháp quy tắc Python; không phải LLM/Gemini' if summary.get('mode')=='RULE_BASED' else ('Gemini API trực tiếp' if summary.get('mode')=='API_DIRECT' else 'Kết quả LLM bên ngoài đã lưu/nhập')
    story.append(p('Nguồn báo cáo: '+prov+' · Model: '+summary['model'],small))
    info=result['key_information']
    data=[[p('Thông tin',small),p('Giá trị',small)],
          [p('Khoản vay đề nghị'),p(money(info['loan_principal_vnd']))],
          [p('Kỳ hạn'),p(str(info['term_months'])+' tháng' if info['term_months'] is not None else 'Chưa có')],
          [p('Thu nhập đã xác minh'),p(money(metrics['validated_monthly_income_vnd']))],
          [p('Trả góp mới mỗi tháng'),p(money(metrics['monthly_payment_vnd']))],
          [p('DTI · trả nợ/thu nhập'),p(ratio(metrics['dti_pct']))],
          [p('Độ lệch thu nhập'),p(ratio(metrics['income_gap_pct']))]]
    table=Table(data,colWidths=[255,244],repeatRows=1,hAlign='LEFT')
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E8F4F5')),
                              ('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),7),
                              ('BOTTOMPADDING',(0,0),(-1,-1),5),('LINEBELOW',(0,0),(-1,-1),0.4,colors.HexColor('#DCE4EF'))]))
    story.extend([Spacer(1,10),table])
    rows=income_rows(state)
    if rows:
        drawing=Drawing(499,38+len(rows)*34)
        max_value=max(max(r['Thu nhập (đ)'] for r in rows),1)
        for i,row in enumerate(rows):
            y=22+(len(rows)-i-1)*34
            drawing.add(String(0,y+4,row['Nguồn'],fontName='CCSans',fontSize=9,fillColor=NAVY))
            width=row['Thu nhập (đ)']/max_value*210
            drawing.add(Rect(153,y,width,17,fillColor=TEAL,strokeColor=None))
            drawing.add(String(372,y+4,money(row['Thu nhập (đ)']),fontName='CCSans',fontSize=8,fillColor=NAVY))
        story.append(KeepTogether([p('So sánh thu nhập theo nguồn',heading),drawing]))
    for key,label in [('overview','Tóm tắt hồ sơ'),('metric_explanations','Diễn giải chỉ số'),
                      ('limitations','Giới hạn sử dụng'),('verification_questions','Câu hỏi cần xác minh')]:
        story.append(p(label,heading))
        for row in result[key]:
            story.extend([p(row['text']),p('Căn cứ: '+', '.join(row['refs']),small)])
    for key,label in [('risk_flags','Cảnh báo'),('missing_information','Thông tin còn thiếu')]:
        story.append(p(label,heading))
        if not result[key]:story.append(p('Chưa có mục nào theo các phép kiểm tra hiện tại. Không chứng minh hồ sơ đủ cho thẩm định thực tế.'))
        for row in result[key]:story.append(p(row['code']+': '+row['message']))
    story.append(p('Kiểm tra và nguồn tham chiếu',heading))
    review=state['phase3']['content_review']
    story.append(p(('Người kiểm tra: '+review['reviewer']+' · Thời điểm UTC: '+review['reviewed_at']+' · Ghi chú: '+review['reason']) if review else 'Bản nháp chưa được người dùng kiểm tra nội dung.',small))
    story.append(p('Danh tính người kiểm tra do người dùng khai, chưa xác thực độc lập. Xác nhận nội dung không duyệt vay.',small))
    for did,src in state['sources'].items():
        story.append(p(did+' · '+src['role']+' · SHA-256: '+src['sha256'],small))
    for alert in state['traceability']['alerts']:
        story.append(p(alert['code']+' · '+alert['rule'],small))
        for ev in alert['evidence']:
            story.append(p(ev['document_id']+' | '+ev['locator']+' | '+(ev.get('quote') or 'Nguồn thiếu, không có trích dẫn.'),small))
    cfg=ctx['config']
    story.append(p('Giả định: lãi danh nghĩa '+str(round(cfg['annual_nominal_rate']*100,4))+'%/năm; ngưỡng DTI '+str(cfg['dti_threshold_pct'])+'%, lệch thu nhập '+str(cfg['income_gap_threshold_pct'])+'%. Chưa gồm phí/bảo hiểm.',small))
    out=BytesIO()
    doc=SimpleDocTemplate(out,pagesize=A4,rightMargin=48,leftMargin=48,topMargin=44,bottomMargin=44,title='CreditCheck '+result['case_id'],author='Project 01')
    def footer(canvas,doc):
        canvas.setStrokeColor(colors.HexColor('#DCE4EF'));canvas.line(48,34,547,34)
        canvas.setFont('CCSans',8);canvas.setFillColor(MUTED)
        canvas.drawString(48,22,'Hồ sơ giả lập · Cần con người rà soát · Không duyệt vay')
        canvas.drawRightString(547,22,'Trang '+str(doc.page))
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    return out.getvalue()

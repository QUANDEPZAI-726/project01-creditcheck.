"""CreditCheck 0.28 — unified review workspace, evidence and grounded assistant."""
import base64
import copy
import hashlib
import hmac
import io
import json
import os
from pathlib import Path
import sys
import threading
import time
import zipfile
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'app'))
from core import make_state, public_state, edit_field, LABELS, now
from phase2 import review_extraction_phase2, verify_income, edit_classification, set_rate
from phase3 import report_text, summary_prompt, import_summary
from phase2 import classification_prompt, import_classification
from assisted_io import read_result, rule_draft
from traceability import sync
from gemini_service import GeminiClient, run_task, chat
from privacy_excel import protect_excel, rule_rows, inspect_excel, example_excel, FINANCIAL
from ui_shell import navigation, shell_styles, landing, guide, work_title, footer, WORK_PAGES, scroll_on_page_change, render_steps, task_brief, landing_scroll_reveal
from assistant_ui import floating_assistant, full_assistant
from experience import (CASE_LABELS, status_label, alert_label, display_value, highlighted_source, case_context, error_guidance, error_details, record_api_success)
from input_security import (session_key, seal_session, open_session, pack_inputs, unpack_inputs,
                            encrypt_export, decrypt_export, validate_connection)

def encryption_key():
    if '_encryption_key' not in st.session_state:
        st.session_state['_encryption_key'] = session_key()
    return st.session_state['_encryption_key']

def protect_inputs(case_id, files, coverage=None):
    packed = pack_inputs(case_id, files, coverage)
    protected = seal_session(packed, encryption_key(), 'input:'+case_id)
    # Authenticate/decrypt before parsing; the working dossier is plaintext in RAM.
    clear = open_session(protected, encryption_key(), 'input:'+case_id)
    cid, restored_files, restored_coverage = unpack_inputs(clear)
    result = make_state(cid, restored_files, restored_coverage)
    vault = st.session_state.setdefault('_input_vault', {})
    vault[cid] = protected
    if st.session_state.get('_encrypted_download',{}).get('case_id') == cid:
        st.session_state.pop('_encrypted_download',None)
    return result

def save_personal_connection():
    try:
        key, model = validate_connection(st.session_state.get('_api_key_input',''),
                                         st.session_state.get('_model_input',''))
        st.session_state['_personal_key'] = seal_session(key.encode(), encryption_key(), 'gemini-key')
        st.session_state['_personal_model'] = model
        st.session_state['_api_key_input'] = ''
        st.session_state['_connection_error'] = ''
        st.session_state.pop('_api_success',None)
    except ValueError as exc:
        st.session_state['_connection_error'] = str(exc)

def clear_personal_connection():
    for key in ('_personal_key','_personal_model','_connection_error','_api_success'):
        st.session_state.pop(key,None)
    st.session_state['_api_key_input'] = ''

def save_group_model():
    try:
        _, model = validate_connection('validation-only', st.session_state.get('_group_model_input',''))
        st.session_state['_group_model_override'] = model
        st.session_state.pop('_api_success',None)
        st.session_state.pop('_connection_probe',None)
        st.session_state.pop('_group_model_error',None)
    except ValueError as exc:
        st.session_state['_group_model_error'] = str(exc)

def reset_group_model():
    for key in ('_group_model_override','_group_model_error','_api_success','_connection_probe','_group_model_input'):
        st.session_state.pop(key,None)

def connection_identity():
    key, model = configured_connection()
    source = st.session_state.get('_api_source','API key của tôi')
    return hashlib.sha256((source+'\0'+key+'\0'+model).encode()).hexdigest()

def connection_diagnostics():
    st.divider()
    st.markdown('**Kiểm tra API trước khi trình bày**')
    st.caption('Yêu cầu thử chỉ gửi câu kiểm tra cố định, không gửi hồ sơ. Mỗi nút dùng một lượt trong giới hạn demo; tài khoản Google có thể tính hạn mức/chi phí API.')
    st.caption('Lượt thao tác API trong phiên: '+str(st.session_state.get('api_calls',0))+'/30 · Cách nhau ít nhất 5 giây. Key nhóm có giới hạn chung 60 lượt/giờ trên máy chủ. Lượt đã gửi dù thất bại vẫn được tính. Không tự gửi lại hoặc tự đổi model. Kiểm tra kết nối tối đa 15 giây; tác vụ hồ sơ tối đa 45 giây chờ trên giao diện.')
    reason = ''
    try:
        identity = connection_identity()
    except ValueError as exc:
        reason = str(exc)
        identity = None
    if reason:
        st.caption(reason)
    consent = st.toggle('Đồng ý gọi Google Gemini để kiểm tra kết nối, không gửi hồ sơ.',key='_diagnostic_consent')
    if st.button('Kiểm tra kết nối API',key='connection_probe',disabled=bool(reason) or not consent):
        try:
            client = reserve_call()
            with st.spinner('Đang thử API bằng câu ngắn · tối đa 15 giây chờ…'):
                meta = client.probe()
            record_api_success(client)
            st.session_state['_connection_probe'] = {'identity': identity, 'ok': True,
                'model': client.model, 'at': now()}
        except (ValueError,TypeError,KeyError) as exc:
            st.session_state.pop('_api_success',None)
            st.session_state['_connection_probe'] = {'identity':identity,'ok':False,'error':str(exc),'at':now()}
    result = st.session_state.get('_connection_probe',{})
    if result.get('identity') == identity and result:
        if result.get('ok'):
            st.success('API đã trả JSON kiểm tra hợp lệ · '+result['model'])
            st.caption('Đây là kiểm tra kết nối, chưa chứng minh trích xuất, phân loại và tạo báo cáo đã chạy thành công. Tiếp tục kiểm tra từng tác vụ.')
        else:
            title,hint = error_guidance(result['error'])
            st.error(title);st.caption(hint);error_details(result['error'])
    if st.button('Lấy danh sách model hỗ trợ tạo nội dung',key='connection_models',disabled=bool(reason) or not consent):
        try:
            client = reserve_call()
            with st.spinner('Đang đọc danh sách model từ Google…'):
                names = client.available_models()
            st.session_state['_connection_models'] = {'identity':identity,'names':names}
        except (ValueError,TypeError,KeyError) as exc:
            title,hint = error_guidance(exc)
            st.error(title);st.caption(hint);error_details(exc)
    models = st.session_state.get('_connection_models',{})
    if identity is not None and models.get('identity') == identity:
        st.code('\n'.join(models.get('names',[])) or 'API không trả model hỗ trợ generateContent.',language=None)
        st.caption('Danh sách do API trả về; vẫn cần thử model để kiểm tra quyền/quota. Chọn model văn bản hỗ trợ JSON, không chọn model chỉ tạo ảnh/âm thanh. Chép đúng tên vào ô model rồi lưu; ứng dụng không tự đổi model.')

def prepare_encrypted_download(case_id):
    try:
        blob = st.session_state.get('_input_vault',{}).get(case_id)
        if not blob:
            raise ValueError('Chưa có bản đầu vào mã hóa cho hồ sơ này.')
        clear = open_session(blob, encryption_key(), 'input:'+case_id)
        encrypted = encrypt_export(clear, st.session_state.get('_export_password',''))
        st.session_state['_encrypted_download'] = {'case_id':case_id,'data':encrypted}
        st.session_state['_export_password'] = ''
        st.session_state['_encryption_notice'] = 'Đã tạo bản mã hóa. Giữ mật khẩu riêng để nhập lại ở phiên khác.'
        st.session_state.pop('_encryption_error',None)
    except ValueError as exc:
        st.session_state.pop('_encrypted_download',None)
        st.session_state['_encryption_error'] = str(exc)

def restore_encrypted_inputs():
    try:
        uploaded = st.session_state.get('_encrypted_upload')
        if uploaded is None:
            raise ValueError('Chọn tệp .ccenc trước.')
        clear = decrypt_export(uploaded.getvalue(),st.session_state.get('_import_password',''))
        case_id, files, coverage = unpack_inputs(clear)
        # New dossier: never restore someone else's human confirmations from input files.
        result = protect_inputs(case_id,files,coverage)
        sync(result)
        old = st.session_state.dossier
        if old: st.session_state.portfolio[old['case']['case_id']] = copy.deepcopy(old)
        st.session_state.dossier = result
        st.session_state.page = 'Tiếp nhận tài liệu'
        st.session_state.messages = []
        st.session_state['_import_password'] = ''
        st.session_state['_encryption_notice'] = 'Giải mã và nhập đầu vào thành công. Cần đối chiếu và xác minh lại.'
        st.session_state.pop('_encryption_error',None)
    except (ValueError,TypeError,KeyError) as exc:
        st.session_state['_encryption_error'] = str(exc)

def encryption_ui(case_id):
    with st.expander('Mã hóa hồ sơ · AES-256-GCM'):
        st.caption('Đầu vào: PDF/CSV của hồ sơ → đầu ra: tệp .ccenc có mật khẩu. Khôi phục tài liệu cần đúng mật khẩu; xác nhận của người kiểm tra không được khôi phục.')
        blob = st.session_state.get('_input_vault',{}).get(case_id)
        if blob:
            st.success('Đã tạo bản mã hóa tài liệu đầu vào cho hồ sơ '+case_id+'.')
            st.caption('Bản đầu vào mã hóa được giữ trong phiên. Dữ liệu xử lý và màn hình vẫn là bản rõ trong bộ nhớ; Gemini nhận nội dung cần xử lý qua kết nối HTTPS.')
            with st.expander('Xem một phần bản mã để demo'):
                st.code(base64.b64encode(blob[12:]).decode()[:160]+'…',language=None)
        else:
            st.info('Mở hoặc tải hồ sơ ở bước Hồ sơ để tạo bản đầu vào mã hóa.')
        st.write('Tải bản đầu vào mã hóa để cất giữ hoặc chuyển sang phiên khác. Tệp này không chứa API key, mật khẩu, báo cáo hoặc xác nhận của người kiểm tra.')
        with st.form('encrypt_input_export'):
            st.text_input('Mật khẩu mã hóa đầu vào (ít nhất 12 ký tự)',type='password',key='_export_password')
            st.form_submit_button('Tạo tệp đầu vào mã hóa',on_click=prepare_encrypted_download,args=(case_id,),disabled=not bool(blob))
        saved=st.session_state.get('_encrypted_download')
        if saved and saved['case_id']==case_id:
            st.download_button('Tải đầu vào mã hóa .ccenc',saved['data'],case_id+'_inputs.ccenc','application/octet-stream',key='download_encrypted')
        with st.form('decrypt_input_import'):
            st.file_uploader('Nhập lại tệp đầu vào .ccenc',type=['ccenc'],max_upload_size=22,key='_encrypted_upload')
            st.text_input('Mật khẩu giải mã đầu vào',type='password',key='_import_password')
            st.form_submit_button('Giải mã và mở hồ sơ',on_click=restore_encrypted_inputs)
        if st.session_state.get('_encryption_error'):st.error(st.session_state['_encryption_error'])
        elif st.session_state.get('_encryption_notice'):st.info(st.session_state['_encryption_notice'])
        st.caption('PDF/ZIP thường vẫn là bản rõ. Chỉ tệp .ccenc được bảo vệ bằng mật khẩu; giữ mật khẩu riêng, ứng dụng không khôi phục được mật khẩu đã mất.')

def configured_connection():
    if st.session_state.get('_api_source','API key của tôi') == 'API key của tôi':
        if not st.session_state.get('_personal_key'):
            raise ValueError('Mở Kết nối Gemini, nhập API key của bạn rồi bấm Lưu kết nối.')
        key = open_session(st.session_state['_personal_key'], encryption_key(), 'gemini-key').decode()
        return validate_connection(key, st.session_state['_personal_model'])
    code = secret('DEMO_ACCESS_CODE')
    if not code or not st.session_state.get('api_unlocked'):
        raise ValueError('Mở quyền dùng API key nhóm bằng mã truy cập trước.')
    key = secret('GEMINI_API_KEY')
    if not key or key.startswith('REPLACE_'):
        raise ValueError('Chưa cấu hình API key nhóm trong Secrets.')
    return validate_connection(key, st.session_state.get('_group_model_override') or secret('GEMINI_MODEL','gemini-3.5-flash-lite'))

def secret(name, default=''):
    try:
        return str(st.secrets.get(name, os.environ.get(name, default)))
    except (FileNotFoundError, st.errors.StreamlitSecretNotFoundError):
        return os.environ.get(name, default)

@st.cache_resource
def shared_budget():
    # Counters only; never store user dossiers/chats in a shared cache.
    return {'lock': threading.Lock(), 'times': []}

def reserve_call():
    api_key, model = configured_connection()
    slot = st.session_state.setdefault('_gemini_request_slot', {'lock': threading.Lock(), 'active': False})
    with slot['lock']:
        if slot['active']:
            raise ValueError('Gemini [REQUEST_PENDING]: Lượt trước vẫn đang kết thúc. Chưa gửi lượt mới; không mất thêm lượt demo.')
    personal = st.session_state.get('_api_source','API key của tôi') == 'API key của tôi'
    b = shared_budget()
    current = time.monotonic()
    with b['lock']:
        b['times'] = [x for x in b['times'] if current - x < 3600]
        if not personal and len(b['times']) >= 60:
            raise ValueError('Đã đạt giới hạn demo 60 lượt/giờ trên máy chủ này.')
        if current - st.session_state.get('last_api_call', -100) < 5:
            raise ValueError('Chờ ít nhất 5 giây giữa hai lượt API.')
        if st.session_state.get('api_calls', 0) >= 30:
            raise ValueError('Phiên này đã đạt giới hạn 30 lượt API.')
        if not personal:
            b['times'].append(current)
        st.session_state.last_api_call = current
        st.session_state.api_calls = st.session_state.get('api_calls', 0) + 1
    return GeminiClient(api_key, model, request_slot=slot)

def sample(cid):
    folder = ROOT / 'runtime/cases' / cid
    manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
    files = {d['source_type']: (folder / d['path']).read_bytes()
             for d in manifest['documents'] if d['available']}
    coverage = next(d for d in manifest['documents'] if d['source_type'] == 'bank_statement')
    state = protect_inputs(cid, files, coverage if coverage['available'] else None)
    sync(state)
    return state

def commit(state, reset_chat=True):
    sync(state)
    st.session_state.dossier = state
    if reset_chat:
        st.session_state.messages = []
    st.session_state.notice = 'Đã cập nhật. Kiểm tra nguồn và trạng thái trước khi tiếp tục.'
    st.rerun()

def mutate(fn, body):
    try:
        state = copy.deepcopy(st.session_state.dossier)
        fn(state, dict(body, expected_version=state['version']))
        commit(state)
    except (ValueError, TypeError, KeyError) as exc:
        st.error(str(exc))

def api_button(task, label, key):
    consent = st.checkbox('Tôi đồng ý gửi dữ liệu giả lập của hồ sơ này đến Google Gemini.', key=key+'_consent')
    current=st.session_state.dossier
    has_result=(bool(current.get('llm_runs')) if task=='extraction' else current['phase2']['classification'] is not None if task=='classification' else current['phase3']['summary'] is not None)
    allowed=task!='classification' or current['extraction_review']['status']=='Reviewed'
    reason=''
    try: configured_connection()
    except ValueError as exc: reason=str(exc)
    if not allowed:st.caption('Để chạy phân loại: đối chiếu nguồn và xác nhận trích xuất trước.')
    if reason:st.caption('Cần kết nối: '+reason)
    elif not consent:st.caption('Tích đồng ý gửi dữ liệu để bật tác vụ. Chỉ bấm nút mới gọi API.')
    failed=st.session_state.get('_api_errors',{}).get(key)
    if failed:
        title,hint=error_guidance(failed)
        st.error(title);st.caption(hint);error_details(failed)
    button_label='Thử lại · '+label if failed else label
    if st.button(button_label, key=key, type='secondary' if has_result else 'primary', disabled=not consent or not allowed or bool(reason)):
        try:
            client = reserve_call()
            with st.spinner('Đang chờ Gemini · tối đa 45 giây trên giao diện; không tự gửi lại…'):
                state = run_task(st.session_state.dossier, task, client)
            if task=='extraction':
                state['_intake_checked']=False
                st.session_state.page='Tiếp nhận tài liệu'
            record_api_success(client)
            st.session_state.setdefault('_api_errors',{}).pop(key,None)
            commit(state)
        except (ValueError, TypeError, KeyError) as exc:
            st.session_state.setdefault('_api_errors',{})[key]=str(exc)
            st.rerun()


def saved_result_ui(task, state, key):
    label='phân loại giao dịch' if task=='classification' else 'báo cáo'
    with st.expander('Dùng kết quả LLM đã lưu · '+label, expanded=False):
        st.write('Không cần khóa API. Tải prompt hiện tại, dùng ChatGPT bên ngoài rồi nhập kết quả JSON; hoặc chọn ZIP báo cáo cũ. Không tự khôi phục xác nhận của người kiểm tra.')
        if task=='classification' and state['extraction_review']['status']!='Reviewed':
            st.info('Đối chiếu nguồn và xác nhận phần trích xuất trước.');return
        try:
            prompt=classification_prompt(state) if task=='classification' else summary_prompt(state)
        except ValueError as exc:
            st.warning(str(exc));return
        st.download_button('Tải prompt '+label, prompt, state['case']['case_id']+'_'+task+'_prompt.txt',key=key+'prompt')
        with st.expander('Xem prompt để sao chép'):st.code(prompt,language=None)
        with st.form(key+'import'):
            upload=st.file_uploader('JSON hoặc ZIP kết quả '+label,type=['json','zip'],max_upload_size=10)
            raw=st.text_area('Hoặc dán JSON kết quả '+label)
            model=st.text_input('Tên công cụ/model tạo kết quả',placeholder='Ví dụ: ChatGPT — kết quả đã lưu')
            attest=st.checkbox('Đây là kết quả LLM đã nhận; chưa được xác minh bởi con người.')
            if st.form_submit_button('Nhập kết quả '+label):
                try:
                    data=upload.getvalue() if upload is not None else raw.encode('utf-8')
                    obj=read_result(data,task)
                    mutate(import_classification if task=='classification' else import_summary,{'result':obj,'model':model,'attest':attest})
                except (ValueError,TypeError,KeyError) as exc:st.error(str(exc))
        if task=='classification':
            candidate=ROOT/'incoming'/str(state['case']['case_id']+'_classification.json')
            if candidate.exists():
                st.caption('Ứng viên phân loại mẫu do ChatGPT soạn cho nguồn gốc. Chưa xác minh thu nhập; nguồn đã đổi sẽ bị từ chối.')
                st.download_button('Tải JSON phân loại mẫu '+state['case']['case_id'],candidate.read_bytes(),candidate.name,'application/json',key=key+'sample')
                if st.button('Nạp ứng viên ChatGPT đã lưu · '+state['case']['case_id'],key=key+'load'):
                    mutate(import_classification,{'result':read_result(candidate.read_bytes(),task),'model':'ChatGPT — ứng viên mẫu v0.7 đã lưu','attest':True})

def source_view(state, did, suffix):
    src = state['sources'].get(did)
    if not src:
        st.info('Nguồn chưa được cung cấp.')
        return
    with st.container(height=330,border=False):st.text(src['text'])
    ext = '.csv' if src['role'] == 'bank_statement' else '.pdf'
    st.download_button('Tải nguồn '+did, base64.b64decode(src['bytes_b64']),
                       file_name=did+ext, key='source_'+suffix+'_'+did)

def archive(state):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('case.json', json.dumps(state['case'], ensure_ascii=False, indent=2))
        z.writestr('review_and_log.json', json.dumps(public_state(state), ensure_ascii=False, indent=2))
        z.writestr('evidence_trace.json', json.dumps(state['traceability'], ensure_ascii=False, indent=2))
        z.writestr('chat.json', json.dumps(st.session_state.messages, ensure_ascii=False, indent=2))
        if state['phase3']['summary']:
            z.writestr('summary.txt', report_text(state))
            z.writestr('summary.pdf', pdf_bytes(copy.deepcopy(state)))
        for did, src in state['sources'].items():
            z.writestr('sources/'+did+('.csv' if src['role']=='bank_statement' else '.pdf'), base64.b64decode(src['bytes_b64']))
    return buf.getvalue()

from html import escape
import pandas as pd
import altair as alt
from phase2 import value
from presentation import money, ratio, checkpoints, workflow, next_action, income_rows, debt_rows
from pdf_report import pdf_bytes

PAGES=['Trang chủ','Hướng dẫn','Tổng quan','1 · Hồ sơ','2 · Kiểm tra','3 · Phân tích','4 · Báo cáo','Trợ lý hồ sơ','Bảo mật Excel']
# Use the same group logo for the browser tab and the in-app brand.
deploy_root=Path(os.environ.get('CREDITCHECK_DEPLOY_ROOT',str(ROOT)))
logo=deploy_root/'logo.png'
if not logo.exists():logo=ROOT/'assets/brand_logo.png'
if not logo.exists():logo=deploy_root/'1790301130067_5325247545233387896_g6287506212488219102_01bae03835e1c999662e363ca9e66ec9.jpg'
from PIL import Image
with Image.open(logo) as logo_image:
    browser_icon=logo_image.copy()
st.set_page_config(page_title='Project 1 · CreditCheck',page_icon=browser_icon,layout='wide')


def go(page):st.session_state.page=page

def commit(state, reset_chat=True):
    sync(state)
    st.session_state.dossier=state
    st.session_state.portfolio[state['case']['case_id']]=copy.deepcopy(state)
    if reset_chat:st.session_state.messages=[]
    st.session_state.notice='Đã lưu thay đổi trong phiên.'
    st.rerun()

def open_case(cid):
    old=st.session_state.get('dossier')
    if old:st.session_state.portfolio[old['case']['case_id']]=copy.deepcopy(old)
    st.session_state.dossier=copy.deepcopy(st.session_state.portfolio[cid]) if cid in st.session_state.portfolio else sample(cid)
    st.session_state.messages=[]
    st.session_state.page='Tiếp nhận tài liệu'

def load_sample(cid):
    # Explicit demo choice always opens a fresh sample, never an uploaded namesake.
    old=st.session_state.get('dossier')
    if old:st.session_state.portfolio[old['case']['case_id']]=copy.deepcopy(old)
    result=sample(cid)
    result['_source_kind']='sample'
    st.session_state.page='Tiếp nhận tài liệu'
    commit(result)

def restore_demo():
    old=st.session_state.get('dossier')
    if old:st.session_state.portfolio[old['case']['case_id']]=copy.deepcopy(old)
    result=json.loads((ROOT/'seed/HS01_session.json').read_text(encoding='utf-8'))
    st.session_state.get('_input_vault',{}).pop('HS01',None)
    if st.session_state.get('_encrypted_download',{}).get('case_id')=='HS01':
        st.session_state.pop('_encrypted_download',None)
    result['_demo_restored']=True
    result['_intake_checked']=True
    result['_source_kind']='saved_demo'
    st.session_state.page='1 · Hồ sơ'
    commit(result)



def next_button(target, enabled=True, reason=''):
    st.divider()
    if not enabled:st.info('Chưa thể tiếp tục: '+reason)
    st.button('Bước tiếp theo → '+{'1 · Hồ sơ':'Tổng hợp hồ sơ','4 · Báo cáo':'Tóm tắt thẩm định'}.get(target,target.split(' · ')[-1]),type='secondary' if st.session_state.page in ['1 · Hồ sơ','4 · Báo cáo'] else 'primary',disabled=not enabled,
              on_click=go,args=(target,),key='next_'+target)

def readable_alerts(s):
    for alert in s['traceability']['alerts']:
        with st.expander(alert['message'],expanded=False):
            st.caption(alert['alert_id']+' · Quy tắc Python · '+alert['code'])
            st.write(alert['rule'])
            for i,ev in enumerate(alert['evidence']):
                st.caption(ev['document_id']+' · '+ev['locator'])
                st.text(ev.get('quote') or 'Không có trích dẫn; xem trạng thái tiếp nhận hoặc metadata của nguồn.')
                if ev.get('quote_found_in_source') is True:st.caption('✓ Trích dẫn khớp tài liệu đã nhận · SHA-256: '+str(ev.get('source_sha256',''))[:16]+'…')
                with st.expander('Xem tài liệu làm căn cứ '+str(i+1)):
                    src=s['sources'].get(ev['document_id'])
                    if src and src.get('pages') and ev.get('quote'):
                        html,_=highlighted_source(src,[ev])
                        with st.container(height=260,border=False):st.markdown(html,unsafe_allow_html=True)
                    elif ev.get('original_row'):st.json(ev['original_row'])
                    source_view(s,ev['document_id'],alert['alert_id']+'_'+str(i))
            with st.expander('Chi tiết quy tắc'):
                st.json(alert['rule_inputs'])
    if not s['traceability']['alerts']:st.info('Chưa kiểm tra đầy đủ: chưa có cảnh báo từ các phép kiểm tra đã chạy; còn cần xác minh nguồn thu.' if s['phase2']['income_review'] is None else 'Đã chạy các kiểm tra hiện tại: không phát hiện cảnh báo. Vẫn cần người thẩm định xem xét, không tự duyệt vay.')

def chart(rows,x,y,title,domain=None):
    if not rows:
        st.info('Chưa có đủ dữ liệu để vẽ biểu đồ này.')
        return
    from financial_charts import amount_chart
    st.altair_chart(amount_chart(rows,x,y,title,domain),width='stretch',theme=None)


def technical_tools(s):
    with st.expander('Dữ liệu, nguồn gốc LLM và nhật ký · nâng cao'):
        st.caption('Không cần đọc JSON để sử dụng quy trình chính.')
        st.json(s['llm_runs'])
        st.json(s['events'])
        st.download_button('Tải dữ liệu JSON',json.dumps(s['case'],ensure_ascii=False,indent=2),s['case']['case_id']+'_case.json','application/json')
        st.download_button('Tải bảng truy vết',json.dumps(s['traceability'],ensure_ascii=False,indent=2),s['case']['case_id']+'_trace.json','application/json')

if 'page' not in st.session_state:st.session_state.page='Trang chủ'
if 'dossier' not in st.session_state:st.session_state.dossier=None
if 'messages' not in st.session_state:st.session_state.messages=[]
if 'portfolio' not in st.session_state:st.session_state.portfolio={}
state=st.session_state.dossier
if state:
    sync(state)
    cid=state['case']['case_id'];prefix=cid+'_'+str(state['version'])+'_'
    st.session_state.portfolio[cid]=copy.deepcopy(state)


def connection_ui():
    source=st.radio('Nguồn API key',['API key của tôi','API key của nhóm'],key='_api_source')
    if source == 'API key của tôi':
        st.caption('Key chỉ dùng trong phiên này, không ghi vào PDF/ZIP hoặc nhật ký. Máy chủ dùng key để gọi Google Gemini.')
        with st.form('personal_connection'):
            st.text_input('API key Gemini của bạn',type='password',key='_api_key_input')
            st.text_input('Tên model Gemini',value=st.session_state.get('_personal_model','gemini-3.5-flash-lite'),key='_model_input')
            st.form_submit_button('Lưu kết nối',on_click=save_personal_connection)
        if st.session_state.get('_connection_error'):st.error(st.session_state['_connection_error'])
        if st.session_state.get('_personal_key'):
            st.success('Đã lưu key cho phiên này. Quyền API được kiểm tra khi chạy tác vụ.')
            st.caption('Model đang dùng: '+st.session_state['_personal_model'])
        st.button('Xóa API key khỏi phiên',on_click=clear_personal_connection)
    else:
        st.session_state['_group_default_model'] = secret('GEMINI_MODEL','gemini-3.5-flash-lite')
        st.caption('Đã cấu hình key nhóm' if secret('GEMINI_API_KEY') and not secret('GEMINI_API_KEY').startswith('REPLACE_') else 'Chưa cấu hình key nhóm.')
        code=st.text_input('Mã truy cập API của nhóm',type='password',key='access_input')
        if st.button('Mở quyền chạy API'):
            expected=secret('DEMO_ACCESS_CODE')
            st.session_state.api_unlocked=bool(expected and not expected.startswith('REPLACE_') and hmac.compare_digest(code.encode(),expected.encode()))
            if st.session_state.api_unlocked:st.success('Đã mở quyền cho phiên này.')
            else:st.error('Mã chưa đúng hoặc chưa cấu hình.')
        st.caption('Model nhóm: '+(st.session_state.get('_group_model_override') or st.session_state['_group_default_model']))
        if st.session_state.get('api_unlocked'):
            with st.expander('Chọn model nhóm cho phiên này'):
                st.caption('Chỉ đổi model trong phiên đang mở; không thay API key hoặc Secrets của nhóm. Dùng đúng model do API trả về và kiểm tra lại kết nối.')
                with st.form('group_model_form'):
                    st.text_input('Tên model nhóm cho phiên này',value=st.session_state.get('_group_model_override') or st.session_state['_group_default_model'],key='_group_model_input')
                    st.form_submit_button('Lưu model cho phiên này',on_click=save_group_model)
                if st.session_state.get('_group_model_error'):st.error(st.session_state['_group_model_error'])
                st.button('Dùng lại model trong Secrets',on_click=reset_group_model,key='group_model_reset')
    connection_diagnostics()

shell_styles()
page=navigation(logo,connection_ui,go)
if page in WORK_PAGES and (not state or not state.get('_intake_checked')):
    page='Tiếp nhận tài liệu'
    st.session_state.page=page
if page in WORK_PAGES:
    render_steps(state,page,go)

labels={'Tổng quan':('TỔNG QUAN HỒ SƠ','Mỗi hồ sơ, một hành trình rõ ràng.'),
        '1 · Hồ sơ':('BƯỚC 01 / 04','Tổng hợp hồ sơ đã tiếp nhận.'),
        '2 · Kiểm tra':('BƯỚC 02 / 04','Kiểm tra những gì hệ thống đã hiểu.'),
        '3 · Phân tích':('BƯỚC 03 / 04','Hiểu chỉ số và căn cứ cảnh báo.'),
        '4 · Báo cáo':('BƯỚC 04 / 04','Tóm tắt thẩm định có căn cứ.'),
        'Trợ lý hồ sơ':('TRỢ LÝ THEO NGỮ CẢNH','Hỏi về hồ sơ đang mở.'),
        'Bảo mật Excel':('BẢO MẬT DỮ LIỆU EXCEL','Tạo bản dữ liệu đã giả danh hóa.')}
if page in labels:
    eyebrow,title=labels[page]
    work_title(eyebrow,title)
    task_brief(page)
if page in WORK_PAGES:
    case_col,overview_col=st.columns([4,1],vertical_alignment='center')
    with case_col:st.markdown(case_context(state),unsafe_allow_html=True)
    with overview_col:st.button('Tổng quan hồ sơ',type='tertiary',on_click=go,args=('Tổng quan',),key='work_overview')
    if page in ['Tổng quan','3 · Phân tích']:
        with st.container(key='cc_summary_strip'):
            cols=st.columns(4)
            cols[0].metric('Trả góp mới/tháng',money(state['phase2']['metrics']['monthly_payment_vnd']))
            cols[1].metric('Thu nhập đã xác minh/tháng',money(state['phase2']['metrics']['validated_monthly_income_vnd']))
            cols[2].metric('DTI · trả nợ / thu nhập',ratio(state['phase2']['metrics']['dti_pct']))
            with cols[3],st.container(key='cc_alert_metric'):st.metric('Cảnh báo cần xem',alert_label(state))
    if 'notice' in st.session_state:st.success(st.session_state.pop('notice'))
    if state.get('_demo_restored'):st.caption('Đang xem HS01 đã lưu · xác nhận giả lập kèm theo · không có lần gọi API mới. Mở lại mẫu gốc hoặc hồ sơ khác để thực hành từ đầu.')
    if state['traceability']['alerts']:st.warning('Cảnh báo chính: '+state['traceability']['alerts'][0]['message'])
    st.caption(str(sum(checkpoints(state)))+'/4 bước hoàn thành · '+next_action(state))

if page=='Trang chủ':
    landing(go)
elif page=='Hướng dẫn':
    guide(go)
elif page=='Tổng quan':
    st.subheader('Tiến độ hồ sơ đang mở')
    a,b=st.columns([1,2])
    done=sum(checkpoints(state))
    with a:
        data=pd.DataFrame({'Trạng thái':['Đã hoàn thành','Cần xử lý'],'Số bước':[done,4-done]})
        ring=alt.Chart(data).mark_arc(innerRadius=65,outerRadius=90).encode(theta='Số bước:Q',
            color=alt.Color('Trạng thái:N',scale=alt.Scale(domain=['Đã hoàn thành','Cần xử lý'],range=['#087F8C','#DCE4EF']),legend=None),tooltip=['Trạng thái','Số bước'])
        text=alt.Chart(pd.DataFrame({'Nhãn':[str(done)+'/4']})).mark_text(fontSize=28,fontWeight='bold',color='#172B4D').encode(text='Nhãn:N')
        st.altair_chart((ring+text).properties(height=220).configure_view(stroke=None).configure(background='#F4F7FB'),width='stretch',theme=None)
    with b:
        st.dataframe(workflow(state),hide_index=True,width='stretch')
        st.caption('Đủ nguồn → Kiểm tra & xác minh thu nhập → Có chỉ số → Báo cáo đã kiểm tra. Hồ sơ lỗi có thể dừng ở bước cần bổ sung.')
    st.subheader('Tất cả hồ sơ trong phiên')
    rows=[]
    for key,s in st.session_state.portfolio.items():
        sync(s)
        rows.append({'Hồ sơ':key,'Người vay':value(s,'full_name') or 'Chưa có',
                     'Nguồn đã nhận':str(sum(d['available'] for d in s['case']['documents']))+'/3',
                     'Trạng thái':'Thiếu thông tin' if s['phase3']['report_status']=='Insufficient information' else 'Cần rà soát',
                     'Tiến độ':str(sum(checkpoints(s)))+'/4', 'Cảnh báo':alert_label(s)})
    st.dataframe(rows,hide_index=True,width='stretch')
    selection=st.selectbox('Chọn hồ sơ để tiếp tục',list(st.session_state.portfolio),key='overview_case')
    st.button('Mở hồ sơ đã chọn',type='primary',on_click=open_case,args=(selection,))
    st.caption('Các hồ sơ mẫu bắt đầu bằng dữ liệu đọc theo mẫu. Kết quả kiểm tra trong phiên được giữ khi chuyển hồ sơ; chưa lưu lâu dài theo tài khoản.')
    st.subheader('Bạn sẽ làm gì?')
    st.dataframe([{'Bước':'01 · Hồ sơ','Bạn làm':'Chọn/tải ba nguồn; trích xuất thông tin'},
                  {'Bước':'02 · Kiểm tra','Bạn làm':'Đối chiếu dữ liệu; kiểm tra giao dịch và xác minh nguồn thu'},
                  {'Bước':'03 · Phân tích','Bạn làm':'Xem DTI, trả góp, cảnh báo và căn cứ'},
                  {'Bước':'04 · Báo cáo','Bạn làm':'Tạo nháp, đọc và xác nhận; tải PDF'}],hide_index=True,width='stretch')
    next_button('1 · Hồ sơ')

elif page=='Tiếp nhận tài liệu':
    from intake_ui import render_intake
    render_intake(state,ROOT,protect_inputs,commit,load_sample,restore_demo,api_button,
                  readable_alerts,encryption_ui,go,open_case)

elif page=='1 · Hồ sơ':
    from intake_ui import comparison_rows, normalized_rows
    st.subheader('Thông tin chính từ ba nguồn')
    st.caption('Kết quả đọc tài liệu chưa phải xác minh độc lập. Ô chưa đọc được giữ trống; không tự điền từ hồ sơ mẫu.')
    st.dataframe(comparison_rows(state),hide_index=True,width='stretch')
    st.download_button('Tải bảng dữ liệu chuẩn hóa JSON',json.dumps(state['case'],ensure_ascii=False,indent=2),cid+'_normalized.json','application/json')
    with st.expander('Tất cả trường đã trích xuất và căn cứ'):
        st.dataframe(normalized_rows(state),hide_index=True,width='stretch')
    st.subheader('Thông tin thiếu và mâu thuẫn cần xử lý')
    readable_alerts(state)
    st.button('Bổ sung hoặc thay tài liệu',on_click=go,args=('Tiếp nhận tài liệu',),type='secondary')
    next_button('2 · Kiểm tra')
    with st.expander('Trích xuất lại bằng Gemini · cần đối chiếu lại sau khi chạy'):
        api_button('extraction','Chạy Gemini trích xuất',prefix+'extract')
    technical_tools(state)

elif page=='2 · Kiểm tra':
    with st.expander('1. Đối chiếu thông tin với nguồn',expanded=state['extraction_review']['status']!='Reviewed'):
        docs={d['document_id']:d for d in state['case']['documents'] if d['available'] and d['source_type']!='bank_statement'}
        if docs:
            did=st.selectbox('Tài liệu cần kiểm tra',list(docs),key=prefix+'check_doc')
            fields=docs[did]['fields']
            left,right=st.columns([1,1],gap='medium')
            with left,st.container(key='cc_field_panel'):
                st.markdown('**Thông tin đã trích xuất**')
                selected_field=st.selectbox('Chọn trường để xem căn cứ',list(fields),format_func=lambda k:LABELS.get(k,k),key=prefix+did+'_focus')
                evidence=[e for e in fields[selected_field].get('evidence',[]) if e.get('document_id')==did]
                with st.container(height=320,border=False):
                    st.dataframe([{'Thông tin':LABELS.get(k,k),'Giá trị':display_value(k,f['value'])} for k,f in fields.items()],hide_index=True,width='stretch',height=300)
                st.caption('Đang đối chiếu: '+LABELS.get(selected_field,selected_field))
                st.write(display_value(selected_field,fields[selected_field]['value']))
            with right,st.container(key='cc_source_panel'):
                st.markdown('**Tài liệu nguồn · '+escape(did)+'**')
                src=state['sources'].get(did)
                if src:
                    html,matches=highlighted_source(src,evidence)
                    with st.container(height=380,border=False):st.markdown(html,unsafe_allow_html=True)
                    st.caption('Đoạn tô vàng khớp trích dẫn trong nguồn; chưa chứng minh tài liệu là thật.' if matches else 'Chưa tìm thấy trích dẫn khớp trong văn bản nguồn. Cần kiểm tra thủ công.')
                    st.download_button('Tải nguồn '+did,base64.b64decode(src['bytes_b64']),file_name=did+'.pdf',key='source_check_'+did)
                else:st.info('Nguồn chưa được cung cấp.')
            with st.expander('Sửa thông tin đọc sai · cần căn cứ'):
                field=st.selectbox('Trường cần sửa',list(docs[did]['fields']),key=prefix+'field')
                with st.form(prefix+'edit_field'):
                    raw=st.text_input('Giá trị JSON (số hoặc chuỗi trong dấu nháy)',value=json.dumps(docs[did]['fields'][field]['value'],ensure_ascii=False))
                    pg=st.number_input('Trang nguồn',min_value=1,value=1)
                    quote=st.text_input('Trích dẫn nguyên văn')
                    reviewer=st.text_input('Người sửa')
                    reason=st.text_input('Lý do sửa')
                    if st.form_submit_button('Lưu sửa và kiểm tra lại'):
                        try:
                            v=json.loads(raw)
                            ev=[] if v is None else [{'document_id':did,'locator_type':'pdf_page_field','locator':f'page={pg}; field={LABELS[field]}','quote':quote}]
                            mutate(edit_field,{'document_id':did,'field':field,'value':v,'evidence':ev,'reviewer':reviewer,'reason':reason})
                        except ValueError as exc:st.error(str(exc))
        with st.form(prefix+'review_extraction'):
            who,note_col=st.columns([1,2])
            with who:name=st.text_input('Người kiểm tra')
            with note_col:note=st.text_area('Ghi chú đối chiếu nguồn',height=90)
            checked=st.checkbox('Tôi đã đối chiếu các trường với tài liệu nguồn.')
            if st.form_submit_button('Xác nhận phần trích xuất',type='primary'):
                mutate(review_extraction_phase2,{'reviewer':name,'reason':note,'checked':checked})
        st.caption('Xác nhận này chỉ kiểm tra thông tin đọc đúng tài liệu, chưa xác minh thu nhập.')
    with st.expander('2. Kiểm tra giao dịch và nguồn thu',expanded=state['extraction_review']['status']=='Reviewed'):
        if state['extraction_review']['status']!='Reviewed':st.info('Cần xác nhận trích xuất trước khi nhập phân loại.')
        api_button('classification','Chạy Gemini phân loại',prefix+'classify')
        saved_result_ui('classification',state,prefix+'saved_classification')
        classification=state['phase2']['classification']
        if classification:
            scope=st.radio('Lọc giao dịch',['Tất cả','Chưa rõ','Lương','Khoản khác'],horizontal=True,key=prefix+'tx_filter')
            filter_labels={'Chưa rõ':'uncertain','Lương':'salary','Khoản khác':'other'}
            rows=[r for r in classification['rows'] if scope=='Tất cả' or r['label']==filter_labels[scope]]
            transactions={t['transaction_id']:t for t in state['case']['transactions']}
            if rows:
                st.dataframe([{'Giao dịch':r['transaction_id'],'Ngày':transactions.get(r['transaction_id'],{}).get('date',''),
                               'Số tiền (đ)':transactions.get(r['transaction_id'],{}).get('amount_vnd'),
                               'Loại':{'salary':'Lương','other':'Khoản khác','uncertain':'Chưa rõ'}[r['label']],
                               'Lý do':r['reason']} for r in rows],hide_index=True,width='stretch',
                               column_config={'Số tiền (đ)':st.column_config.NumberColumn(format='localized')})
            else:st.info('Không có giao dịch thuộc bộ lọc này.')
            with st.expander('Xem sao kê và sửa nhãn có căn cứ'):
                bank_id=next((k for k,s in state['sources'].items() if s['role']=='bank_statement'),None)
                if bank_id:
                    st.dataframe(pd.DataFrame(state['case']['transactions'])[['transaction_id','date','direction','amount_vnd','counterparty','description']],hide_index=True,width='stretch',column_config={'transaction_id':'Mã giao dịch','date':'Ngày','direction':'Chiều tiền IN/OUT','amount_vnd':st.column_config.NumberColumn('Số tiền (đ)',format='localized'),'counterparty':'Đối tác','description':'Nội dung'})
                    st.download_button('Tải sao kê gốc',base64.b64decode(state['sources'][bank_id]['bytes_b64']),bank_id+'.csv',key='bank_review_download')
                tid=st.selectbox('Giao dịch cần kiểm tra',[r['transaction_id'] for r in classification['rows']],key=prefix+'tid')
                with st.form(prefix+'edit_class'):
                    label=st.selectbox('Nhãn mới',['salary','other','uncertain'],index=['salary','other','uncertain'].index(next(r['label'] for r in classification['rows'] if r['transaction_id']==tid)),format_func=lambda x:{'salary':'Lương','other':'Khoản khác','uncertain':'Chưa rõ'}[x])
                    reviewer=st.text_input('Người kiểm tra nhãn');reason=st.text_input('Lý do thay đổi');note=st.text_area('Căn cứ bổ sung đã kiểm tra')
                    if st.form_submit_button('Cập nhật nhãn'):mutate(edit_classification,{'transaction_id':tid,'label':label,'reviewer':reviewer,'reason':reason,'supporting_note':note})
        pre=state['phase2'].get('preview')
        if pre:
            st.metric('Lương bình quân xem trước · chưa xác minh',money(pre['mean_salary_vnd']))
            if pre['unresolved_transaction_ids']:st.warning('Còn '+str(len(pre['unresolved_transaction_ids']))+' khoản chưa rõ. Cần căn cứ trước khi xác minh.')
            with st.expander('Chi tiết tổng hợp nguồn thu'):st.json(pre)
        coverage=next(d for d in state['case']['documents'] if d['source_type']=='bank_statement')
        with st.form(prefix+'income_review'):
            a,b=st.columns(2)
            with a:start=st.text_input('Từ ngày YYYY-MM-DD',value=coverage.get('coverage_start') or '2026-07-01')
            with b:end=st.text_input('Đến ngày YYYY-MM-DD',value=coverage.get('coverage_end') or '2026-09-30')
            who,note_col=st.columns([1,2])
            with who:name=st.text_input('Người xác minh thu nhập')
            with note_col:note=st.text_area('Ghi chú xác minh và căn cứ dùng thu nhập sao kê',height=90)
            checked=st.checkbox('Đã đối chiếu nhãn và nguồn trả lương.');complete=st.checkbox('Đã kiểm tra kỳ sao kê đầy đủ.')
            gap=st.checkbox('Đã xem chênh lệch thu nhập nếu có và ghi căn cứ ở trên.')
            if st.form_submit_button('Xác minh thu nhập và tính chỉ số',type='primary'):
                mutate(verify_income,{'coverage_start':start,'coverage_end':end,'reviewer':name,'reason':note,'checked':checked,'coverage_checked':complete,'acknowledge_gap':gap})
    enabled=state['phase2']['income_review'] is not None
    next_button('3 · Phân tích',enabled,'Cần đủ nguồn, phân loại rõ và xác minh thu nhập. '+next_action(state))
    if not enabled:st.button('Xem cảnh báo và dữ liệu chưa đủ',on_click=go,args=('3 · Phân tích',))

elif page=='3 · Phân tích':
    st.subheader('Hai chỉ số Python · PMT và DTI')
    st.caption('PMT là khoản trả góp mới mỗi tháng; DTI là tỷ lệ tổng nghĩa vụ trả nợ trên thu nhập đã xác minh. Gemini chỉ diễn giải kết quả Python.')
    st.subheader('Thu nhập và nghĩa vụ trả nợ')
    m=state['phase2']['metrics'];old_debt=value(state,'existing_monthly_debt_vnd')
    if m['dti_pct'] is not None:
        st.markdown('<div class="cc-dti-equation">DTI = ('+money(old_debt)+' + '+money(m['monthly_payment_vnd'])+') ÷ '+money(m['validated_monthly_income_vnd'])+' × 100 = <strong>'+ratio(m['dti_pct'])+'</strong></div>',unsafe_allow_html=True)
        st.caption('Trả nợ hiện tại/tháng + trả góp mới/tháng, chia thu nhập đã xác minh/tháng. Ngưỡng 40% là giả định bài tập; không tự duyệt vay.')
    else:st.info('Chưa tính DTI: cần xác minh nguồn thu và các đầu vào bắt buộc tại bước Kiểm tra.')
    from financial_charts import comparison_domain
    incomes,debts=income_rows(state),debt_rows(state)
    domain=comparison_domain(incomes,debts)
    st.caption('Hai biểu đồ dùng cùng thang đo, bắt đầu từ 0 nếu không có số âm. Số trên thanh là đồng/tháng.')
    a,b=st.columns(2)
    with a:
        chart(incomes,'Thu nhập (đ)','Nguồn','Thu nhập theo nguồn',domain)
        st.caption('Khai báo và xác nhận là dữ kiện tài liệu; chỉ sao kê đã xác minh mới là đầu vào tính DTI.')
    with b:
        chart(debts,'Số tiền (đ)','Khoản','Thu nhập sau nghĩa vụ trả nợ',domain)
        st.caption('Phần còn lại chưa trừ chi phí sinh hoạt, không phải tiền tiết kiệm.')
    st.write('DTI là tổng nghĩa vụ trả nợ mỗi tháng chia thu nhập đã xác minh mỗi tháng. Chỉ số chưa có được giữ trống, không biến thành 0.')
    st.subheader('Cảnh báo và căn cứ')
    readable_alerts(state)
    with st.expander('Giả định và cách tính · có thể điều chỉnh'):
        st.caption('Ngưỡng DTI 40%, độ lệch 20% là giả định bài tập; chưa tính phí/bảo hiểm.')
        with st.form(prefix+'rate'):
            rate=st.number_input('Lãi danh nghĩa %/năm',min_value=0.0,max_value=100.0,value=state['phase2']['config']['annual_nominal_rate']*100)
            name=st.text_input('Người thay giả định');note=st.text_input('Lý do thay lãi suất')
            if st.form_submit_button('Tính lại với lãi suất mới'):mutate(set_rate,{'annual_nominal_rate':rate/100,'reviewer':name,'reason':note})
        st.json(state['phase2'].get('calculation_trace'))
    next_button('4 · Báo cáo')
    st.caption('Có thể tạo báo cáo ghi thiếu thông tin. Điều đó không tự xác minh thu nhập hoặc cho phép duyệt vay.')

elif page=='4 · Báo cáo':
    summary=state['phase3']['summary']
    # Existing output is the main task; regenerating is a secondary tool.
    with st.expander('Tạo lại báo cáo bằng Gemini' if summary else 'Tạo báo cáo bằng Gemini',expanded=not bool(summary)):
        api_button('summary','Chạy Gemini tạo báo cáo',prefix+'summary')
        saved_result_ui('summary',state,prefix+'saved_summary')
        with st.expander('Công cụ dự phòng · bản nháp bằng quy tắc'):
            st.caption('Để thử PDF khi API chưa sẵn sàng: tạo bản nháp bằng quy tắc, ghi rõ không phải LLM. Không tự xác minh hoặc duyệt vay.')
            if st.button('Tạo bản nháp quy tắc · không dùng API',key=prefix+'rule_draft'):mutate(rule_draft,{})
    summary=state['phase3']['summary']
    if summary:
        saved=summary.get('mode')!='API_DIRECT'
        st.caption('Bản nháp bằng quy tắc Python · không phải LLM' if summary.get('mode')=='RULE_BASED' else ('Kết quả LLM đã lưu/nhập trước đó' if saved else 'Báo cáo từ lần gọi Gemini trực tiếp'))
        header,download=st.columns([3,1],vertical_alignment='center')
        with header:st.markdown('**'+('Đã kiểm tra nội dung' if state['phase3']['content_review'] else 'Bản nháp · chưa kiểm tra')+'** · '+status_label(state))
        with download:st.download_button('Tải báo cáo PDF',pdf_bytes(copy.deepcopy(state)),cid+'_Credit_Review.pdf','application/pdf',type='primary',key='report_pdf_top')
        st.caption('Bản xuất giữ nguyên trạng thái kiểm tra và giới hạn; không phải giấy duyệt vay.')
        with st.container(key='cc_report_paper'):
            st.markdown('<div class="cc-report-heading"><span>Credit Review Summary · '+escape(cid)+'</span><span class="cc-badge">'+('Đã kiểm tra' if state['phase3']['content_review'] else 'Bản nháp')+'</span></div>',unsafe_allow_html=True)
            for key,label in [('overview','Tóm tắt hồ sơ'),('metric_explanations','Diễn giải chỉ số'),('limitations','Giới hạn'),('verification_questions','Câu hỏi cần xác minh')]:
                st.subheader(label)
                for row_index,row in enumerate(summary['result'][key]):
                    st.write(row['text'])
                    with st.expander('Căn cứ: '+', '.join(row['refs'])):
                        for ref in row['refs']:
                            st.caption(ref)
                            if ref in state['sources']:source_view(state,ref,'summary_'+key+'_'+str(row_index))
                            else:st.json(state['phase3']['context']['references'][ref])
        st.subheader('Cảnh báo rủi ro và dữ liệu còn thiếu · căn cứ trực tiếp')
        readable_alerts(state)
        st.subheader('Xác nhận nội dung trước khi bàn giao')
        with st.form(prefix+'summary_review'):
            who,note_col=st.columns([1,2])
            with who:name=st.text_input('Người kiểm tra báo cáo')
            with note_col:note=st.text_area('Ghi chú kiểm tra nội dung',height=90)
            facts=st.checkbox('Đã kiểm tra số liệu, nguồn, cảnh báo và thông tin thiếu.')
            limits=st.checkbox('Đã kiểm tra giới hạn và câu hỏi xác minh; đây không phải quyết định vay.')
            if st.form_submit_button('Xác nhận đã kiểm tra nội dung'):
                from phase3 import review_summary
                mutate(review_summary,{'reviewer':name,'reason':note,'checked_facts':facts,'checked_limits':limits})
        st.subheader('Tải bản báo cáo')
        st.caption('PDF giữ trạng thái bản nháp/đã kiểm tra, nguồn và giới hạn; không phải giấy duyệt vay.')
        st.download_button('Tải báo cáo PDF',pdf_bytes(copy.deepcopy(state)),cid+'_Credit_Review.pdf','application/pdf',type='secondary')
        with st.expander('Tải TXT, ZIP và dữ liệu nâng cao'):
            st.download_button('Tải báo cáo TXT',report_text(state),cid+'_Credit_Review_Summary.txt')
            st.download_button('Tải ZIP báo cáo và hồ sơ',archive(state),cid+'_review.zip','application/zip')
            st.json(summary['result'])
    else:
        st.info('Chưa có báo cáo. Chạy Gemini, nhập kết quả LLM đã lưu hoặc tạo bản nháp quy tắc để thử PDF.')
        st.markdown('**Báo cáo sẽ gồm:** Tóm tắt hồ sơ → Chỉ số Python → Cảnh báo và thông tin thiếu → Căn cứ → Câu hỏi xác minh.')
        st.caption('Chưa có đầu ra để tải. Tạo báo cáo ở vùng phía trên; có thể lập báo cáo ghi rõ dữ liệu còn thiếu.')
    st.button('Quay về tổng quan hồ sơ',on_click=go,args=('Tổng quan',))

elif page=='Bảo mật Excel':
    st.caption('Xử lý trên máy chủ trong phiên · Không gửi Excel đến Gemini · Giả danh hóa, không đặt mật khẩu cho workbook.')
    source_col,rules_col=st.columns([3,2],gap='large')
    deployed=Path(os.environ.get('CREDITCHECK_DEPLOY_ROOT',str(ROOT)))/'data_raw.xlsx'
    data=None;input_error='';inspection=None
    with source_col:
        st.subheader('01 · Chọn dữ liệu')
        source=st.radio('Nguồn dữ liệu Excel',['Tải file từ máy','data_raw.xlsx trên GitHub'],key='_excel_source',horizontal=True)
        if source=='Tải file từ máy':
            upload=st.file_uploader('Chọn data_raw.xlsx',type=['xlsx'],max_upload_size=10,key='_excel_upload')
            if upload is not None:data=upload.getvalue()
        elif deployed.exists() and deployed.stat().st_size<=10*1024*1024:
            data=deployed.read_bytes();st.caption('Đang dùng data_raw.xlsx cạnh file khởi chạy.')
        else:input_error='Chưa thấy data_raw.xlsx hợp lệ (tối đa 10 MB). Chọn file từ máy để tiếp tục.'
        st.download_button('Tải Excel mẫu · dữ liệu giả lập',example_excel(),'data_raw_mau_gia_lap.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',type='tertiary')
    current_hash=hashlib.sha256(data).hexdigest() if data else None
    if data:
        cached=st.session_state.get('_excel_inspected')
        if not cached or cached['hash']!=current_hash:
            try:
                prepared=inspect_excel(data)
                cached={'hash':current_hash,'rows':len(prepared['rows']),'companies':len(prepared['companies']),'error':''}
            except (ValueError,TypeError,KeyError) as exc:cached={'hash':current_hash,'error':str(exc)}
            st.session_state['_excel_inspected']=cached
        inspection=cached;input_error=cached['error']
    with rules_col:
        st.subheader('02 · Kiểm tra quy tắc')
        st.write('Giữ nguyên năm và 12 trường tài chính. Mã doanh nghiệp được giữ liên kết qua các năm trong cùng phiên; người phụ trách dùng STAFF_001…')
        with st.expander('Xem bảng quy tắc đã chốt'):
            st.dataframe(rule_rows(),hide_index=True,width='stretch')
        st.caption('Tối đa 10 MB, 5.000 dòng, một sheet và đúng 20 trường. Công thức và cột lạ cần đối chiếu trước.')
        if input_error:
            st.error(input_error)
            st.session_state.pop('_excel_result',None)
        elif inspection:
            st.success('Đầu vào hợp lệ · '+str(inspection['rows'])+' dòng · '+str(inspection['companies'])+' doanh nghiệp.')
        else:st.caption('Chọn file để kiểm tra đầu vào và bật nút xử lý.')
        existing_result=st.session_state.get('_excel_result',{})
        current_result=existing_result.get('source_hash')==current_hash and existing_result.get('source_choice')==source
        if st.button('Xử lý bảo mật Excel',type='secondary' if current_result else 'primary',disabled=not bool(data) or bool(input_error)):
            try:
                with st.spinner('Đang giả danh hóa và đối chiếu số liệu…'):
                    result=protect_excel(data,encryption_key(),st.session_state.get('_excel_staff_map'))
                result.update(source_hash=current_hash,source_choice=source)
                st.session_state['_excel_staff_map']=result.pop('staff_map')
                st.session_state['_excel_result']=result
                st.rerun()
            except (ValueError,TypeError,KeyError) as exc:
                st.session_state.pop('_excel_result',None);st.error(str(exc))
    result=st.session_state.get('_excel_result')
    st.subheader('03 · Kết quả an toàn để chia sẻ')
    if result and result['source_hash']==current_hash and result['source_choice']==source:
        cols=st.columns(3)
        cols[0].metric('Dòng dữ liệu',result['row_count'])
        cols[1].metric('Cột sau xử lý',len(result['headers']))
        cols[2].metric('Doanh nghiệp',result['company_count'])
        st.success('Đã đối chiếu '+str(result['row_count'])+' dòng: năm và cả 12 trường tài chính giữ nguyên. Mã doanh nghiệp liên kết nhất quán trong dữ liệu đã xử lý.')
        st.download_button('Tải data_encrypted.xlsx',result['data'],'data_encrypted.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',type='primary')
        st.dataframe(pd.DataFrame(result['rows'][:20],columns=result['headers']),hide_index=True,width='stretch',column_config={name:st.column_config.NumberColumn(format='localized') for name in ['Năm']+FINANCIAL})
        with st.expander('Đối chiếu trước / sau · dòng đầu của file'):
            st.caption('Phần này có dữ liệu gốc: chỉ mở khi cần kiểm tra. Không đưa bảng đối chiếu này vào file kết quả.')
            st.dataframe(result['comparison'],hide_index=True,width='stretch')
    elif result:st.info('Nguồn đã đổi. Bấm Xử lý bảo mật Excel để tạo kết quả cho file đang chọn.')
    else:st.caption('Kết quả sẽ hiện sau khi kiểm tra đầu vào và bấm xử lý. File tải xuống chứa 17 cột theo quy tắc.')
    with st.expander('Giả danh hóa Excel khác mã hóa hồ sơ như thế nào?'):
        st.write('Excel thay định danh và loại bỏ cột theo quy tắc; dữ liệu tài chính vẫn đọc được. Mã hóa hồ sơ tạo tệp .ccenc có mật khẩu tại bước Hồ sơ. Hai chức năng có mục đích khác nhau.')
        st.caption('Mã giả danh ổn định trong phiên. Tải lại web có thể tạo khóa và mã mới; dùng script offline với khóa riêng khi cần liên kết nhiều phiên. Không tự gộp doanh nghiệp đổi mã hoặc nhân viên trùng tên.')

else:
    full_assistant(state,page,reserve_call,go)

footer()
floating_assistant(st.session_state.dossier,page,reserve_call,go)



# Run after page content is rendered; widgets on the same page keep their position.
scroll_on_page_change(page)

landing_scroll_reveal(page=='Trang chủ')

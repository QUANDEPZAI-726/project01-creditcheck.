def navigate(app,page,timeout=30):
    app.session_state['page']=page
    return app.run(timeout=timeout)

def choose_sample(app,cid='HS01',accept=True):
    navigate(app,'Tiếp nhận tài liệu')
    next(x for x in app.radio if x.label=='Nguồn hồ sơ').set_value('Hồ sơ mẫu giả lập').run(timeout=30)
    next(x for x in app.selectbox if x.key=='intake_sample_choice').set_value(cid).run(timeout=30)
    next(x for x in app.button if x.key=='intake_sample_load').click().run(timeout=30)
    if accept:accept_intake(app)
    return app

def accept_intake(app):
    next(x for x in app.checkbox if x.label.startswith('Tôi đã xem ba nguồn')).check().run(timeout=30)
    next(x for x in app.button if x.key=='intake_continue').click().run(timeout=30)
    return app

def restore_demo(app):
    navigate(app,'Tiếp nhận tài liệu')
    next(x for x in app.radio if x.label=='Nguồn hồ sơ').set_value('Hồ sơ mẫu giả lập').run(timeout=30)
    next(x for x in app.button if x.key=='restore_demo').click().run(timeout=30)
    return app

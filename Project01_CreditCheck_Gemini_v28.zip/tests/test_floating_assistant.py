from ui_test_tools import choose_sample, accept_intake, restore_demo, navigate
import json
import unittest
from pathlib import Path
from unittest.mock import patch
from streamlit.testing.v1 import AppTest
APP=Path(__file__).resolve().parents[1]/'streamlit_app.py'

class FloatingAssistantTests(unittest.TestCase):
    def fresh(self):
        a=AppTest.from_file(str(APP)).run(timeout=30)
        self.assertFalse(a.exception)
        choose_sample(a)
        navigate(a,'Trang chủ')
        return a
    def click(self,a,key):
        next(b for b in a.button if b.key==key).click().run(timeout=30)
        self.assertFalse(a.exception,[e.message for e in a.exception])
    def connect(self,a):
        next(x for x in a.text_input if x.label=='API key Gemini của bạn').set_value('fake-drawer-test-key')
        next(b for b in a.button if b.label=='Lưu kết nối').click().run(timeout=30)
    def consent(self,a):
        next(c for c in a.checkbox if c.key=='cc_drawer_consent_HS01').check().run(timeout=30)
        self.assertTrue(a.session_state['_cc_drawer_consents']['HS01'])
    def question(self,a,q):next(x for x in a.text_area if x.key=='_cc_drawer_question').set_value(q)
    def send(self,a):next(b for b in a.button if b.label=='Gửi câu hỏi').click().run(timeout=30)

    def test_open_suggest_close_never_calls_api_or_navigates(self):
        a=self.fresh()
        with patch('gemini_service.GeminiClient.generate') as api:
            self.click(a,'cc_chat_open')
            self.assertEqual(a.session_state['page'],'Trang chủ')
            self.assertTrue(next(b for b in a.button if b.label=='Gửi câu hỏi').disabled)
            self.click(a,'cc_chat_suggest_2')
            self.assertIn('DTI',next(x for x in a.text_area if x.key=='_cc_drawer_question').value)
            self.click(a,'cc_chat_close');api.assert_not_called()

    def test_send_has_page_context_and_history_survives_close_and_full_view(self):
        a=self.fresh();self.connect(a)
        a.session_state['page']='1 · Hồ sơ';a.run(timeout=30)
        self.click(a,'cc_chat_open');self.consent(a);self.question(a,'Giải thích hồ sơ')
        prompts=[]
        def generate(client,prompt):
            prompts.append(prompt)
            return {'answer':[{'text':'Hồ sơ cần người kiểm tra.','refs':['CASE']}]},{'model':client.model,'mock':True}
        with patch('gemini_service.GeminiClient.generate',autospec=True,side_effect=generate):self.send(a)
        self.assertFalse(a.exception,[e.message for e in a.exception]);self.assertFalse(a.error)
        self.assertEqual(len(prompts),1);self.assertIn('"current_page": "1 · Hồ sơ"',prompts[0])
        self.assertEqual(len(a.session_state['messages']),1)
        self.assertEqual(next(x for x in a.text_area if x.key=='_cc_drawer_question').value,'')
        self.click(a,'cc_chat_close');self.click(a,'cc_chat_open')
        self.assertEqual(len(a.session_state['messages']),1)
        self.click(a,'cc_chat_wide')
        self.assertEqual(a.session_state['page'],'Trợ lý hồ sơ')
        self.assertEqual(len(a.session_state['messages']),1)
        self.assertNotIn('fake-drawer-test-key',json.dumps(a.session_state['messages']))

    def test_failure_preserves_question_without_fake_answer(self):
        a=self.fresh();self.connect(a);self.click(a,'cc_chat_open');self.consent(a)
        self.question(a,'Tôi làm gì tiếp?')
        with patch('gemini_service.GeminiClient.generate',side_effect=ValueError('Gemini [503]: high demand')):self.send(a)
        self.assertFalse(a.exception);self.assertTrue(a.error)
        self.assertEqual(a.session_state['messages'],[])
        self.assertEqual(next(x for x in a.text_area if x.key=='_cc_drawer_question').value,'Tôi làm gì tiếp?')

    def test_switch_case_clears_draft_history_and_requires_consent(self):
        a=self.fresh();a.session_state['page']='1 · Hồ sơ';a.run(timeout=30)
        self.click(a,'cc_chat_open');self.consent(a)
        a.session_state['messages']=[{'question':'HS01?','answer':[{'text':'Mẫu','refs':['CASE']}],'references':{}}]
        self.question(a,'Câu hỏi HS01');a.run(timeout=30)
        choose_sample(a,'HS02')
        self.assertFalse(a.exception,[e.message for e in a.exception])
        self.assertEqual(a.session_state['dossier']['case']['case_id'],'HS02')
        self.assertEqual(a.session_state['messages'],[])
        self.assertEqual(next(x for x in a.text_area if x.key=='_cc_drawer_question').value,'')
        self.assertFalse(next(c for c in a.checkbox if c.key=='cc_drawer_consent_HS02').value)

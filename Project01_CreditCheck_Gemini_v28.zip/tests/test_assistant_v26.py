import copy
import unittest
from pathlib import Path
from unittest.mock import patch
from streamlit.testing.v1 import AppTest
from ui_test_tools import navigate,choose_sample
ROOT=Path(__file__).resolve().parents[1]
class AssistantAvailabilityTests(unittest.TestCase):
 def fresh(self):
  app=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
  self.assertFalse(app.exception)
  return app
 def test_no_case_launcher_help_full_and_close_without_api(self):
  a=self.fresh()
  with patch('gemini_service.GeminiClient.generate') as api:
   for page in ['Trang chủ','Tiếp nhận tài liệu','Bảo mật Excel','Hướng dẫn']:
    navigate(a,page)
    next(b for b in a.button if b.key=='cc_chat_open').click().run(timeout=30)
    self.assertFalse(a.exception)
    self.assertIsNone(a.session_state['dossier'])
    self.assertTrue(any('Hướng dẫn có sẵn' in c.value for c in a.caption))
    next(b for b in a.button if b.key=='cc_chat_close').click().run(timeout=30)
   navigate(a,'Trợ lý hồ sơ')
   self.assertEqual(a.session_state['page'],'Trợ lý hồ sơ')
   self.assertIsNone(a.session_state['dossier'])
   self.assertTrue(any(s.label=='Bạn cần hướng dẫn gì?' for s in a.selectbox))
   api.assert_not_called()
 def test_assistant_available_before_intake_confirmation(self):
  a=self.fresh();choose_sample(a,accept=False)
  self.assertFalse(a.session_state['dossier'].get('_intake_checked'))
  next(b for b in a.button if b.key=='cc_chat_open').click().run(timeout=30)
  self.assertFalse(a.exception,[e.message for e in a.exception])
  self.assertTrue(any('chưa xác nhận đối chiếu' in c.value for c in a.caption))
  self.assertTrue(next(b for b in a.button if b.label=='Gửi câu hỏi').disabled)
  next(b for b in a.button if b.key=='cc_chat_wide').click().run(timeout=30)
  self.assertEqual(a.session_state['page'],'Trợ lý hồ sơ')
  self.assertFalse(a.exception)
 def test_resume_existing_case_preserves_work(self):
  a=self.fresh();choose_sample(a)
  old=copy.deepcopy(a.session_state['dossier'])
  choose_sample(a,'HS02',accept=False)
  next(s for s in a.selectbox if s.key=='intake_resume_case').set_value('HS01').run(timeout=30)
  next(b for b in a.button if b.key=='intake_resume_open').click().run(timeout=30)
  self.assertFalse(a.exception,[e.message for e in a.exception])
  self.assertEqual(a.session_state['dossier'],old)
  self.assertTrue(a.session_state['dossier']['_intake_checked'])

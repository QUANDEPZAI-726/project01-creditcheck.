import copy
import json
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from input_security import *

class InputEncryptionTests(unittest.TestCase):
    def setUp(self):
        self.files={'application':b'%PDF synthetic borrower Nguyen A', 'bank_statement':b'amount_vnd\n20000000'}
        self.clear=pack_inputs('HS06',self.files)
        self.password='test-password-for-demo-only'

    def test_roundtrip_across_independent_sessions(self):
        blob=encrypt_export(self.clear,self.password)
        self.assertEqual(unpack_inputs(decrypt_export(blob,self.password)),('HS06',self.files,None))
        self.assertNotIn(b'Nguyen A',blob)
        self.assertNotIn(self.password.encode(),blob)

    def test_same_input_has_different_ciphertext(self):
        self.assertNotEqual(encrypt_export(self.clear,self.password),encrypt_export(self.clear,self.password))

    def test_wrong_password_rejected(self):
        with self.assertRaisesRegex(ValueError,'Sai mật khẩu'):
            decrypt_export(encrypt_export(self.clear,self.password),'another-password-only')

    def test_modified_ciphertext_rejected(self):
        obj=json.loads(encrypt_export(self.clear,self.password))
        ct=bytearray(unb64(obj['ciphertext']));ct[0]^=1
        obj['ciphertext']=b64(ct)
        with self.assertRaisesRegex(ValueError,'Sai mật khẩu'):
            decrypt_export(json.dumps(obj).encode(),self.password)

    def test_untrusted_kdf_parameters_rejected_without_deriving(self):
        obj=json.loads(encrypt_export(self.clear,self.password));obj['n']=2**30
        with self.assertRaisesRegex(ValueError,'định dạng'):
            decrypt_export(json.dumps(obj).encode(),self.password)

    def test_metadata_nonce_and_salt_tamper_rejected(self):
        original=json.loads(encrypt_export(self.clear,self.password))
        for field in ('nonce','salt'):
            obj=copy.deepcopy(original);data=bytearray(unb64(obj[field]));data[0]^=1;obj[field]=b64(data)
            with self.assertRaises(ValueError):decrypt_export(json.dumps(obj).encode(),self.password)

    def test_invalid_envelope_and_short_password(self):
        for data in (b'[]',b'not json',b'{"ciphertext":"??"}'):
            with self.assertRaises(ValueError):decrypt_export(data,self.password)
        with self.assertRaises(ValueError):encrypt_export(self.clear,'short')

    def test_session_key_and_case_context_isolation(self):
        key=session_key();blob=seal_session(self.clear,key,'input:HS06')
        self.assertEqual(open_session(blob,key,'input:HS06'),self.clear)
        for other_key,purpose in ((session_key(),'input:HS06'),(key,'input:HS01')):
            with self.assertRaises(ValueError):open_session(blob,other_key,purpose)

    def test_invalid_input_payloads_and_size(self):
        for cid,files in (('../HS06',self.files),('HS06',{'script':b'code'}),('HS06',{}),('HS06',{'application':b'x'*(MAX_INPUT+1)})):
            with self.assertRaises(ValueError):pack_inputs(cid,files)
        with self.assertRaises(ValueError):unpack_inputs(b'{"files":{}}')

    def test_key_and_model_validation(self):
        self.assertEqual(validate_connection(' fake-key ',' models/gemini-3.5-flash-lite '),('fake-key','gemini-3.5-flash-lite'))
        for key,model in (('', 'model'),('key with spaces','model'),('key','https://evil.test'),('key','')):
            with self.assertRaises(ValueError):validate_connection(key,model)

if __name__=='__main__':unittest.main()

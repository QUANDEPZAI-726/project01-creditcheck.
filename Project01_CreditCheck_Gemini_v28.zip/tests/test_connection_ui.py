from ui_test_tools import choose_sample, accept_intake, restore_demo, navigate
from ui_test_tools import navigate
import io
import json
import sys
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
from streamlit.testing.v1 import AppTest
APP=Path(__file__).resolve().parents[1]/'streamlit_app.py'
sys.path.insert(0,str(APP.parent/'app'))
from input_security import open_session, decrypt_export, unpack_inputs

class ConnectionUITests(unittest.TestCase):
    def fresh(self):
        at=AppTest.from_file(str(APP)).run(timeout=30)
        self.assertFalse(at.exception)
        choose_sample(at)
        return at

    def connect(self,at,key='test-personal-key-never-real',model='gemini-3.5-flash-lite'):
        next(x for x in at.text_input if x.label=='API key Gemini của bạn').set_value(key)
        next(x for x in at.text_input if x.label=='Tên model Gemini').set_value(model)
        next(x for x in at.button if x.label=='Lưu kết nối').click().run(timeout=30)
        self.assertFalse(at.exception)

    def test_key_encrypted_and_cleared_from_widget_and_other_session(self):
        a,b=self.fresh(),self.fresh()
        key='test-personal-key-never-real';self.connect(a,key)
        self.assertEqual(a.session_state['_api_key_input'],'')
        self.assertNotIn(key.encode(),a.session_state['_personal_key'])
        self.assertEqual(open_session(a.session_state['_personal_key'],a.session_state['_encryption_key'],'gemini-key').decode(),key)
        self.assertNotIn('_personal_key',b.session_state)
        next(x for x in a.button if x.label=='Xóa API key khỏi phiên').click().run(timeout=30)
        self.assertFalse(a.exception);self.assertNotIn('_personal_key',a.session_state)

    def test_personal_key_and_custom_model_used_without_group_unlock(self):
        at=self.fresh();self.connect(at,model='custom-test-model')
        navigate(at,'Trợ lý hồ sơ')
        next(x for x in at.checkbox if x.label.startswith('Đồng ý gửi câu hỏi')).check().run(timeout=30)
        seen={}
        def generate(client,prompt):
            seen.update(key=client.api_key,model=client.model)
            return {'answer':[{'text':'Hồ sơ giả lập cần con người xem xét.','refs':['CASE']}]},{'model':client.model,'mock':True}
        with patch('gemini_service.GeminiClient.generate',autospec=True,side_effect=generate):
            at.chat_input[0].set_value('Giải thích hồ sơ').run(timeout=30)
        self.assertFalse(at.exception);self.assertFalse(at.error)
        self.assertEqual(seen,{'key':'test-personal-key-never-real','model':'custom-test-model'})
        exported=json.dumps({'state':at.session_state['dossier'],'chat':at.session_state['messages']},ensure_ascii=False)
        self.assertNotIn(seen['key'],exported)

    def test_personal_mode_does_not_silently_use_server_key(self):
        at=self.fresh()
        at.secrets={'GEMINI_API_KEY':'server-test-key','DEMO_ACCESS_CODE':'code'}
        at.session_state['api_unlocked']=True
        navigate(at,'Trợ lý hồ sơ')
        at.checkbox[0].check().run(timeout=30)
        with patch('gemini_service.GeminiClient.generate') as call:
            self.assertTrue(at.chat_input[0].disabled)
        call.assert_not_called()
        self.assertTrue(any('Mở Gemini' in c.value for c in at.caption))

    def test_inputs_encrypted_and_password_export_roundtrip(self):
        at=self.fresh();navigate(at,'Tiếp nhận tài liệu')
        vault=at.session_state['_input_vault']['HS01']
        data=open_session(vault,at.session_state['_encryption_key'],'input:HS01')
        case_id,files,coverage=unpack_inputs(data)
        self.assertEqual(case_id,'HS01');self.assertEqual(len(files),3)
        password='test-export-password-only'
        next(x for x in at.text_input if x.label.startswith('Mật khẩu mã hóa')).set_value(password)
        next(x for x in at.button if x.label=='Tạo tệp đầu vào mã hóa').click().run(timeout=30)
        self.assertFalse(at.exception);self.assertFalse(at.error)
        self.assertEqual(at.session_state['_export_password'],'')
        encrypted=at.session_state['_encrypted_download']['data']
        self.assertEqual(decrypt_export(encrypted,password),data)
        self.assertNotIn(password.encode(),encrypted)
        self.assertNotIn(b'api_key',data)

if __name__=='__main__':unittest.main()

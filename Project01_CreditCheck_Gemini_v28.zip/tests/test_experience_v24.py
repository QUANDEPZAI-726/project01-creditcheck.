from ui_test_tools import choose_sample, accept_intake, restore_demo, navigate
import copy
import io
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
from streamlit.testing.v1 import AppTest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'))
from experience import highlighted_source, alert_label
from privacy_excel import example_excel, inspect_excel, protect_excel, FINANCIAL

class EvidenceAndPrivacyTests(unittest.TestCase):
    def test_quote_is_exact_page_scoped_and_html_is_escaped(self):
        source={'pages':['same <script>bad</script> 20.000.000','same 20.000.000']}
        html,count=highlighted_source(source,[{'locator':'page=2; field=income','quote':'20.000.000'}])
        self.assertEqual(count,1)
        self.assertNotIn('<script>',html)
        self.assertIn('&lt;script&gt;',html)
        self.assertEqual(html.count('<mark>'),1)
        self.assertIn('<mark>20.000.000</mark>',html)
        html,count=highlighted_source(source,[{'locator':'page=3','quote':'20.000.000'}])
        self.assertEqual(count,0)
        self.assertNotIn('<mark>',html)

    def test_pending_and_checked_zero_are_distinct(self):
        seed=json.loads((ROOT/'seed/HS01_session.json').read_text())
        from traceability import sync
        sync(seed)
        self.assertEqual(alert_label(seed),'0')
        seed['phase2']['income_review']=None
        self.assertEqual(alert_label(seed),'Chưa kiểm tra đầy đủ')
        seed['traceability']['alerts']=[{'code':'MISSING_DOCUMENT'}]
        self.assertIn('1 · chưa kiểm tra',alert_label(seed))

    def test_template_multi_year_and_comparison_never_in_export(self):
        raw=example_excel();inspection=inspect_excel(raw)
        self.assertEqual(len(inspection['rows']),2)
        result=protect_excel(raw,b'k'*32)
        self.assertTrue(result['numeric_unchanged'])
        self.assertEqual(len(result['comparison']),20)
        h=result['headers'];before=inspection['headers']
        for i,row in enumerate(inspection['rows']):
            for name in FINANCIAL+['Năm']:
                self.assertEqual(row[before.index(name)],result['rows'][i][h.index(name)])
        from openpyxl import load_workbook
        book=load_workbook(io.BytesIO(result['data']));values=str(list(book.active.values));book.close()
        self.assertNotIn('Nhân viên giả lập A',values)
        self.assertNotIn('Doanh nghiệp giả lập A',values)
        self.assertIn('STAFF_001',values)
        self.assertEqual(result['rows'][0][h.index('Mã chứng khoán')],result['rows'][1][h.index('Mã chứng khoán')])

class ExperienceUIFlows(unittest.TestCase):
    def fresh(self):
        app=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
        self.assertFalse(app.exception)
        choose_sample(app)
        return app
    def page(self,app,page):
        app.session_state['page']=page;app.run(timeout=30)
        self.assertFalse(app.exception,[x.message for x in app.exception])
    def test_compact_header_pending_state_and_source_focus(self):
        a=self.fresh();self.page(a,'1 · Hồ sơ')
        self.assertEqual(len(a.metric),0)
        self.assertTrue(next(b for b in a.button if b.label=='Chạy Gemini trích xuất').disabled)
        self.page(a,'3 · Phân tích')
        self.assertEqual(next(m for m in a.metric if m.label=='Cảnh báo cần xem').value,'Chưa kiểm tra đầy đủ')
        self.page(a,'2 · Kiểm tra')
        field=next(x for x in a.selectbox if x.label=='Chọn trường để xem căn cứ')
        field.set_value('existing_monthly_debt_vnd').run(timeout=30)
        self.assertFalse(a.exception)
        self.assertTrue(any('<mark>2.000.000</mark>' in m.value for m in a.markdown))

    def test_restored_result_all_pages_and_transaction_filter(self):
        a=self.fresh();self.page(a,'1 · Hồ sơ')
        restore_demo(a)
        self.assertFalse(a.exception)
        self.assertEqual(a.session_state['dossier']['phase2']['metrics']['dti_pct'],33.54)
        for page in ['2 · Kiểm tra','3 · Phân tích','4 · Báo cáo','Tổng quan','Trợ lý hồ sơ','Bảo mật Excel','Hướng dẫn','Trang chủ']:
            self.page(a,page)
        self.page(a,'2 · Kiểm tra')
        next(r for r in a.radio if r.label=='Lọc giao dịch').set_value('Chưa rõ').run(timeout=30)
        self.assertFalse(a.exception)
        self.assertTrue(any('Không có giao dịch' in i.value for i in a.info))
        self.page(a,'4 · Báo cáo')
        headings=[h.value for h in a.subheader]
        self.assertIn('Giới hạn',headings)
        self.assertIn('Diễn giải chỉ số',headings)

    def test_api_failure_retry_preserves_state_and_success_status_is_real(self):
        a=self.fresh()
        next(t for t in a.text_input if t.label=='API key Gemini của bạn').set_value('fake-connection-test-key')
        next(b for b in a.button if b.label=='Lưu kết nối').click().run(timeout=30)
        self.assertTrue(any('chưa thử API' in c.value for c in a.caption))
        self.page(a,'1 · Hồ sơ')
        next(c for c in a.checkbox if c.label.startswith('Tôi đồng ý gửi dữ liệu')).check().run(timeout=30)
        old=copy.deepcopy(a.session_state['dossier'])
        with patch('gemini_service.GeminiClient.generate',side_effect=ValueError('Gemini [503]: high demand')):
            next(b for b in a.button if b.label=='Chạy Gemini trích xuất').click().run(timeout=30)
        self.assertFalse(a.exception)
        self.assertEqual(a.session_state['dossier'],old)
        self.assertTrue(any('quá tải' in e.value for e in a.error))
        self.assertTrue(any(b.label.startswith('Thử lại · Chạy Gemini') for b in a.button))
        self.assertNotIn('_api_success',a.session_state)

    def test_consent_shared_between_drawer_and_full_page(self):
        a=self.fresh()
        next(b for b in a.button if b.key=='cc_chat_open').click().run(timeout=30)
        next(c for c in a.checkbox if c.key=='cc_drawer_consent_HS01').check().run(timeout=30)
        next(b for b in a.button if b.key=='cc_chat_wide').click().run(timeout=30)
        self.assertFalse(a.exception)
        self.assertTrue(next(c for c in a.checkbox if c.key=='cc_drawer_consent_HS01').value)
        self.assertTrue(a.chat_input[0].disabled)  # Consent alone is not a configured connection.

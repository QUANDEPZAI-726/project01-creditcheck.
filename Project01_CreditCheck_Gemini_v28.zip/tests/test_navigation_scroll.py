import sys
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from ui_shell import scroll_on_page_change

class NavigationScrollTests(unittest.TestCase):
    def test_only_navigation_scrolls_not_initial_load_or_form_rerun(self):
        with patch('ui_shell.st') as ui:
            ui.session_state={}
            scroll_on_page_change('1 · Hồ sơ')
            ui.html.assert_not_called()
            scroll_on_page_change('2 · Kiểm tra')
            ui.html.assert_called_once()
            self.assertTrue(ui.html.call_args.kwargs['unsafe_allow_javascript'])
            ui.html.reset_mock()
            scroll_on_page_change('2 · Kiểm tra')
            ui.html.assert_not_called()
            scroll_on_page_change('1 · Hồ sơ')
            ui.html.assert_called_once()
            self.assertEqual(ui.session_state['_cc_scroll_serial'],2)

import copy
import io
import sys
import unittest
from pathlib import Path
from openpyxl import Workbook,load_workbook
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'app'))
from privacy_excel import protect_excel,FINANCIAL,RULES

def fixture(rows=None,headers=None):
    headers=headers or list(RULES)
    records=rows or [
        {'Năm':2023,'Mã hồ sơ':'A','Tên người phụ trách hồ sơ':'Staff A','Tên doanh nghiệp':'Firm A','Mã chứng khoán':'AAA','Ngành':'Private Sector','Địa chỉ':'Private Address','Người đại diện':'Private Person',**{k:100+i for i,k in enumerate(FINANCIAL)}},
        {'Năm':2024,'Mã hồ sơ':'A','Tên người phụ trách hồ sơ':'Staff A','Tên doanh nghiệp':'Firm A','Mã chứng khoán':'AAA','Ngành':'Private Sector','Địa chỉ':'Private Address','Người đại diện':'Private Person',**{k:200+i for i,k in enumerate(FINANCIAL)}},
        {'Năm':2024,'Mã hồ sơ':'B','Tên người phụ trách hồ sơ':'Staff B','Tên doanh nghiệp':'Firm B','Mã chứng khoán':'BBB','Ngành':'Private Sector','Địa chỉ':'Private Address','Người đại diện':'Private Person',**{k:300+i for i,k in enumerate(FINANCIAL)}},
    ]
    b=Workbook();s=b.active;s.append(headers)
    for r in records:s.append([r.get(k) for k in headers])
    buf=io.BytesIO();b.save(buf);b.close();return buf.getvalue()

class ExcelPrivacyTests(unittest.TestCase):
    def test_linkage_financial_values_and_drop(self):
        result=protect_excel(fixture(),b'x'*32)
        self.assertEqual((result['row_count'],len(result['headers']),result['company_count']),(3,17,2))
        h=result['headers'];r=result['rows']
        self.assertEqual(r[0][h.index('Mã chứng khoán')],r[1][h.index('Mã chứng khoán')])
        self.assertEqual(r[0][h.index('Tên doanh nghiệp')],r[0][h.index('Mã chứng khoán')])
        self.assertEqual(r[0][h.index('Tên người phụ trách hồ sơ')],'STAFF_001')
        self.assertEqual(r[1][h.index('Tên người phụ trách hồ sơ')],'STAFF_001')
        for i,k in enumerate(FINANCIAL):self.assertEqual([row[h.index(k)] for row in r],[100+i,200+i,300+i])
        self.assertTrue(all(k not in h for k in ['Ngành','Địa chỉ','Người đại diện']))

    def test_export_has_only_safe_data_and_exact_values(self):
        result=protect_excel(fixture(),b'x'*32)
        b=load_workbook(io.BytesIO(result['data']),read_only=True)
        values=list(b.active.values);b.close()
        self.assertEqual(list(values[0]),result['headers'])
        self.assertEqual([list(r) for r in values[1:]],result['rows'])
        rendered=str(values)
        for secret in ['Private Address','Private Person','Firm A','Staff A']:
            self.assertNotIn(secret,rendered)

    def test_repeated_run_and_sessions(self):
        first=protect_excel(fixture(),b'x'*32)
        again=protect_excel(fixture(),b'x'*32,first['staff_map'])
        other=protect_excel(fixture(),b'y'*32)
        self.assertEqual(first['rows'],again['rows'])
        col=first['headers'].index('Mã chứng khoán')
        self.assertNotEqual(first['rows'][0][col],other['rows'][0][col])

    def test_invalid_schema_and_input(self):
        for data in [b'invalid',b'',fixture(headers=list(RULES)[:-1])]:
            with self.assertRaises(ValueError):protect_excel(data,b'x'*32)

    def test_duplicate_year_formula_and_non_numeric_rejected(self):
        b=load_workbook(io.BytesIO(fixture()));s=b.active
        changes=[('A3',2023),('I2','=1+1'),('I2','not a number')]
        for cell,value in changes:
            old=s[cell].value;s[cell]=value;buf=io.BytesIO();b.save(buf)
            with self.assertRaises(ValueError):protect_excel(buf.getvalue(),b'x'*32)
            s[cell]=old
        b.close()

    def test_staff_map_not_mutated_when_rejected(self):
        m={'a'*64:'STAFF_001'};original=copy.deepcopy(m)
        with self.assertRaises(ValueError):protect_excel(b'invalid',b'x'*32,m)
        self.assertEqual(m,original)

    def test_unexpected_sheets_not_silently_dropped(self):
        b=load_workbook(io.BytesIO(fixture()));b.create_sheet('Other');buf=io.BytesIO();b.save(buf);b.close()
        with self.assertRaises(ValueError):protect_excel(buf.getvalue(),b'x'*32)

if __name__=='__main__':unittest.main()

from ui_test_tools import restore_demo
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'app'))
from financial_charts import comparison_domain, amount_chart
from presentation import income_rows, debt_rows


class FinancialChartTests(unittest.TestCase):
    def test_hs01_amounts_share_scale_and_labels_preserve_values(self):
        state = json.loads((ROOT/'seed/HS01_session.json').read_text())
        incomes, debts = income_rows(state), debt_rows(state)
        domain = comparison_domain(incomes, debts)
        self.assertEqual(domain, [0, 26400000])
        a = amount_chart(incomes, 'Thu nhập (đ)', 'Nguồn', 'Thu nhập', domain).to_dict()
        b = amount_chart(debts, 'Số tiền (đ)', 'Khoản', 'Nợ', domain).to_dict()
        for spec in [a, b]:
            for layer in spec['layer']:
                self.assertEqual(layer['encoding']['x']['scale']['domain'], domain)
                self.assertFalse(layer['encoding']['x']['scale']['nice'])
        values = next(iter(b['datasets'].values()))
        self.assertEqual(values[0]['Số tiền (đ)'], 2000000)
        self.assertEqual(values[1]['Số tiền (đ)'], 4707347)
        self.assertEqual(values[1]['_amount_label'], '4.707.347 đ')
        self.assertGreater(20000000/domain[1], values[1]['Số tiền (đ)']/domain[1])

    def test_negative_remainder_is_preserved_and_missing_is_not_zero(self):
        domain = comparison_domain([{'Thu nhập (đ)': 1000000}],
                                   [{'Số tiền (đ)': -3000000}, {'Số tiền (đ)': None}])
        self.assertEqual(domain, [-3960000, 1320000])
        self.assertEqual(comparison_domain([], []), [0, 1.32])

    def test_analysis_page_renders_both_comparisons_after_restore(self):
        from streamlit.testing.v1 import AppTest
        app = AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
        restore_demo(app)
        app.session_state['page'] = '3 · Phân tích'
        app.run(timeout=30)
        self.assertFalse(app.exception)
        self.assertEqual(len(app.get('vega_lite_chart')), 2)
        self.assertTrue(any('Hai biểu đồ dùng cùng thang đo' in c.value for c in app.caption))

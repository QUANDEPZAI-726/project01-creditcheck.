import copy
import json
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from streamlit.testing.v1 import AppTest
from ui_test_tools import navigate,choose_sample,accept_intake,restore_demo
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'))
from input_security import open_session,unpack_inputs

class IntakeV25Tests(unittest.TestCase):
    def fresh(self):
        a=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
        self.assertFalse(a.exception)
        return a
    def test_empty_start_no_hidden_sample_and_protected_routes(self):
        a=self.fresh()
        self.assertIsNone(a.session_state['dossier'])
        self.assertEqual(a.session_state['portfolio'],{})
        self.assertNotIn('_input_vault',a.session_state)
        for page in ['2 · Kiểm tra','3 · Phân tích','4 · Báo cáo']:
            navigate(a,page)
            self.assertFalse(a.exception)
            self.assertEqual(a.session_state['page'],'Tiếp nhận tài liệu')
            self.assertIsNone(a.session_state['dossier'])
            self.assertFalse(any((b.key or '').startswith('work_nav_') for b in a.button))
        for page in ['Trang chủ','Bảo mật Excel','Hướng dẫn']:
            navigate(a,page);self.assertFalse(a.exception)
            self.assertEqual(a.session_state['page'],page)
            self.assertIsNone(a.session_state['dossier'])
    def test_explicit_sample_gate_never_claims_income_verified(self):
        a=self.fresh();choose_sample(a,accept=False)
        self.assertEqual(a.session_state['page'],'Tiếp nhận tài liệu')
        self.assertTrue(next(b for b in a.button if b.key=='intake_continue').disabled)
        self.assertIsNone(a.session_state['dossier']['phase2']['income_review'])
        self.assertIsNone(a.session_state['dossier']['phase2']['metrics']['dti_pct'])
        accept_intake(a)
        self.assertEqual(a.session_state['page'],'1 · Hồ sơ')
        self.assertEqual(a.session_state['dossier']['extraction_review']['status'],'Pending')
        self.assertEqual(len([b for b in a.button if (b.key or '').startswith('work_nav_')]),4)
    def test_receive_files_encrypts_and_does_not_fill_missing_source(self):
        a=self.fresh();navigate(a,'Tiếp nhận tài liệu')
        manifest=json.loads((ROOT/'runtime/cases/HS01/manifest.json').read_text())
        d=next(d for d in manifest['documents'] if d['source_type']=='application')
        data=(ROOT/'runtime/cases/HS01'/d['path']).read_bytes()
        def uploader(label,*args,**kwargs):
            return SimpleNamespace(name='application.pdf',getvalue=lambda:data) if kwargs.get('key')=='intake_file_application' else None
        with patch('streamlit.file_uploader',side_effect=uploader):
            a.run(timeout=30)
            next(t for t in a.text_input if t.key=='intake_case_id').set_value('HS01').run(timeout=30)
            next(b for b in a.button if b.key=='intake_receive').click().run(timeout=30)
        self.assertFalse(a.exception,[e.message for e in a.exception])
        s=a.session_state['dossier']
        self.assertEqual(s['_source_kind'],'upload')
        self.assertEqual(sum(d['available'] for d in s['case']['documents']),1)
        self.assertEqual(s['phase3']['report_status'],'Insufficient information')
        clear=open_session(a.session_state['_input_vault']['HS01'],a.session_state['_encryption_key'],'input:HS01')
        cid,files,_=unpack_inputs(clear)
        self.assertEqual(files,{'application':data})
        self.assertNotEqual(a.session_state['_input_vault']['HS01'],clear)
    def test_failed_upload_preserves_existing_state(self):
        a=self.fresh();choose_sample(a,accept=False)
        next(x for x in a.radio if x.label=='Nguồn hồ sơ').set_value('Tài liệu của bạn').run(timeout=30)
        old=copy.deepcopy(a.session_state['dossier']);vault=a.session_state['_input_vault']['HS01']
        def uploader(label,*args,**kwargs):
            return SimpleNamespace(name='broken.pdf',getvalue=lambda:b'not pdf') if kwargs.get('key')=='intake_file_application' else None
        with patch('streamlit.file_uploader',side_effect=uploader):
            a.run(timeout=30)
            next(x for x in a.checkbox if x.key=='intake_replace_ack').check().run(timeout=30)
            next(b for b in a.button if b.key=='intake_receive').click().run(timeout=30)
            self.assertTrue(a.error)
            self.assertTrue(next(b for b in a.button if b.key=='intake_continue').disabled)
        self.assertEqual(a.session_state['dossier'],old)
        self.assertEqual(a.session_state['_input_vault']['HS01'],vault)
    def test_two_conflict_types_and_absence_have_real_evidence(self):
        a=self.fresh()
        for cid,code in [('HS02','MISSING_DOCUMENT'),('HS03','INCOME_MISMATCH'),('HS04','BORROWER_ID_MISMATCH')]:
            choose_sample(a,cid,accept=False)
            self.assertFalse(a.exception,[e.message for e in a.exception])
            alert=next(x for x in a.session_state['dossier']['traceability']['alerts'] if x['code']==code)
            self.assertTrue(alert['evidence'])
            if code=='MISSING_DOCUMENT':
                self.assertTrue(all(e['quote'] is None and not e['source_available'] for e in alert['evidence']))
            else:self.assertTrue(all(e['quote_found_in_source'] for e in alert['evidence']))
    def test_saved_demo_is_explicit_and_all_pages_render(self):
        a=self.fresh();choose_sample(a);restore_demo(a)
        self.assertNotIn('HS01',a.session_state['_input_vault'])
        self.assertTrue(a.session_state['dossier']['_demo_restored'])
        self.assertEqual(a.session_state['dossier']['phase2']['metrics']['dti_pct'],33.54)
        for page in ['1 · Hồ sơ','2 · Kiểm tra','3 · Phân tích','4 · Báo cáo','Tổng quan','Trợ lý hồ sơ','Bảo mật Excel','Hướng dẫn','Trang chủ']:
            navigate(a,page);self.assertFalse(a.exception,(page,[e.message for e in a.exception]))
    def test_new_sample_resets_acceptance_and_clears_chat(self):
        a=self.fresh();choose_sample(a)
        a.session_state['messages']=[{'question':'old'}]
        choose_sample(a,'HS02',accept=False)
        self.assertFalse(a.session_state['dossier'].get('_intake_checked'))
        self.assertEqual(a.session_state['messages'],[])
        navigate(a,'3 · Phân tích')
        self.assertEqual(a.session_state['page'],'Tiếp nhận tài liệu')

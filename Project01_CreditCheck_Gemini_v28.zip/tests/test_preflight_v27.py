"""Regression checks. All API responses here are mocked, never live API proof."""
import copy
import json
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch, MagicMock
from streamlit.testing.v1 import AppTest
from ui_test_tools import choose_sample, navigate

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'))
from gemini_service import GeminiClient, GeminiError, safe_error
from experience import error_guidance, connection_caption

class PreflightUnitTests(unittest.TestCase):
    def test_error_code_preserved_and_key_scrubbed(self):
        key='private-test-key'
        exc=SimpleNamespace(code=503,message='failed '+key+' ?key=another-secret&x=1 AIzaABCDE1234')
        message=str(safe_error(exc,key))
        self.assertIn('[503]',message)
        for secret in [key,'another-secret','AIzaABCDE1234']:
            self.assertNotIn(secret,message)

    def test_error_types_are_distinct(self):
        titles=[error_guidance('Gemini ['+str(n)+']: test')[0] for n in [500,503,504,429,403,404]]
        self.assertEqual(len(set(titles)),6)
        self.assertIn('thời gian',error_guidance('Gemini [ReadTimeout]: timed out')[0])

    def test_probe_rejects_wrong_json_and_accepts_exact_boolean(self):
        c=GeminiClient('test-key','test-model')
        for value in [{'ok':1},{'ok':False},{'ok':True,'other':1}]:
            with patch.object(c,'generate',return_value=(value,{})):
                with self.assertRaises(ValueError):c.probe()
        with patch.object(c,'generate',return_value=({'ok':True},{'model':'test-model'})) as call:
            self.assertEqual(c.probe()['model'],'test-model')
            self.assertNotIn('HS01',call.call_args.args[0])

    def test_sdk_retry_is_bounded_and_not_on_quota_or_auth(self):
        response=SimpleNamespace(text='{"ok":true}',usage_metadata=SimpleNamespace(),response_id='mock')
        sdk=MagicMock()
        sdk.__enter__.return_value.models.generate_content.return_value=response
        with patch('google.genai.Client',return_value=sdk) as factory:
            GeminiClient('test-key','test-model').generate('test only')
        opts=factory.call_args.kwargs['http_options']
        self.assertEqual(opts.retry_options.attempts,1)
        self.assertLessEqual(opts.timeout,20000)

    def test_available_models_filters_non_generation(self):
        sdk=MagicMock()
        sdk.__enter__.return_value.models.list.return_value=[
            SimpleNamespace(name='models/model-one',supported_actions=['generateContent']),
            SimpleNamespace(name='models/embedding-only',supported_actions=['embedContent'])]
        with patch('google.genai.Client',return_value=sdk):
            self.assertEqual(GeminiClient('test-key','unused').available_models(),['model-one'])

    def test_changed_group_model_invalidates_connection_badge(self):
        session={'_api_source':'API key của nhóm','api_unlocked':True,
                 '_group_model_override':'new-model','_api_success':{'source':'group','model':'old-model'}}
        with patch('streamlit.session_state',session):
            self.assertIn('chưa thử',connection_caption())

class PreflightUITests(unittest.TestCase):
    def fresh_group(self):
        a=AppTest.from_file(str(ROOT/'streamlit_app.py'))
        a.secrets={'GEMINI_API_KEY':'group-test-key','GEMINI_MODEL':'test-old-model','DEMO_ACCESS_CODE':'test-group-code'}
        a.run(timeout=30)
        next(x for x in a.radio if x.label=='Nguồn API key').set_value('API key của nhóm').run(timeout=30)
        next(x for x in a.text_input if x.label=='Mã truy cập API của nhóm').set_value('test-group-code')
        next(x for x in a.button if x.label=='Mở quyền chạy API').click().run(timeout=30)
        self.assertFalse(a.exception)
        return a

    def test_probe_requires_consent_and_keeps_dossier_and_provenance(self):
        a=self.fresh_group();choose_sample(a)
        before=copy.deepcopy(a.session_state['dossier'])
        self.assertTrue(next(x for x in a.button if x.key=='connection_probe').disabled)
        a.toggle[0].set_value(True).run(timeout=30)
        with patch('gemini_service.GeminiClient.probe',return_value={'model':'test-old-model'}):
            next(x for x in a.button if x.key=='connection_probe').click().run(timeout=30)
        self.assertFalse(a.exception)
        self.assertEqual(a.session_state['dossier'],before)
        self.assertTrue(a.session_state['_connection_probe']['ok'])
        self.assertEqual(a.session_state['dossier']['llm_runs'],before['llm_runs'])

    def test_probe_failure_is_readable_and_keeps_dossier(self):
        a=self.fresh_group();choose_sample(a)
        before=copy.deepcopy(a.session_state['dossier'])
        a.toggle[0].set_value(True).run(timeout=30)
        with patch('gemini_service.GeminiClient.probe',side_effect=GeminiError('Gemini [503]: mock unavailable')):
            next(x for x in a.button if x.key=='connection_probe').click().run(timeout=30)
        self.assertFalse(a.exception)
        self.assertTrue(any('[503]' in x.value for x in a.error))
        self.assertEqual(a.session_state['dossier'],before)
        self.assertNotIn('_api_success',a.session_state)

    def test_group_model_override_and_reset_never_changes_secret(self):
        a=self.fresh_group()
        next(x for x in a.text_input if x.key=='_group_model_input').set_value('models/test-new-model')
        next(x for x in a.button if x.label=='Lưu model cho phiên này').click().run(timeout=30)
        self.assertFalse(a.exception)
        self.assertEqual(a.session_state['_group_model_override'],'test-new-model')
        self.assertEqual(a.secrets['GEMINI_MODEL'],'test-old-model')
        a.toggle[0].set_value(True).run(timeout=30)
        seen=[]
        def probe(client):
            seen.append(client.model)
            return {'model':client.model}
        with patch('gemini_service.GeminiClient.probe',autospec=True,side_effect=probe):
            next(x for x in a.button if x.key=='connection_probe').click().run(timeout=30)
        self.assertEqual(seen,['test-new-model'])
        next(x for x in a.button if x.key=='group_model_reset').click().run(timeout=30)
        self.assertFalse(a.exception)
        self.assertNotIn('_group_model_override',a.session_state)
        self.assertNotIn('_api_success',a.session_state)

    def test_whitespace_same_case_cannot_bypass_replacement_gate(self):
        a=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
        choose_sample(a,accept=False)
        next(x for x in a.radio if x.label=='Nguồn hồ sơ').set_value('Tài liệu của bạn').run(timeout=30)
        before=copy.deepcopy(a.session_state['dossier'])
        m=json.loads((ROOT/'runtime/cases/HS01/manifest.json').read_text())
        doc=next(d for d in m['documents'] if d['source_type']=='application')
        data=(ROOT/'runtime/cases/HS01'/doc['path']).read_bytes()
        def uploader(*args,**kwargs):
            return SimpleNamespace(name='application.pdf',getvalue=lambda:data) if kwargs.get('key')=='intake_file_application' else None
        with patch('streamlit.file_uploader',side_effect=uploader):
            a.run(timeout=30)
            next(x for x in a.text_input if x.key=='intake_case_id').set_value(' HS01 ')
            next(x for x in a.button if x.key=='intake_receive').click().run(timeout=30)
        self.assertFalse(a.exception)
        self.assertTrue(any('cùng mã' in x.value for x in a.error))
        self.assertEqual(a.session_state['dossier'],before)

if __name__=='__main__':unittest.main()

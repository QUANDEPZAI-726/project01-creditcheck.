"""Actually stall the transport to verify UI waiting is bounded and late output is ignored."""
import copy
import json
import sys
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from streamlit.testing.v1 import AppTest
from ui_test_tools import choose_sample

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'app'))
from gemini_service import GeminiClient, GeminiError, run_task, PROBE_PROMPT
from sample_data import load_sample
from experience import error_guidance

class DeadlineTests(unittest.TestCase):
    def test_stalled_transport_returns_before_worker_finishes_and_blocks_duplicate(self):
        release=threading.Event();done=threading.Event()
        c=GeminiClient('test-key','test-model')
        calls=[]
        def stalled():
            calls.append(1)
            release.wait(2)
            done.set()
            return 'late-result'
        start=time.monotonic()
        try:
            with self.assertRaisesRegex(GeminiError,'LOCAL_TIMEOUT'):
                c._bounded(stalled,.025)
            self.assertLess(time.monotonic()-start,.5)
            self.assertFalse(done.is_set())
            with self.assertRaisesRegex(ValueError,'REQUEST_PENDING'):
                c._bounded(stalled,.025)
            self.assertEqual(len(calls),1)
        finally:
            release.set();self.assertTrue(done.wait(1))

    def test_sdk_completion_after_deadline_cannot_change_dossier(self):
        state=load_sample('HS01');before=copy.deepcopy(state)
        release=threading.Event();done=threading.Event()
        c=GeminiClient('test-key','test-model')
        result={'case_id':'HS01','documents':[{'document_id':d['document_id'],'fields':d['fields']}
            for d in state['case']['documents'] if d['source_type']!='bank_statement' and d['available']]}
        bounded=c._bounded
        def stalled(*args,**kwargs):
            release.wait(2);done.set()
            return result,{'model':'test-model'}
        try:
            with patch.object(c,'_generate_content',side_effect=stalled), patch.object(c,'_bounded',side_effect=lambda op,seconds:bounded(op,.025)):
                with self.assertRaisesRegex(GeminiError,'LOCAL_TIMEOUT'):
                    run_task(state,'extraction',c)
                self.assertEqual(state,before)
                release.set();self.assertTrue(done.wait(1))
            self.assertEqual(state,before)
        finally:release.set()

    def test_fast_transport_and_failure_are_forwarded_without_retry(self):
        c=GeminiClient('test-key','test-model')
        self.assertEqual(c._bounded(lambda:{'ok':True},.5),{'ok':True})
        def fail():raise GeminiError('Gemini [503]: synthetic failure')
        with self.assertRaisesRegex(GeminiError,'503'):c._bounded(fail,.5)
        self.assertFalse(c.request_slot['active'])

    def test_new_clients_in_same_session_share_pending_guard(self):
        slot={'lock':threading.Lock(),'active':True}
        c=GeminiClient('test-key','different-model',request_slot=slot)
        with self.assertRaisesRegex(ValueError,'REQUEST_PENDING'):
            c.generate('should not be sent')

    def test_probe_and_task_use_separate_deadlines(self):
        c=GeminiClient('test-key','test-model')
        with patch.object(c,'_bounded',return_value=({'ok':True},{})) as call:
            c.probe();self.assertEqual(call.call_args.args[1],15)
            c.generate('task');self.assertEqual(call.call_args.args[1],45)
            c.available_models();self.assertEqual(call.call_args.args[1],15)

    def test_local_timeout_and_pending_are_not_claimed_provider_overload(self):
        for code in ['LOCAL_TIMEOUT','REQUEST_PENDING']:
            title,hint=error_guidance('Gemini ['+code+']: test')
            self.assertNotIn('quá tải',title)
            self.assertIn('giữ nguyên',hint)

    def test_no_false_empty_model_response_before_auth_or_request(self):
        a=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
        self.assertFalse(a.exception)
        self.assertFalse(any('API không trả model' in x.value for x in a.code))
        self.assertTrue(next(x for x in a.button if x.key=='connection_probe').disabled)

    def test_stalled_extraction_exits_spinner_and_renders_error_without_changing_case(self):
        a=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
        next(x for x in a.text_input if x.label=='API key Gemini của bạn').set_value('synthetic-test-key')
        next(x for x in a.button if x.label=='Lưu kết nối').click().run(timeout=30)
        choose_sample(a,accept=False)
        next(x for x in a.checkbox if x.label.startswith('Tôi đồng ý gửi dữ liệu')).check().run(timeout=30)
        before=copy.deepcopy(a.session_state['dossier'])
        release=threading.Event();done=threading.Event()
        original=GeminiClient._bounded
        def stalled(*args,**kwargs):
            release.wait(2);done.set()
            return {},{}
        try:
            with patch('gemini_service.GeminiClient._generate_content',side_effect=stalled), patch('gemini_service.GeminiClient._bounded',autospec=True,side_effect=lambda c,op,seconds:original(c,op,.025)):
                next(x for x in a.button if x.label=='Chạy Gemini trích xuất').click().run(timeout=30)
                self.assertFalse(a.exception,[e.message for e in a.exception])
                self.assertTrue(any('Đã dừng chờ Gemini' in x.value for x in a.error))
                self.assertEqual(a.session_state['dossier'],before)
                self.assertTrue(any(x.label.startswith('Thử lại · Chạy Gemini trích xuất') for x in a.button))
                release.set();self.assertTrue(done.wait(1))
            self.assertEqual(a.session_state['dossier'],before)
        finally:release.set()

if __name__=='__main__':unittest.main()

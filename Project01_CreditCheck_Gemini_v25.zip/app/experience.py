"""Display helpers for review, provenance and input validation; no credit decisions."""
from html import escape
import re
from core import LABELS
from presentation import money

CASE_LABELS = {'HS01':'HS01 · Hồ sơ cơ sở, ba nguồn phù hợp',
 'HS02':'HS02 · Thiếu nguồn sao kê', 'HS03':'HS03 · Thu nhập giữa các nguồn khác nhau',
 'HS04':'HS04 · Thông tin chủ tài khoản cần đối chiếu', 'HS05':'HS05 · Nguồn thu có khoản chưa rõ'}

def status_label(state):
    return 'Thiếu thông tin' if state['phase3']['report_status']=='Insufficient information' else 'Cần người thẩm định xem xét'

def alert_label(state):
    count=len(state['traceability']['alerts'])
    complete=state['phase2']['income_review'] is not None and all(v is not None for v in state['phase2']['metrics'].values())
    if complete:return str(count)
    return f'{count} · chưa kiểm tra đầy đủ' if count else 'Chưa kiểm tra đầy đủ'

def display_value(field,value):
    if value is None:return 'Chưa có'
    if field.endswith('_vnd') and isinstance(value,(int,float)):return money(value)
    if isinstance(value,bool):return 'Đã xác minh' if value else 'Chưa xác minh'
    return str(value)

def highlighted_source(source, evidence):
    """Highlight exact, verified quotes on their cited page only; escape all input."""
    pages=source.get('pages') or [source.get('text','')]
    rendered=[];matches=0
    for i,page in enumerate(pages,1):
        intervals=[]
        for ev in evidence:
            match=re.search(r'page=(\d+)',ev.get('locator',''))
            if match and int(match[1])!=i:continue
            quote=ev.get('quote')
            if not isinstance(quote,str) or not quote:continue
            start=page.find(quote)
            if start>=0:intervals.append((start,start+len(quote)))
        merged=[]
        for start,end in sorted(set(intervals)):
            if merged and start<=merged[-1][1]:merged[-1]=(merged[-1][0],max(end,merged[-1][1]))
            else:merged.append((start,end))
        matches+=len(merged);pos=0;parts=[]
        for start,end in merged:
            parts.extend([escape(page[pos:start]),'<mark>'+escape(page[start:end])+'</mark>']);pos=end
        parts.append(escape(page[pos:]))
        rendered.append('<section class="cc-source-page"><span class="cc-source-label">Trang '+str(i)+'</span><pre>'+''.join(parts)+'</pre></section>')
    return '<div class="cc-source-document">'+''.join(rendered)+'</div>',matches

def case_context(state):
    from phase2 import value
    return '<div class="cc-case-context"><strong>'+escape(state['case']['case_id'])+'</strong><span>'+escape(str(value(state,'full_name') or 'Chưa có tên người vay'))+'</span><span class="cc-badge">'+escape(status_label(state))+'</span></div>'

def error_guidance(error):
    text=str(error)
    if '[503]' in text or '[500]' in text or '[504]' in text:
        return 'Gemini đang quá tải hoặc tạm thời gián đoạn.', 'Chờ một lát rồi bấm Thử lại. Hồ sơ và kết quả trước đó được giữ nguyên.'
    if '[429]' in text:
        return 'Gemini đã chạm hạn mức hoặc nhận quá nhiều yêu cầu.', 'Kiểm tra quota của key đang chọn; chờ rồi thử lại. Đổi key không bảo đảm có quota.'
    if '[401]' in text or '[403]' in text:
        return 'API key không hợp lệ hoặc chưa được cấp quyền.', 'Mở Gemini trên thanh đầu trang để kiểm tra key và quyền gọi model.'
    if '[404]' in text:
        return 'Không tìm thấy model hoặc key chưa có quyền sử dụng.', 'Mở Gemini và nhập đúng tên model mà tài khoản của bạn được cấp quyền.'
    return text, 'Dữ liệu trước đó được giữ. Kiểm tra thông báo rồi thử lại; không tự dùng kết quả mẫu thay API.'

def connection_caption():
    import streamlit as st
    if st.session_state.get('_api_source','API key của tôi')=='API key của tôi':
        model=st.session_state.get('_personal_model')
        configured=bool(st.session_state.get('_personal_key'))
        source='personal'
    else:
        model=None;configured=bool(st.session_state.get('api_unlocked'));source='group'
    if not configured:return 'Chưa lưu cấu hình' if source=='personal' else 'Chưa mở quyền nhóm'
    proof=st.session_state.get('_api_success',{})
    if proof.get('source')==source and (source=='group' or proof.get('model')==model):return 'API đã chạy thành công'
    return 'Đã lưu cấu hình · chưa thử API'

def record_api_success(client):
    import streamlit as st
    st.session_state['_api_success']={'source':'personal' if st.session_state.get('_api_source','API key của tôi')=='API key của tôi' else 'group','model':client.model}

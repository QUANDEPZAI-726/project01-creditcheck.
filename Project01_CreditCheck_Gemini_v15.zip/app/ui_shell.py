"""Public landing page and horizontal navigation; all operations use native widgets."""
from html import escape
from pathlib import Path
import streamlit as st

WORK_PAGES=['Tổng quan','1 · Hồ sơ','2 · Kiểm tra','3 · Phân tích','4 · Báo cáo']
SECTIONS=['Trang chủ','Rà soát hồ sơ','Bảo mật Excel','Trợ lý','Hướng dẫn']

def section_for(page):
    if page in WORK_PAGES:return 'Rà soát hồ sơ'
    return 'Trợ lý' if page=='Trợ lý hồ sơ' else page

def select_section():
    section=st.session_state['_nav_section']
    if section=='Rà soát hồ sơ':
        st.session_state.page=st.session_state.get('_last_work_page','1 · Hồ sơ')
    else:
        st.session_state.page='Trợ lý hồ sơ' if section=='Trợ lý' else section

def shell_styles():
    from design_tokens import stylesheet
    st.markdown(stylesheet(),unsafe_allow_html=True)


def navigation(logo,connection,go):
    page=st.session_state.get('page','Trang chủ')
    if page in WORK_PAGES:st.session_state['_last_work_page']=page
    st.session_state['_nav_section']=section_for(page)
    with st.container(key='cc_header'):
        brand,menu,config=st.columns([1.4,3.6,.85],vertical_alignment='center')
        with brand,st.container(key='cc_brand'):
            with st.container(horizontal=True,vertical_alignment='center',gap='small'):
                if logo and Path(logo).exists():st.image(str(logo),width=58)
                st.button('CreditCheck',type='tertiary',on_click=go,args=('Trang chủ',),key='brand_home')
            st.caption('PROJECT 01 · RÀ SOÁT HỒ SƠ')
        with menu:
            st.radio('Điều hướng chính',SECTIONS,horizontal=True,key='_nav_section',
                     label_visibility='collapsed',on_change=select_section)
        with config:
            with st.popover('Gemini',help='Kết nối API key và chọn model',width='stretch'):
                connection()
    return st.session_state.page

def landing(go):
    with st.container(key='cc_landing'):
        intro,visual=st.columns([1.25,1],gap='large',vertical_alignment='center')
        with intro:
            st.markdown('''<div class="cc-home-label">CREDITCHECK · TRỢ LÝ RÀ SOÁT HỒ SƠ</div>
            <h1 class="cc-home-title">Hồ sơ rõ ràng.<br><em>Rà soát có căn cứ.</em></h1>
            <p class="cc-home-copy">Đối chiếu tài liệu vay, xem chỉ số do Python tính và kiểm tra phần diễn giải của Gemini. Bạn kiểm tra từng bước, từ tài liệu đầu vào đến báo cáo bàn giao.</p>''',unsafe_allow_html=True)
            primary,secondary=st.columns([1,1])
            with primary:st.button('Bắt đầu rà soát',type='primary',width='stretch',on_click=go,args=('1 · Hồ sơ',),key='home_start')
            with secondary:st.button('Dùng thử hồ sơ mẫu',width='stretch',on_click=go,args=('1 · Hồ sơ',),key='home_sample')
            st.markdown('<div class="cc-intro-line">Bắt đầu bằng tài liệu của bạn hoặc một hồ sơ mẫu. Bạn có thể xem mẫu trước khi kết nối Gemini.</div>',unsafe_allow_html=True)
        with visual:
            st.markdown('''<div class="cc-doc-stack"><div class="cc-scene" aria-hidden="true"></div><div class="cc-doc-label">BA NGUỒN · MỘT HỒ SƠ</div>
            <div class="cc-document"><span>PDF</span><div><strong>Đơn đề nghị vay</strong><small>Thông tin người vay và khoản vay</small></div></div>
            <div class="cc-document"><span>PDF</span><div><strong>Xác nhận thu nhập</strong><small>Đối chiếu công việc và mức thu nhập</small></div></div>
            <div class="cc-document"><span>CSV</span><div><strong>Sao kê ngân hàng</strong><small>Kiểm tra giao dịch và nguồn trả lương</small></div></div><div class="cc-engine-note">Gemini đọc dữ liệu · Python tính chỉ số · Bạn kiểm tra</div></div>''',unsafe_allow_html=True)
    st.markdown('<div class="cc-section-label">CHỌN VIỆC BẠN MUỐN LÀM</div>',unsafe_allow_html=True)
    with st.container(key='cc_features'):
        left,right=st.columns(2,gap='large')
        with left,st.container(border=True,key="cc_credit_card"):
            st.markdown('<div class="cc-feature"><div class="cc-card-number">01 / CREDIT REVIEW</div><h3>Rà soát hồ sơ vay</h3><p>Kiểm tra nguồn, xem chỉ số và cảnh báo, rồi tạo báo cáo để con người rà soát.</p></div>',unsafe_allow_html=True)
            st.button('Mở vùng làm việc →',on_click=go,args=('1 · Hồ sơ',),key='home_credit')
        with right,st.container(border=True,key="cc_privacy_card"):
            st.markdown('<div class="cc-feature"><div class="cc-card-number">02 / DATA PRIVACY</div><h3>Bảo mật dữ liệu Excel</h3><p>Giả danh hóa thông tin nhận diện, giữ nguyên năm và số liệu tài chính cần cho tính toán.</p></div>',unsafe_allow_html=True)
            st.button('Xử lý file Excel →',on_click=go,args=('Bảo mật Excel',),key='home_excel')
    st.markdown('<div class="cc-section-label">TỪ TÀI LIỆU ĐẾN BÁO CÁO</div>',unsafe_allow_html=True)
    st.subheader('Bốn bước, mỗi bước một việc rõ ràng.')
    stages=[('01','Nhận tài liệu','Chọn nguồn hoặc hồ sơ mẫu để bắt đầu.'),
            ('02','Đối chiếu & xác minh','Kiểm tra dữ liệu đã đọc và nguồn thu.'),
            ('03','Hiểu chỉ số','Xem kết quả Python và căn cứ cảnh báo.'),
            ('04','Kiểm tra báo cáo','Rà soát nội dung rồi tải bản bàn giao.')]
    for col,(n,title,body) in zip(st.columns(4),stages):
        with col:st.markdown('<div class="cc-process"><span class="cc-card-number">'+n+'</span><strong>'+title+'</strong><p>'+body+'</p></div>',unsafe_allow_html=True)
    with st.expander('LLM, Python và con người làm gì?'):
        st.write('Gemini hỗ trợ đọc tài liệu, đề xuất nhãn và diễn giải. Python tính chỉ số và kiểm tra quy tắc. Con người đối chiếu nguồn, xác minh thu nhập và kiểm tra báo cáo.')
        st.write('Các hồ sơ mẫu phục vụ học tập. Kết quả lưu sẵn khác với lần gọi API mới; ứng dụng không tự duyệt vay.')

def work_title(eyebrow,title):
    st.markdown('<div class="cc-work-title"><div class="cc-section-label">'+escape(eyebrow)+'</div><h1>'+escape(title)+'</h1><p>LLM hỗ trợ · Python tính và kiểm tra · Con người xác minh</p></div>',unsafe_allow_html=True)

def guide(go):
    st.title('Bắt đầu từ việc bạn muốn làm.')
    st.write('Chọn một tác vụ. Dữ liệu đang xử lý được giữ khi chuyển trang trong cùng phiên.')
    with st.expander('Tôi muốn rà soát hồ sơ vay',expanded=True):
        st.write('Mở Rà soát hồ sơ, chọn hồ sơ mẫu hoặc tải PDF/CSV. Chạy Gemini khi đã lưu kết nối và đồng ý gửi dữ liệu. Đối chiếu nguồn trước khi xác nhận; xác minh thu nhập rồi mới tính chỉ số.')
        st.button('Đến bước Hồ sơ',on_click=go,args=('1 · Hồ sơ',),key='guide_credit')
    with st.expander('Tôi muốn bảo vệ file Excel'):
        st.write('Mở Bảo mật Excel, chọn file từ máy hoặc data_raw.xlsx trên GitHub. Bấm xử lý rồi tải kết quả. Đây là giả danh hóa, không phải toàn bộ Excel được khóa bằng mật khẩu.')
        st.button('Đến Bảo mật Excel',on_click=go,args=('Bảo mật Excel',),key='guide_excel')
    with st.expander('Tôi muốn dùng API key riêng'):
        st.write('Bấm Gemini trên thanh đầu trang. Chọn API key của tôi, nhập key và model rồi Lưu kết nối. Không gửi key trong chat. Chỉ lưu cấu hình chưa chứng minh key có quyền gọi model; cần thử tác vụ.')
    with st.expander('Tôi muốn giữ kết quả sau khi đóng web'):
        st.write('Tải PDF/ZIP trong bước Báo cáo. Giữ file .ccenc và mật khẩu riêng nếu cần nhập lại tài liệu mã hóa. Dữ liệu và mã giả danh theo phiên có thể bắt đầu lại khi tải lại web.')

def footer():
    st.markdown('<div class="cc-footer"><span><strong>CreditCheck</strong> · Project 01</span><span>Dữ liệu giả lập phục vụ học tập · Không tự duyệt vay · v0.15</span></div>',unsafe_allow_html=True)

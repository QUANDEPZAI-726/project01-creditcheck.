"""OFFLINE tests. HTTP responses are synthetic; these do not prove a live Google call."""
import copy,json,sys,unittest
from pathlib import Path
from unittest.mock import patch
import httpx
from google import genai
from streamlit.testing.v1 import AppTest
from ui_test_tools import choose_sample,navigate
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'app'))
from sample_data import load_sample
from gemini_service import GeminiClient,GeminiError,run_task,chat,PROBE_PROMPT
from api_contracts import task_prompt,compact_context,request_profile
from api_diagnostics import run_checks
from phase2 import review_extraction_phase2,verify_income,classification_prompt
from phase3 import summary_prompt,context,SECTIONS

def fixture_output(task):
    if task=='extraction':
        s=load_sample('HS01')
        return {'case_id':'HS01','documents':[{'document_id':d['document_id'],'fields':d['fields']} for d in s['case']['documents'] if d['available'] and d['source_type']!='bank_statement']}
    if task=='classification':
        obj=json.loads((ROOT/'incoming/HS01_classification.json').read_text())
        return {'case_id':'HS01','transactions':[{k:r[k] for k in ['transaction_id','label','reason']} for r in obj['transactions']]}
    if task=='summary':return {'case_id':'HS01'}|{k:[{'text':'Diễn giải thử nghiệm có nguồn, không phải API thật.', 'refs':['METRICS' if k=='metric_explanations' else 'CASE']}] for k in SECTIONS}
    return {'answer':[{'text':'Đây là dữ liệu kiểm thử; không phải Gemini trực tiếp.','refs':['METRICS']}]}

class FixtureClient:
    model='OFFLINE_TEST_NOT_LIVE'
    def generate(self,prompt):
        task=request_profile(prompt)[0]
        return fixture_output(task),{'model':self.model,'mock':True,'live_api':False}

def reviewed():
    s=load_sample('HS01')
    review_extraction_phase2(s,{'expected_version':s['version'],'checked':True,'reviewer':'TEST','reason':'Test fixture only'})
    return s

class ContractTests(unittest.TestCase):
    def test_actual_sdk_sends_90_seconds_not_20_and_compact_schema(self):
        requests=[];original=genai.Client
        def handler(req):
            requests.append(req)
            return httpx.Response(200,json={'candidates':[{'content':{'parts':[{'text':json.dumps(fixture_output('classification'))}],'role':'model'},'finishReason':'STOP'}],
                'responseId':'OFFLINE-FIXTURE','usageMetadata':{'promptTokenCount':10,'candidatesTokenCount':10,'totalTokenCount':20}})
        def factory(**kwargs):
            kwargs['http_options'].client_args={'transport':httpx.MockTransport(handler),'trust_env':False}
            kwargs['http_options'].async_client_args={'transport':httpx.MockTransport(handler),'trust_env':False}
            return original(**kwargs)
        with patch('google.genai.Client',side_effect=factory):
            obj,meta=GeminiClient('synthetic-test-key','gemini-3.5-flash-lite').generate(task_prompt(reviewed(),'classification'))
        self.assertEqual(len(requests),1)
        req=requests[0];body=json.loads(req.content);config=body['generationConfig']
        self.assertEqual(req.headers['X-Server-Timeout'],'90')
        self.assertNotIn('temperature',config)
        self.assertEqual(config['thinkingConfig'].get('thinkingLevel',config['thinkingConfig'].get('thinking_level')),'MINIMAL')
        self.assertEqual(config['maxOutputTokens'],4096)
        self.assertIn('responseJsonSchema',config)
        self.assertEqual(meta['sdk_timeout_ms'],90000)
        self.assertEqual(obj['case_id'],'HS01')
        self.assertEqual(request_profile('CREDITCHECK_TASK=classification\n'+json.dumps({'transaction_count':60}))[1],9000)

    def test_actual_sdk_504_is_reported_once_without_automatic_retry(self):
        count=[];original=genai.Client
        def handler(req):
            count.append(1)
            return httpx.Response(504,json={'error':{'code':504,'status':'DEADLINE_EXCEEDED','message':'Synthetic expired deadline'}})
        def factory(**kwargs):
            kwargs['http_options'].client_args={'transport':httpx.MockTransport(handler),'trust_env':False}
            kwargs['http_options'].async_client_args={'transport':httpx.MockTransport(handler),'trust_env':False}
            return original(**kwargs)
        c=GeminiClient('synthetic-test-key','gemini-3.5-flash-lite')
        with patch('google.genai.Client',side_effect=factory):
            with self.assertRaisesRegex(GeminiError,'504'):c.generate(PROBE_PROMPT)
        self.assertEqual(len(count),1)
        self.assertFalse(c.last_attempt['ok'])
        self.assertNotIn('synthetic-test-key',json.dumps(c.last_attempt))

    def test_incomplete_json_never_applied_even_if_it_parses(self):
        from types import SimpleNamespace
        from unittest.mock import MagicMock
        sdk=MagicMock();sdk.__enter__.return_value.models.generate_content.return_value=SimpleNamespace(text='{"ok":true}',candidates=[SimpleNamespace(finish_reason='MAX_TOKENS')])
        with patch('google.genai.Client',return_value=sdk):
            with self.assertRaisesRegex(GeminiError,'INCOMPLETE_RESPONSE'):GeminiClient('test','gemini-3.5-flash-lite').probe()

    def test_compact_classification_binds_only_existing_source_and_preserves_human_gate(self):
        s=reviewed();before=copy.deepcopy(s)
        out=run_task(s,'classification',FixtureClient())
        self.assertEqual(s,before)
        self.assertIsNone(out['phase2']['income_review'])
        txs={t['transaction_id']:t for t in s['case']['transactions']}
        for row in out['phase2']['classification']['rows']:self.assertEqual(row['evidence'],txs[row['transaction_id']]['evidence'])
        self.assertNotIn('evidence',out['llm_runs'][-1]['raw_response']['transactions'][0])

    def test_unknown_duplicate_and_wrong_case_compact_labels_rejected(self):
        s=reviewed();before=copy.deepcopy(s)
        for kind in ['unknown','duplicate','case']:
            obj=fixture_output('classification')
            if kind=='unknown':obj['transactions'][0]['transaction_id']='HS09-BOGUS'
            if kind=='duplicate':obj['transactions'][1]=copy.deepcopy(obj['transactions'][0])
            if kind=='case':obj['case_id']='HS09'
            with patch.object(FixtureClient,'generate',return_value=(obj,{})):
                with self.assertRaises(ValueError):run_task(s,'classification',FixtureClient())
            self.assertEqual(s,before)

    def test_summary_python_facts_and_audit_origin_preserved(self):
        s=run_task(reviewed(),'classification',FixtureClient())
        verify_income(s,{'expected_version':s['version'],'checked':True,'coverage_checked':True,'reviewer':'TEST','reason':'Fixture only','coverage_start':'2026-07-01','coverage_end':'2026-09-30'})
        before=copy.deepcopy(s)
        out=run_task(s,'summary',FixtureClient())
        self.assertEqual(s,before)
        self.assertEqual(out['phase3']['summary']['result']['metrics']['dti_pct'],33.54)
        self.assertIsNone(out['phase3']['content_review'])
        self.assertEqual(out['llm_runs'][-1]['raw_response'],fixture_output('summary'))
        event=next(e for e in reversed(out['events']) if e['action']=='IMPORT_SUMMARY')
        self.assertEqual(event['provenance'],'server_gemini_api')

    def test_prompts_reduce_copying_and_keep_all_reference_keys(self):
        s=reviewed()
        self.assertLess(len(task_prompt(s,'classification')),len(classification_prompt(s)))
        self.assertLess(len(task_prompt(s,'summary')),len(summary_prompt(s)))
        compact=compact_context(s);ctx=context(s)
        for k in ['references','metrics','risk_flags','missing_information']:self.assertEqual(compact[k],ctx[k])
        self.assertEqual(len(compact['transactions']),len(s['case']['transactions']))
        for row,original in zip(compact['transactions'],s['case']['transactions']):
            self.assertEqual(row['amount_vnd'],original['amount_vnd'])
            self.assertEqual(row['description'],original['description'])
            self.assertIn(row['source_ref'],compact['references'])

    def test_four_step_check_does_not_claim_mock_as_live(self):
        result=run_checks(FixtureClient)
        self.assertTrue(result['ok'],result)
        self.assertFalse(result['live_api_confirmed'])
        self.assertEqual(len(result['steps']),4)
        self.assertIn('không phải xác nhận',result['scope'])

    def test_diagnostic_stops_on_first_failure(self):
        def factory():raise GeminiError('Gemini [503]: synthetic')
        result=run_checks(factory)
        self.assertFalse(result['ok']);self.assertFalse(result['live_api_confirmed'])
        self.assertEqual(len(result['steps']),1)
        self.assertIn('503',result['steps'][0]['error'])

class DiagnosticUITests(unittest.TestCase):
    def test_diagnostics_require_configuration_and_consent(self):
        a=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
        self.assertTrue(next(b for b in a.button if b.key=='api_full_check').disabled)
        next(x for x in a.text_input if x.label=='API key Gemini của bạn').set_value('synthetic-test-key')
        next(b for b in a.button if b.label=='Lưu kết nối').click().run(timeout=30)
        self.assertTrue(next(b for b in a.button if b.key=='api_full_check').disabled)
        next(x for x in a.toggle if x.key=='api_full_check_consent').set_value(True).run(timeout=30)
        self.assertFalse(next(b for b in a.button if b.key=='api_full_check').disabled)
        with patch('gemini_service.GeminiClient.generate',side_effect=GeminiError('Gemini [504]: Synthetic timeout')):
            next(b for b in a.button if b.key=='api_full_check').click().run(timeout=30)
        self.assertFalse(a.exception,[e.message for e in a.exception])
        self.assertIsNone(a.session_state['dossier'])
        self.assertFalse(a.session_state['_full_api_check']['report']['live_api_confirmed'])
        self.assertTrue(any(b.proto.label.startswith('Tải kết quả kiểm thử API') for b in a.get('download_button')))

if __name__=='__main__':unittest.main()

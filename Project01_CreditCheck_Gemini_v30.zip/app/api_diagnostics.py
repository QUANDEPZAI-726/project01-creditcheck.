"""Opt-in live checks on an isolated synthetic fixture, never the active dossier."""
import copy
import hashlib
import json
from pathlib import Path
from core import now
from sample_data import load_sample
from phase2 import review_extraction_phase2,verify_income
from gemini_service import run_task,chat

TASK_LABELS={'extraction':'Trích xuất PDF','classification':'Phân loại sao kê','summary':'Tạo báo cáo','chat':'Trợ lý hỏi đáp'}

def run_checks(client_factory,progress=None):
    result={'app_version':'v0.30','started_at':now(),'case_id':'HS01','synthetic_data':True,
        'scope':'Kiểm thử kỹ thuật trên bản sao HS01. Các cổng kiểm tra được thiết lập bằng fixture thử nghiệm; không phải xác nhận của con người, không cập nhật hồ sơ đang mở.',
        'steps':[],'ok':False,'live_api_confirmed':False}
    baseline=load_sample('HS01');s=copy.deepcopy(baseline)
    expected=json.loads((Path(__file__).resolve().parents[1]/'incoming/HS01_classification.json').read_text())
    for i,task in enumerate(TASK_LABELS):
        row={'task':task,'label':TASK_LABELS[task],'ok':False};client=None
        if progress:progress(i,task)
        try:
            client=client_factory()
            if task=='chat':
                entry=chat(s,'Giải thích DTI của hồ sơ hiện tại, các đầu vào và điều cần xác minh.',[],client,page='4 · Báo cáo')
                raw=entry['answer'];meta=entry['api']
            else:
                s=run_task(s,task,client);raw=s['llm_runs'][-1]['raw_response'];meta=s['llm_runs'][-1]['api']
                if task=='extraction':
                    original={d['document_id']:{k:f['value'] for k,f in d['fields'].items()} for d in baseline['case']['documents']}
                    actual={d['document_id']:{k:f['value'] for k,f in d['fields'].items()} for d in s['case']['documents']}
                    if actual!=original:raise ValueError('Gemini đã trả dữ liệu nhưng trường trích xuất chưa khớp HS01 chuẩn; chưa đạt kiểm thử.')
                    review_extraction_phase2(s,{'expected_version':s['version'],'checked':True,'reviewer':'TECHNICAL_TEST_FIXTURE','reason':'Cổng kiểm thử tự động trên dữ liệu giả lập; không phải người xác minh.'})
                elif task=='classification':
                    actual={r['transaction_id']:r['label'] for r in s['phase2']['classification']['rows']}
                    labels={r['transaction_id']:r['label'] for r in expected['transactions']}
                    if actual!=labels:raise ValueError('Gemini đã trả nhãn nhưng chưa khớp tiêu chí HS01 chuẩn; cần đối chiếu trước khi trình bày.')
                    verify_income(s,{'expected_version':s['version'],'checked':True,'coverage_checked':True,'acknowledge_gap':True,
                        'reviewer':'TECHNICAL_TEST_FIXTURE','reason':'Thiết lập test fixture, không phải xác minh con người.','coverage_start':'2026-07-01','coverage_end':'2026-09-30'})
                    if s['phase2']['metrics']['dti_pct']!=33.54:raise ValueError('Chỉ số kiểm thử HS01 chưa khớp 33,54%.')
            row.update(ok=True,api=meta,response_sha256=hashlib.sha256(json.dumps(raw,ensure_ascii=False,sort_keys=True).encode()).hexdigest())
        except (ValueError,TypeError,KeyError) as exc:
            row.update(error=str(exc),attempt=copy.deepcopy(getattr(client,'last_attempt',None)))
            result['steps'].append(row)
            break
        result['steps'].append(row)
    result['finished_at']=now()
    result['ok']=len(result['steps'])==4 and all(x['ok'] for x in result['steps'])
    result['live_api_confirmed']=result['ok'] and all(x.get('api',{}).get('live_api') is True and not x.get('api',{}).get('mock') for x in result['steps'])
    return result

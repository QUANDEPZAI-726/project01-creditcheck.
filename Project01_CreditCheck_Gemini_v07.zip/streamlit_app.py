"""CreditCheck 0.5 — per-browser session, Gemini tasks and grounded chat."""
import base64
import copy
import hashlib
import hmac
import io
import json
import os
from pathlib import Path
import sys
import threading
import time
import zipfile
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'app'))
from core import make_state, public_state, edit_field, LABELS, now
from phase2 import review_extraction_phase2, verify_income, edit_classification, set_rate
from phase3 import report_text, summary_prompt, import_summary
from phase2 import classification_prompt, import_classification
from assisted_io import read_result, rule_draft
from traceability import sync
from gemini_service import GeminiClient, run_task, chat

def secret(name, default=''):
    try:
        return str(st.secrets.get(name, os.environ.get(name, default)))
    except (FileNotFoundError, st.errors.StreamlitSecretNotFoundError):
        return os.environ.get(name, default)

@st.cache_resource
def shared_budget():
    # Counters only; never store user dossiers/chats in a shared cache.
    return {'lock': threading.Lock(), 'times': []}

def reserve_call():
    code = secret('DEMO_ACCESS_CODE')
    if not code or not st.session_state.get('api_unlocked'):
        raise ValueError('Mở quyền chạy API bằng mã demo trước.')
    if not secret('GEMINI_API_KEY') or secret('GEMINI_API_KEY').startswith('REPLACE_'):
        raise ValueError('Chưa cấu hình Gemini API key thật trong Secrets.')
    b = shared_budget()
    current = time.monotonic()
    with b['lock']:
        b['times'] = [x for x in b['times'] if current - x < 3600]
        if len(b['times']) >= 60:
            raise ValueError('Đã đạt giới hạn demo 60 lượt/giờ trên máy chủ này.')
        if current - st.session_state.get('last_api_call', -100) < 5:
            raise ValueError('Chờ ít nhất 5 giây giữa hai lượt API.')
        if st.session_state.get('api_calls', 0) >= 30:
            raise ValueError('Phiên này đã đạt giới hạn 30 lượt API.')
        b['times'].append(current)
        st.session_state.last_api_call = current
        st.session_state.api_calls = st.session_state.get('api_calls', 0) + 1
    return GeminiClient(secret('GEMINI_API_KEY'), secret('GEMINI_MODEL', 'gemini-flash-latest'))

def sample(cid):
    folder = ROOT / 'runtime/cases' / cid
    manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
    files = {d['source_type']: (folder / d['path']).read_bytes()
             for d in manifest['documents'] if d['available']}
    coverage = next(d for d in manifest['documents'] if d['source_type'] == 'bank_statement')
    state = make_state(cid, files, coverage if coverage['available'] else None)
    sync(state)
    return state

def commit(state, reset_chat=True):
    sync(state)
    st.session_state.dossier = state
    if reset_chat:
        st.session_state.messages = []
    st.session_state.notice = 'Đã cập nhật. Kiểm tra nguồn và trạng thái trước khi tiếp tục.'
    st.rerun()

def mutate(fn, body):
    try:
        state = copy.deepcopy(st.session_state.dossier)
        fn(state, dict(body, expected_version=state['version']))
        commit(state)
    except (ValueError, TypeError, KeyError) as exc:
        st.error(str(exc))

def api_button(task, label, key):
    consent = st.checkbox('Tôi đồng ý gửi dữ liệu giả lập của hồ sơ này đến Google Gemini.', key=key+'_consent')
    if st.button(label, key=key, type='primary', disabled=not consent):
        try:
            client = reserve_call()
            with st.spinner('Gemini đang xử lý; Python sẽ kiểm tra kết quả…'):
                state = run_task(st.session_state.dossier, task, client)
            commit(state)
        except (ValueError, TypeError, KeyError) as exc:
            st.error(str(exc))
            st.caption('Dữ liệu cũ được giữ. Không tự dùng kết quả mẫu thay cho API.')

def saved_result_ui(task, state, key):
    label='phân loại giao dịch' if task=='classification' else 'báo cáo'
    with st.expander('Dùng kết quả LLM đã lưu · '+label, expanded=False):
        st.write('Không cần khóa API. Tải prompt hiện tại, dùng ChatGPT bên ngoài rồi nhập kết quả JSON; hoặc chọn ZIP báo cáo cũ. Không tự khôi phục xác nhận của người kiểm tra.')
        if task=='classification' and state['extraction_review']['status']!='Reviewed':
            st.info('Đối chiếu nguồn và xác nhận phần trích xuất trước.');return
        try:
            prompt=classification_prompt(state) if task=='classification' else summary_prompt(state)
        except ValueError as exc:
            st.warning(str(exc));return
        st.download_button('Tải prompt '+label, prompt, state['case']['case_id']+'_'+task+'_prompt.txt',key=key+'prompt')
        with st.expander('Xem prompt để sao chép'):st.code(prompt,language=None)
        with st.form(key+'import'):
            upload=st.file_uploader('JSON hoặc ZIP kết quả '+label,type=['json','zip'])
            raw=st.text_area('Hoặc dán JSON kết quả '+label)
            model=st.text_input('Tên công cụ/model tạo kết quả',placeholder='Ví dụ: ChatGPT — kết quả đã lưu')
            attest=st.checkbox('Đây là kết quả LLM đã nhận; chưa được xác minh bởi con người.')
            if st.form_submit_button('Nhập kết quả '+label):
                try:
                    data=upload.getvalue() if upload is not None else raw.encode('utf-8')
                    obj=read_result(data,task)
                    mutate(import_classification if task=='classification' else import_summary,{'result':obj,'model':model,'attest':attest})
                except (ValueError,TypeError,KeyError) as exc:st.error(str(exc))
        if task=='classification':
            candidate=ROOT/'incoming'/str(state['case']['case_id']+'_classification.json')
            if candidate.exists():
                st.caption('Ứng viên phân loại mẫu do ChatGPT soạn cho nguồn gốc. Chưa xác minh thu nhập; nguồn đã đổi sẽ bị từ chối.')
                st.download_button('Tải JSON phân loại mẫu '+state['case']['case_id'],candidate.read_bytes(),candidate.name,'application/json',key=key+'sample')
                if st.button('Nạp ứng viên ChatGPT đã lưu · '+state['case']['case_id'],key=key+'load'):
                    mutate(import_classification,{'result':read_result(candidate.read_bytes(),task),'model':'ChatGPT — ứng viên mẫu v0.7 đã lưu','attest':True})

def source_view(state, did, suffix):
    src = state['sources'].get(did)
    if not src:
        st.info('Nguồn chưa được cung cấp.')
        return
    st.text(src['text'])
    ext = '.csv' if src['role'] == 'bank_statement' else '.pdf'
    st.download_button('Tải nguồn '+did, base64.b64decode(src['bytes_b64']),
                       file_name=did+ext, key='source_'+suffix+'_'+did)

def archive(state):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('case.json', json.dumps(state['case'], ensure_ascii=False, indent=2))
        z.writestr('review_and_log.json', json.dumps(public_state(state), ensure_ascii=False, indent=2))
        z.writestr('evidence_trace.json', json.dumps(state['traceability'], ensure_ascii=False, indent=2))
        z.writestr('chat.json', json.dumps(st.session_state.messages, ensure_ascii=False, indent=2))
        if state['phase3']['summary']:
            z.writestr('summary.txt', report_text(state))
            z.writestr('summary.pdf', pdf_bytes(copy.deepcopy(state)))
        for did, src in state['sources'].items():
            z.writestr('sources/'+did+('.csv' if src['role']=='bank_statement' else '.pdf'), base64.b64decode(src['bytes_b64']))
    return buf.getvalue()

from html import escape
import pandas as pd
import altair as alt
from phase2 import value
from presentation import money, ratio, checkpoints, workflow, next_action, income_rows, debt_rows
from pdf_report import pdf_bytes

PAGES=['Tổng quan','1 · Hồ sơ','2 · Kiểm tra','3 · Phân tích','4 · Báo cáo','Trợ lý hồ sơ']
st.set_page_config(page_title='CreditCheck · Rà soát hồ sơ',page_icon='🏦',layout='wide')
st.markdown('''<style>
html,body,.stApp{font-family:"Segoe UI",Arial,sans-serif!important;}
.stApp,[data-testid="stAppViewContainer"]{background:#F4F7FB!important;color:#172B4D!important;}
[data-testid="stSidebar"]{background:#EAF0F8!important;border-right:1px solid #DCE4EF;}
.stApp h1,.stApp h2,.stApp h3,.stApp h4{color:#172B4D!important;letter-spacing:-.5px;}
.stApp h1{font-size:34px!important;} .stApp h2{font-size:25px!important;}
.stApp [data-testid="stMarkdownContainer"],.stApp label,.stApp label p,
.stApp [data-testid="stText"],.stApp [data-testid="stMetricLabel"],.stApp [data-testid="stMetricValue"]{color:#172B4D!important;}
.stApp [data-testid="stMarkdownContainer"] p,.stApp label p{font-size:16px;line-height:1.6;}
.stApp [data-testid="stCaptionContainer"],.stApp [data-testid="stCaptionContainer"] p{color:#52647A!important;}
.stApp input,.stApp textarea,.stApp [data-baseweb="select"]>div{background:#FFFFFF!important;color:#172B4D!important;}
.stApp input::placeholder,.stApp textarea::placeholder{color:#61738A!important;}
[role="listbox"],[role="option"]{background:#FFFFFF!important;color:#172B4D!important;}
.stApp button{border-radius:10px!important;min-height:44px;background:#FFFFFF;color:#172B4D;border-color:#CCD8E6;}
.stApp button p,.stApp button span{color:inherit!important;font-size:15px!important;}
.stApp button[kind="primary"],.stApp button[kind="primaryFormSubmit"]{background:#087F8C!important;color:white!important;border-color:#087F8C!important;}
.stApp button:disabled{opacity:.6;}
[data-testid="stMetric"]{background:#FFFFFF;border:1px solid #DCE4EF;padding:17px;border-radius:14px;}
[data-testid="stMetricValue"]{font-size:26px!important;}
[data-testid="stExpander"]{background:white;border-color:#DCE4EF;border-radius:12px;}
[data-testid="stExpander"] summary p{color:#172B4D!important;}
.cc-hero{padding:23px 27px;background:linear-gradient(115deg,#142B4D,#164D61);border-radius:18px;margin:8px 0 20px;}
.cc-hero h1{color:white!important;margin:6px 0;font-size:31px!important;}
.cc-hero p{color:#E6F4F5!important;margin:0;font-size:16px!important;}
.cc-eyebrow{font-size:12px;color:#A6DFE2;letter-spacing:2px;}
.cc-step{padding:13px 15px;background:#FFFFFF;border:1px solid #DCE4EF;border-radius:12px;height:78px;color:#172B4D;}
.cc-step strong{font-size:15px;} .cc-step small{display:block;color:#52647A;margin-top:5px;}
.cc-step.done{border-color:#087F8C;background:#E8F5F4;}
.cc-status{display:inline-block;padding:6px 12px;border-radius:30px;background:#E8F4F5;color:#076773;font-size:14px;}
.block-container{padding-top:2rem;max-width:1280px;}
@media(max-width:700px){.cc-hero{padding:17px}.cc-hero h1{font-size:25px!important}}
</style>''',unsafe_allow_html=True)

def go(page):st.session_state.page=page

def commit(state, reset_chat=True):
    sync(state)
    st.session_state.dossier=state
    st.session_state.portfolio[state['case']['case_id']]=copy.deepcopy(state)
    if reset_chat:st.session_state.messages=[]
    st.session_state.notice='Đã lưu thay đổi trong phiên. '+next_action(state)
    st.rerun()

def open_case(cid):
    st.session_state.portfolio[st.session_state.dossier['case']['case_id']]=copy.deepcopy(st.session_state.dossier)
    st.session_state.dossier=copy.deepcopy(st.session_state.portfolio[cid])
    st.session_state.messages=[]
    st.session_state.page='1 · Hồ sơ'

def next_button(target, enabled=True, reason=''):
    st.divider()
    if not enabled:st.info('Chưa thể tiếp tục: '+reason)
    st.button('Bước tiếp theo → '+target.split(' · ')[-1],type='primary',disabled=not enabled,
              on_click=go,args=(target,),key='next_'+target)

def readable_alerts(s):
    for alert in s['traceability']['alerts']:
        with st.expander(alert['message'],expanded=False):
            st.write(alert['rule'])
            for i,ev in enumerate(alert['evidence']):
                st.caption(ev['document_id']+' · '+ev['locator'])
                st.text(ev.get('quote') or 'Nguồn chưa được cung cấp; không có trích dẫn.')
                with st.expander('Xem tài liệu làm căn cứ '+str(i+1)):
                    source_view(s,ev['document_id'],alert['alert_id']+'_'+str(i))
            with st.expander('Chi tiết quy tắc'):
                st.json(alert['rule_inputs'])
    if not s['traceability']['alerts']:st.info('Chưa có cảnh báo theo các phép kiểm tra hiện tại. Không có nghĩa được duyệt vay.')

def chart(rows,x,y,title):
    if not rows:
        st.info('Chưa có đủ dữ liệu để vẽ biểu đồ này.')
        return
    c=alt.Chart(pd.DataFrame(rows)).mark_bar(color='#087F8C',cornerRadiusEnd=5).encode(
        x=alt.X(x+':Q',title='Đồng'),y=alt.Y(y+':N',sort=None,title=None),tooltip=[y,x]).properties(height=180,title=title)
    c=c.configure_axis(labelColor='#172B4D',titleColor='#52647A',labelFontSize=12).configure_title(color='#172B4D',fontSize=15).configure_view(stroke=None).configure(background='#FFFFFF')
    st.altair_chart(c,width='stretch',theme=None)

def technical_tools(s):
    with st.expander('Dữ liệu, nguồn gốc LLM và nhật ký · nâng cao'):
        st.caption('Không cần đọc JSON để sử dụng quy trình chính.')
        st.json(s['llm_runs'])
        st.json(s['events'])
        st.download_button('Tải dữ liệu JSON',json.dumps(s['case'],ensure_ascii=False,indent=2),s['case']['case_id']+'_case.json','application/json')
        st.download_button('Tải bảng truy vết',json.dumps(s['traceability'],ensure_ascii=False,indent=2),s['case']['case_id']+'_trace.json','application/json')

if 'dossier' not in st.session_state:
    st.session_state.dossier=sample('HS01')
if 'messages' not in st.session_state:st.session_state.messages=[]
if 'portfolio' not in st.session_state:
    st.session_state.portfolio={cid:sample(cid) for cid in ['HS01','HS02','HS03','HS04','HS05']}
state=st.session_state.dossier
sync(state)
cid=state['case']['case_id'];prefix=cid+'_'+str(state['version'])+'_'
st.session_state.portfolio[cid]=copy.deepcopy(state)

with st.sidebar:
    st.markdown('### 🏦 CreditCheck')
    st.caption('TRỢ LÝ RÀ SOÁT HỒ SƠ VAY')
    page=st.radio('Hành trình của bạn',PAGES,key='page')
    st.divider()
    st.caption('Hồ sơ đang mở')
    st.write(cid+' · '+str(value(state,'full_name') or 'Chưa có tên'))
    st.progress(sum(checkpoints(state))/4,text=str(sum(checkpoints(state)))+'/4 bước hoàn thành')
    with st.expander('Kết nối Gemini & quyền truy cập'):
        st.caption('Đã cấu hình khóa' if secret('GEMINI_API_KEY') and not secret('GEMINI_API_KEY').startswith('REPLACE_') else 'Chưa cấu hình khóa. Vẫn xem được hồ sơ và kết quả đã lưu.')
        code=st.text_input('Mã truy cập API của nhóm',type='password',key='access_input')
        if st.button('Mở quyền chạy API'):
            expected=secret('DEMO_ACCESS_CODE')
            st.session_state.api_unlocked=bool(expected and not expected.startswith('REPLACE_') and hmac.compare_digest(code.encode(),expected.encode()))
            if st.session_state.api_unlocked:st.success('Đã mở quyền cho phiên này.')
            else:st.error('Mã chưa đúng hoặc chưa cấu hình.')
        st.caption('Model: '+secret('GEMINI_MODEL','gemini-flash-latest'))
    st.caption('Dữ liệu lưu trong phiên hiện tại. Tải ZIP trước khi đóng hoặc tải lại web.')

labels={'Tổng quan':('TỔNG QUAN HỒ SƠ','Mỗi hồ sơ, một hành trình rõ ràng.'),
        '1 · Hồ sơ':('BƯỚC 01 / 04','Bắt đầu từ tài liệu của bạn.'),
        '2 · Kiểm tra':('BƯỚC 02 / 04','Kiểm tra những gì hệ thống đã hiểu.'),
        '3 · Phân tích':('BƯỚC 03 / 04','Hiểu chỉ số và căn cứ cảnh báo.'),
        '4 · Báo cáo':('BƯỚC 04 / 04','Đọc, kiểm tra và bàn giao báo cáo.'),
        'Trợ lý hồ sơ':('TRỢ LÝ THEO NGỮ CẢNH','Hỏi về hồ sơ đang mở.')}
eyebrow,title=labels[page]
st.markdown('<div class="cc-hero"><div class="cc-eyebrow">CREDITCHECK · '+eyebrow+'</div><h1>'+title+'</h1><p>LLM hỗ trợ · Python tính và kiểm tra · Con người xác minh</p></div>',unsafe_allow_html=True)
cols=st.columns(4)
cols[0].metric('Trạng thái hồ sơ','Thiếu thông tin' if state['phase3']['report_status']=='Insufficient information' else 'Cần rà soát')
cols[1].metric('Thu nhập đã xác minh',money(state['phase2']['metrics']['validated_monthly_income_vnd']))
cols[2].metric('DTI · trả nợ / thu nhập',ratio(state['phase2']['metrics']['dti_pct']))
cols[3].metric('Cảnh báo cần xem',len(state['traceability']['alerts']))
st.caption(cid+' · '+str(value(state,'full_name') or 'Chưa có tên người vay')+' · '+state['phase3']['report_status'])
if 'notice' in st.session_state:st.success(st.session_state.pop('notice'))
if state['traceability']['alerts']:st.warning('Cảnh báo chính: '+state['traceability']['alerts'][0]['message'])
st.info('Việc tiếp theo: '+next_action(state))
stepcols=st.columns(4)
for i,(col,done,name) in enumerate(zip(stepcols,checkpoints(state),['Hồ sơ','Kiểm tra','Phân tích','Báo cáo'])):
    col.markdown(f'<div class="cc-step {"done" if done else ""}"><strong>{i+1:02d} · {name}</strong><small>{"✓ Đã hoàn thành" if done else "Cần xử lý"}</small></div>',unsafe_allow_html=True)
st.caption('Tiến độ là các checkpoint xử lý hồ sơ; không phải điểm tín dụng hay khả năng duyệt vay.')

if page=='Tổng quan':
    st.subheader('Tiến độ hồ sơ đang mở')
    a,b=st.columns([1,2])
    done=sum(checkpoints(state))
    with a:
        data=pd.DataFrame({'Trạng thái':['Đã hoàn thành','Cần xử lý'],'Số bước':[done,4-done]})
        ring=alt.Chart(data).mark_arc(innerRadius=65,outerRadius=90).encode(theta='Số bước:Q',
            color=alt.Color('Trạng thái:N',scale=alt.Scale(domain=['Đã hoàn thành','Cần xử lý'],range=['#087F8C','#DCE4EF']),legend=None),tooltip=['Trạng thái','Số bước'])
        text=alt.Chart(pd.DataFrame({'Nhãn':[str(done)+'/4']})).mark_text(fontSize=28,fontWeight='bold',color='#172B4D').encode(text='Nhãn:N')
        st.altair_chart((ring+text).properties(height=220).configure_view(stroke=None).configure(background='#F4F7FB'),width='stretch',theme=None)
    with b:
        st.dataframe(workflow(state),hide_index=True,width='stretch')
        st.caption('Đủ nguồn → Kiểm tra & xác minh thu nhập → Có chỉ số → Báo cáo đã kiểm tra. Hồ sơ lỗi có thể dừng ở checkpoint cần bổ sung.')
    st.subheader('Tất cả hồ sơ trong phiên')
    rows=[]
    for key,s in st.session_state.portfolio.items():
        sync(s)
        rows.append({'Hồ sơ':key,'Người vay':value(s,'full_name') or 'Chưa có',
                     'Nguồn đã nhận':str(sum(d['available'] for d in s['case']['documents']))+'/3',
                     'Trạng thái':'Thiếu thông tin' if s['phase3']['report_status']=='Insufficient information' else 'Cần rà soát',
                     'Tiến độ':str(sum(checkpoints(s)))+'/4', 'Cảnh báo':len(s['traceability']['alerts'])})
    st.dataframe(rows,hide_index=True,width='stretch')
    selection=st.selectbox('Chọn hồ sơ để tiếp tục',list(st.session_state.portfolio),key='overview_case')
    st.button('Mở hồ sơ đã chọn',type='primary',on_click=open_case,args=(selection,))
    st.caption('Các hồ sơ mẫu bắt đầu bằng dữ liệu đọc theo mẫu. Kết quả kiểm tra trong phiên được giữ khi chuyển hồ sơ; chưa lưu lâu dài theo tài khoản.')
    st.subheader('Bạn sẽ làm gì?')
    st.dataframe([{'Bước':'01 · Hồ sơ','Bạn làm':'Chọn/tải ba nguồn; trích xuất thông tin'},
                  {'Bước':'02 · Kiểm tra','Bạn làm':'Đối chiếu dữ liệu; kiểm tra giao dịch và xác minh nguồn thu'},
                  {'Bước':'03 · Phân tích','Bạn làm':'Xem DTI, trả góp, cảnh báo và căn cứ'},
                  {'Bước':'04 · Báo cáo','Bạn làm':'Tạo nháp, đọc và xác nhận; tải PDF'}],hide_index=True,width='stretch')
    next_button('1 · Hồ sơ')

elif page=='1 · Hồ sơ':
    st.subheader('Chọn hồ sơ hoặc đưa tài liệu vào')
    left,right=st.columns([3,2])
    with left:
        selected=st.selectbox('Hồ sơ mẫu',list(st.session_state.portfolio),key='sample_selection')
        st.button('Mở hồ sơ mẫu',on_click=open_case,args=(selected,))
        if st.button('Khôi phục HS01 đã kiểm tra · kết quả lưu v0.4'):
            commit(json.loads((ROOT/'seed/HS01_session.json').read_text(encoding='utf-8')))
        st.caption('Khôi phục dùng kết quả LLM đã lưu, không gọi Gemini mới.')
    with right:
        for doc in state['case']['documents']:
            name={'application':'Đơn vay PDF','income_certificate':'Xác nhận thu nhập PDF','bank_statement':'Sao kê CSV'}[doc['source_type']]
            st.write(('✓ ' if doc['available'] else '○ ')+name)
    with st.expander('Tải hồ sơ giả lập của bạn'):
        with st.form('upload'):
            uploaded_cid=st.text_input('Mã hồ sơ mới',value='HS06')
            app=st.file_uploader('Đơn vay PDF',type=['pdf'])
            income=st.file_uploader('Xác nhận thu nhập PDF',type=['pdf'])
            bank=st.file_uploader('Sao kê CSV',type=['csv'])
            if st.form_submit_button('Đọc tài liệu'):
                try:
                    files={k:v.getvalue() for k,v in [('application',app),('income_certificate',income),('bank_statement',bank)] if v}
                    if sum(map(len,files.values()))>10*1024*1024:raise ValueError('Tổng tệp tối đa 10 MB.')
                    commit(make_state(uploaded_cid,files))
                except (ValueError,TypeError,KeyError) as exc:st.error(str(exc))
    st.subheader('Đọc thông tin bằng Gemini')
    st.write('Gemini trả dữ liệu có cấu trúc. Bước tiếp theo bạn sẽ đối chiếu với tài liệu nguồn.')
    api_button('extraction','Chạy Gemini trích xuất',prefix+'extract')
    technical_tools(state)
    next_button('2 · Kiểm tra')

elif page=='2 · Kiểm tra':
    st.subheader('1. Đối chiếu thông tin với nguồn')
    docs={d['document_id']:d for d in state['case']['documents'] if d['available'] and d['source_type']!='bank_statement'}
    if docs:
        did=st.selectbox('Tài liệu cần kiểm tra',list(docs),key=prefix+'check_doc')
        left,right=st.columns([1,1])
        with left:
            st.caption('Thông tin hệ thống đã đọc')
            st.dataframe([{'Thông tin':LABELS.get(k,k),'Giá trị':str(f['value'])} for k,f in docs[did]['fields'].items()],hide_index=True,width='stretch')
        with right:
            st.caption('Nguồn để đối chiếu')
            source_view(state,did,'check')
        with st.expander('Sửa thông tin đọc sai · cần căn cứ'):
            field=st.selectbox('Trường cần sửa',list(docs[did]['fields']),key=prefix+'field')
            with st.form(prefix+'edit_field'):
                raw=st.text_input('Giá trị JSON (số hoặc chuỗi trong dấu nháy)',value=json.dumps(docs[did]['fields'][field]['value'],ensure_ascii=False))
                pg=st.number_input('Trang nguồn',min_value=1,value=1)
                quote=st.text_input('Trích dẫn nguyên văn')
                reviewer=st.text_input('Người sửa')
                reason=st.text_input('Lý do sửa')
                if st.form_submit_button('Lưu sửa và kiểm tra lại'):
                    try:
                        v=json.loads(raw)
                        ev=[] if v is None else [{'document_id':did,'locator_type':'pdf_page_field','locator':f'page={pg}; field={LABELS[field]}','quote':quote}]
                        mutate(edit_field,{'document_id':did,'field':field,'value':v,'evidence':ev,'reviewer':reviewer,'reason':reason})
                    except ValueError as exc:st.error(str(exc))
    with st.form(prefix+'review_extraction'):
        name=st.text_input('Người kiểm tra')
        note=st.text_area('Ghi chú đối chiếu nguồn')
        checked=st.checkbox('Tôi đã đối chiếu các trường với tài liệu nguồn.')
        if st.form_submit_button('Xác nhận phần trích xuất'):
            mutate(review_extraction_phase2,{'reviewer':name,'reason':note,'checked':checked})
    st.caption('Xác nhận này chỉ kiểm tra thông tin đọc đúng tài liệu, chưa xác minh thu nhập.')
    st.subheader('2. Kiểm tra giao dịch và nguồn thu')
    if state['extraction_review']['status']!='Reviewed':st.info('Cần xác nhận trích xuất trước khi nhập phân loại.')
    api_button('classification','Chạy Gemini phân loại',prefix+'classify')
    saved_result_ui('classification',state,prefix+'saved_classification')
    classification=state['phase2']['classification']
    if classification:
        st.dataframe([{'Giao dịch':r['transaction_id'],'Loại':{'salary':'Lương','other':'Khoản khác','uncertain':'Chưa rõ'}[r['label']],
                       'Lý do':r['reason']} for r in classification['rows']],hide_index=True,width='stretch')
        with st.expander('Xem sao kê và sửa nhãn có căn cứ'):
            bank_id=next((k for k,s in state['sources'].items() if s['role']=='bank_statement'),None)
            if bank_id:source_view(state,bank_id,'classify')
            tid=st.selectbox('Giao dịch cần kiểm tra',[r['transaction_id'] for r in classification['rows']],key=prefix+'tid')
            with st.form(prefix+'edit_class'):
                label=st.selectbox('Nhãn mới',['salary','other','uncertain'],format_func=lambda x:{'salary':'Lương','other':'Khoản khác','uncertain':'Chưa rõ'}[x])
                reviewer=st.text_input('Người kiểm tra nhãn');reason=st.text_input('Lý do thay đổi');note=st.text_area('Căn cứ bổ sung đã kiểm tra')
                if st.form_submit_button('Cập nhật nhãn'):mutate(edit_classification,{'transaction_id':tid,'label':label,'reviewer':reviewer,'reason':reason,'supporting_note':note})
    pre=state['phase2'].get('preview')
    if pre:
        st.metric('Lương bình quân xem trước · chưa xác minh',money(pre['mean_salary_vnd']))
        if pre['unresolved_transaction_ids']:st.warning('Còn '+str(len(pre['unresolved_transaction_ids']))+' khoản chưa rõ. Cần căn cứ trước khi xác minh.')
        with st.expander('Chi tiết tổng hợp nguồn thu'):st.json(pre)
    coverage=next(d for d in state['case']['documents'] if d['source_type']=='bank_statement')
    with st.form(prefix+'income_review'):
        start=st.text_input('Từ ngày YYYY-MM-DD',value=coverage.get('coverage_start') or '2026-07-01')
        end=st.text_input('Đến ngày YYYY-MM-DD',value=coverage.get('coverage_end') or '2026-09-30')
        name=st.text_input('Người xác minh thu nhập');note=st.text_area('Ghi chú xác minh và căn cứ dùng thu nhập sao kê')
        checked=st.checkbox('Đã đối chiếu nhãn và nguồn trả lương.');complete=st.checkbox('Đã kiểm tra kỳ sao kê đầy đủ.')
        gap=st.checkbox('Đã xem chênh lệch thu nhập nếu có và ghi căn cứ ở trên.')
        if st.form_submit_button('Xác minh thu nhập và tính chỉ số'):
            mutate(verify_income,{'coverage_start':start,'coverage_end':end,'reviewer':name,'reason':note,'checked':checked,'coverage_checked':complete,'acknowledge_gap':gap})
    enabled=state['phase2']['income_review'] is not None
    next_button('3 · Phân tích',enabled,'Cần đủ nguồn, phân loại rõ và xác minh thu nhập. '+next_action(state))
    if not enabled:st.button('Xem cảnh báo và dữ liệu chưa đủ',on_click=go,args=('3 · Phân tích',))

elif page=='3 · Phân tích':
    st.subheader('Thu nhập và nghĩa vụ trả nợ')
    st.metric('Trả góp mới mỗi tháng',money(state['phase2']['metrics']['monthly_payment_vnd']))
    a,b=st.columns(2)
    with a:
        chart(income_rows(state),'Thu nhập (đ)','Nguồn','Thu nhập theo nguồn')
        st.caption('Khai báo và xác nhận là dữ kiện tài liệu; chỉ sao kê đã xác minh mới là đầu vào tính DTI.')
    with b:
        chart(debt_rows(state),'Số tiền (đ)','Khoản','Thu nhập sau nghĩa vụ trả nợ')
        st.caption('Phần còn lại chưa trừ chi phí sinh hoạt, không phải tiền tiết kiệm.')
    st.write('DTI là tổng nợ hiện tại và trả góp mới chia thu nhập đã xác minh. Chỉ số chưa có được giữ trống, không biến thành 0.')
    st.subheader('Cảnh báo và căn cứ')
    readable_alerts(state)
    with st.expander('Giả định và cách tính · có thể điều chỉnh'):
        st.caption('Ngưỡng DTI 40%, độ lệch 20% là giả định bài tập; chưa tính phí/bảo hiểm.')
        with st.form(prefix+'rate'):
            rate=st.number_input('Lãi danh nghĩa %/năm',min_value=0.0,max_value=100.0,value=state['phase2']['config']['annual_nominal_rate']*100)
            name=st.text_input('Người thay giả định');note=st.text_input('Lý do thay lãi suất')
            if st.form_submit_button('Tính lại với lãi suất mới'):mutate(set_rate,{'annual_nominal_rate':rate/100,'reviewer':name,'reason':note})
        st.json(state['phase2'].get('calculation_trace'))
    next_button('4 · Báo cáo')
    st.caption('Có thể tạo báo cáo ghi thiếu thông tin. Điều đó không tự xác minh thu nhập hoặc cho phép duyệt vay.')

elif page=='4 · Báo cáo':
    st.subheader('Báo cáo có thể kiểm tra và bàn giao')
    api_button('summary','Chạy Gemini tạo báo cáo',prefix+'summary')
    saved_result_ui('summary',state,prefix+'saved_summary')
    st.caption('Để thử PDF khi API chưa sẵn sàng: tạo bản nháp bằng quy tắc, ghi rõ không phải LLM. Không tự xác minh hoặc duyệt vay.')
    if st.button('Tạo bản nháp quy tắc · không dùng API',key=prefix+'rule_draft'):
        mutate(rule_draft,{})
    summary=state['phase3']['summary']
    if summary:
        saved=summary.get('mode')!='API_DIRECT'
        st.caption('Bản nháp bằng quy tắc Python · không phải LLM' if summary.get('mode')=='RULE_BASED' else ('Kết quả LLM đã lưu/nhập trước đó' if saved else 'Báo cáo từ lần gọi Gemini trực tiếp'))
        st.markdown('**Nội dung: '+('Đã kiểm tra' if state['phase3']['content_review'] else 'Bản nháp chưa kiểm tra')+' · '+state['phase3']['report_status']+'**')
        for key,label in [('overview','Tóm tắt hồ sơ'),('metric_explanations','Diễn giải chỉ số'),('limitations','Giới hạn'),('verification_questions','Câu hỏi cần xác minh')]:
            with st.expander(label,expanded=key in ['overview','verification_questions']):
                for row in summary['result'][key]:
                    st.write(row['text'])
                    with st.expander('Căn cứ: '+', '.join(row['refs'])):
                        for ref in row['refs']:
                            st.caption(ref)
                            if ref in state['sources']:source_view(state,ref,'summary_'+key+'_'+str(summary['result'][key].index(row)))
                            else:st.json(state['phase3']['context']['references'][ref])
        with st.form(prefix+'summary_review'):
            name=st.text_input('Người kiểm tra báo cáo');note=st.text_area('Ghi chú kiểm tra nội dung')
            facts=st.checkbox('Đã kiểm tra số liệu, nguồn, cảnh báo và thông tin thiếu.')
            limits=st.checkbox('Đã kiểm tra giới hạn và câu hỏi xác minh; đây không phải quyết định vay.')
            if st.form_submit_button('Xác nhận đã kiểm tra nội dung'):
                from phase3 import review_summary
                mutate(review_summary,{'reviewer':name,'reason':note,'checked_facts':facts,'checked_limits':limits})
        st.subheader('Tải bản báo cáo')
        st.caption('PDF giữ trạng thái bản nháp/đã kiểm tra, nguồn và giới hạn; không phải giấy duyệt vay.')
        st.download_button('Tải báo cáo PDF',pdf_bytes(copy.deepcopy(state)),cid+'_Credit_Review.pdf','application/pdf',type='primary')
        with st.expander('Tải TXT, ZIP và dữ liệu nâng cao'):
            st.download_button('Tải báo cáo TXT',report_text(state),cid+'_Credit_Review_Summary.txt')
            st.download_button('Tải ZIP báo cáo và hồ sơ',archive(state),cid+'_review.zip','application/zip')
            st.json(summary['result'])
    else:
        st.info('Chưa có báo cáo. Chạy Gemini, nhập kết quả LLM đã lưu hoặc tạo bản nháp quy tắc để thử PDF.')
        st.download_button('Tải báo cáo PDF',b'',cid+'_Credit_Review.pdf','application/pdf',disabled=True)
    st.button('Quay về tổng quan hồ sơ',on_click=go,args=('Tổng quan',))

else:
    st.write('Hỏi về cảnh báo, dữ liệu còn thiếu hoặc cách tính của '+cid+'. Trợ lý không sửa dữ liệu hay xác nhận thay bạn.')
    consent=st.checkbox('Đồng ý gửi câu hỏi và ngữ cảnh hồ sơ giả lập đến Gemini.',key=prefix+'chat_consent')
    if st.button('Xóa lịch sử chat của phiên'):
        st.session_state.messages=[];st.rerun()
    for entry in st.session_state.messages:
        with st.chat_message('user'):st.text(entry['question'])
        with st.chat_message('assistant'):
            for row in entry['answer']:st.text(row['text']);st.caption('Căn cứ: '+', '.join(row['refs']))
            with st.expander('Mở dữ liệu tham chiếu'):st.json(entry['references'])
    question=st.chat_input('Ví dụ: Vì sao hồ sơ này có cảnh báo?',disabled=not consent)
    if question:
        try:
            client=reserve_call()
            with st.spinner('Gemini đang giải thích…'):entry=chat(state,question,st.session_state.messages,client)
            st.session_state.messages=(st.session_state.messages+[entry])[-20:];st.rerun()
        except (ValueError,TypeError,KeyError) as exc:st.error(str(exc))

st.divider()
st.caption('Hồ sơ giả lập phục vụ học tập · Danh tính người kiểm tra chưa xác thực · Không tự duyệt vay · v0.7')



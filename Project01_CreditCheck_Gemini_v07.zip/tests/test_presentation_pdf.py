import copy,io,json,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'app'))
from sample_data import load_sample
from presentation import checkpoints,income_rows,debt_rows,next_action
from pdf_report import pdf_bytes
from phase3 import template,import_summary
from traceability import sync
from pypdf import PdfReader
from streamlit.testing.v1 import AppTest

class PresentationPDFTests(unittest.TestCase):
    def seed(self):
        s=json.loads((ROOT/'seed/HS01_session.json').read_text());sync(s);return s
    def test_unverified_metrics_are_not_charted_as_zero(self):
        s=load_sample('HS01')
        self.assertEqual(debt_rows(s),[])
        self.assertNotIn('Sao kê đã xác minh',[r['Nguồn'] for r in income_rows(s)])
        self.assertEqual(checkpoints(s),[True,False,False,False])
    def test_reviewed_progress_not_approval(self):
        s=self.seed()
        self.assertEqual(checkpoints(s),[True]*4)
        self.assertEqual(s['phase3']['report_status'],'Human review required')
        self.assertIn('vẫn cần',next_action(s))
    def test_pdf_vietnamese_metrics_provenance_and_font(self):
        pdf=PdfReader(io.BytesIO(pdf_bytes(self.seed())))
        text='\n'.join(p.extract_text() for p in pdf.pages)
        for term in ['Nguyễn An Minh','33,54%','4.707.347','Reviewed','Human review required','HS01-APP','Không phải quyết định']:
            self.assertIn(term,text)
        self.assertTrue(any(font.get_object().get('/FontDescriptor',{}).get_object().get('/FontFile2') for page in pdf.pages for font in page['/Resources']['/Font'].values() if font.get_object().get('/FontDescriptor')))
    def test_missing_source_pdf_is_draft_with_null_metrics(self):
        s=load_sample('HS02');obj=template(s)
        for key in ['overview','limitations','verification_questions']:
            obj[key]=[{'text':'Hồ sơ giả lập cần bổ sung nguồn và người kiểm tra.','refs':['SCOPE']}]
        obj['metric_explanations']=[{'text':'Chưa có chỉ số vì chưa xác minh nguồn thu.','refs':['PENDING_METRICS']}]
        import_summary(s,{'expected_version':s['version'],'attest':True,'model':'TEST FIXTURE','result':obj});sync(s)
        text='\n'.join(p.extract_text() for p in PdfReader(io.BytesIO(pdf_bytes(s))).pages)
        self.assertIn('Insufficient information',text);self.assertIn('Draft',text);self.assertIn('MISSING_DOCUMENT',text)
        self.assertTrue(all(v is None for v in s['phase2']['metrics'].values()))
    def test_pdf_requires_report(self):
        with self.assertRaises(ValueError):pdf_bytes(load_sample('HS01'))
    def test_switch_back_keeps_reviewed_case_in_session(self):
        at=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
        at.radio[0].set_value('1 · Hồ sơ').run(timeout=30)
        next(b for b in at.button if b.label.startswith('Khôi phục HS01')).click().run(timeout=30)
        at.radio[0].set_value('Tổng quan').run(timeout=30)
        next(x for x in at.selectbox if x.label=='Chọn hồ sơ để tiếp tục').select('HS03').run(timeout=30)
        next(b for b in at.button if b.label=='Mở hồ sơ đã chọn').click().run(timeout=30)
        self.assertEqual(at.session_state['dossier']['case']['case_id'],'HS03')
        at.radio[0].set_value('Tổng quan').run(timeout=30)
        next(x for x in at.selectbox if x.label=='Chọn hồ sơ để tiếp tục').select('HS01').run(timeout=30)
        next(b for b in at.button if b.label=='Mở hồ sơ đã chọn').click().run(timeout=30)
        self.assertFalse(at.exception)
        self.assertIsNotNone(at.session_state['dossier']['phase3']['content_review'])
    def test_next_disabled_until_income_review(self):
        at=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
        at.radio[0].set_value('2 · Kiểm tra').run(timeout=30)
        self.assertTrue(next(b for b in at.button if b.label=='Bước tiếp theo → Phân tích').disabled)
        self.assertFalse(next(b for b in at.button if b.label=='Xem cảnh báo và dữ liệu chưa đủ').disabled)
    def test_navigation_callback(self):
        at=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
        next(b for b in at.button if b.label=='Bước tiếp theo → Hồ sơ').click().run(timeout=30)
        self.assertEqual(at.radio[0].value,'1 · Hồ sơ');self.assertFalse(at.exception)

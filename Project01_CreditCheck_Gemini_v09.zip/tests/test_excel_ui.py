import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from streamlit.testing.v1 import AppTest
from test_privacy_excel import fixture
APP=Path(__file__).resolve().parents[1]/'streamlit_app.py'

class ExcelUITests(unittest.TestCase):
    def test_github_source_process_and_download(self):
        with tempfile.TemporaryDirectory() as d,patch.dict(os.environ,{'CREDITCHECK_DEPLOY_ROOT':d}):
            Path(d,'data_raw.xlsx').write_bytes(fixture())
            at=AppTest.from_file(str(APP)).run(timeout=30)
            at.radio[0].set_value('Bảo mật Excel').run(timeout=30)
            self.assertFalse(at.exception,[e.message for e in at.exception])
            self.assertNotIn('DTI · trả nợ / thu nhập',[x.label for x in at.metric])
            next(x for x in at.radio if x.label=='Nguồn dữ liệu Excel').set_value('data_raw.xlsx trên GitHub').run(timeout=30)
            next(x for x in at.button if x.label=='Xử lý bảo mật Excel').click().run(timeout=30)
            self.assertFalse(at.exception,[e.message for e in at.exception]);self.assertFalse(at.error)
            result=at.session_state['_excel_result'];self.assertEqual(result['row_count'],3)
            self.assertTrue(result['data'].startswith(b'PK'))
            self.assertEqual([x.value for x in at.metric],['3','17','2'])

    def test_bad_source_clears_download(self):
        with tempfile.TemporaryDirectory() as d,patch.dict(os.environ,{'CREDITCHECK_DEPLOY_ROOT':d}):
            p=Path(d,'data_raw.xlsx');p.write_bytes(fixture())
            at=AppTest.from_file(str(APP)).run(timeout=30)
            at.radio[0].set_value('Bảo mật Excel').run(timeout=30)
            next(x for x in at.radio if x.label=='Nguồn dữ liệu Excel').set_value('data_raw.xlsx trên GitHub').run(timeout=30)
            next(x for x in at.button if x.label=='Xử lý bảo mật Excel').click().run(timeout=30)
            self.assertIn('_excel_result',at.session_state)
            p.write_bytes(b'bad')
            next(x for x in at.button if x.label=='Xử lý bảo mật Excel').click().run(timeout=30)
            self.assertFalse(at.exception);self.assertTrue(at.error)
            self.assertNotIn('_excel_result',at.session_state)

if __name__=='__main__':unittest.main()

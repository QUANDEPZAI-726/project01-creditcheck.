"""Public landing page and horizontal navigation; all operations use native widgets."""
import base64
from html import escape
from pathlib import Path
import streamlit as st

WORK_PAGES=['Tổng quan','1 · Hồ sơ','2 · Kiểm tra','3 · Phân tích','4 · Báo cáo']
SECTIONS=['Trang chủ','Rà soát hồ sơ','Bảo mật Excel','Trợ lý','Hướng dẫn']

def section_for(page):
    if page in WORK_PAGES:return 'Rà soát hồ sơ'
    return 'Trợ lý' if page=='Trợ lý hồ sơ' else page

def select_section():
    section=st.session_state['_nav_section']
    if section=='Rà soát hồ sơ':
        st.session_state.page=st.session_state.get('_last_work_page','1 · Hồ sơ')
    else:
        st.session_state.page='Trợ lý hồ sơ' if section=='Trợ lý' else section

def shell_styles():
    st.markdown('''<style>
    .stApp,[data-testid="stAppViewContainer"]{background:#FAFBFC!important;}
    .block-container{max-width:1320px;padding-top:1.2rem;padding-bottom:2rem;}
    .st-key-cc_header{background:white;border-bottom:1px solid #E1E7ED;padding:12px 0 18px;margin-bottom:28px;}
    .cc-brand{display:flex;align-items:center;gap:12px;min-height:50px;text-decoration:none;}
    .cc-brand img{height:50px;width:50px;object-fit:contain;}
    .cc-brand strong{font-size:21px;color:#102A43;letter-spacing:-.5px;}
    .cc-brand small{display:block;font-size:10px;color:#63788C;letter-spacing:1.5px;margin-top:2px;}
    .st-key-cc_brand button{border:none!important;padding:0!important;min-height:30px!important;background:transparent!important;}
    .st-key-cc_brand button p{font-size:21px!important;font-weight:700;color:#102A43!important;}
    .st-key-cc_brand [data-testid="stCaptionContainer"] p{font-size:10px!important;letter-spacing:1px;}
    .st-key-cc_header [role="radiogroup"]{gap:5px;flex-wrap:wrap;}
    .st-key-cc_header [data-baseweb="radio"]{padding:9px 12px;border-radius:8px;margin:0;}
    .st-key-cc_header [data-baseweb="radio"]>div:first-child{display:none;}
    .st-key-cc_header [data-baseweb="radio"]:has(input:checked){background:#EDF4F8;border-bottom:2px solid #087F8C;}
    .st-key-cc_header label p{font-size:14px!important;font-weight:600;white-space:nowrap;}
    .cc-home-label{font-size:11px;font-weight:700;color:#087F8C;letter-spacing:2px;margin-bottom:20px;}
    .stApp h1.cc-home-title{font-family:Georgia,"Times New Roman",serif!important;font-size:52px!important;line-height:1.15;color:#102A43!important;letter-spacing:-1.5px;margin:0 0 22px;}
    .cc-home-title em{font-weight:400;color:#9A762D;}
    .cc-home-copy{font-size:17px!important;line-height:1.8;color:#52647A!important;max-width:590px;margin-bottom:20px;}
    .st-key-cc_landing{padding:32px 0 36px;}
    .st-key-cc_landing button[kind="primary"]{background:#102A43!important;border-color:#102A43!important;}
    .cc-doc-stack{background:linear-gradient(145deg,#F1F5F8,#E9F1F5);border:1px solid #DCE5ED;border-radius:18px;padding:28px;margin:8px 0 0 28px;}
    .cc-doc-label{font-size:11px;color:#63788C;letter-spacing:2px;margin-bottom:16px;}
    .cc-document{display:flex;align-items:center;gap:14px;padding:17px;background:white;border:1px solid #DFE7EE;border-radius:10px;margin-bottom:12px;}
    .cc-document span{font-size:11px;color:#8B6A23;background:#FAF5E8;padding:10px;border-radius:6px;font-weight:700;}
    .cc-document strong{font-size:15px;color:#173B50;display:block;}
    .cc-document small{font-size:12px;color:#64748B;}
    .cc-document:last-child{margin-bottom:0;}
    .cc-intro-line{margin:10px 0 22px;color:#63788C;font-size:13px;line-height:1.6;}
    .cc-section-label{font-size:11px;color:#087F8C;letter-spacing:1.8px;margin:18px 0 8px;font-weight:700;}
    .cc-card-number{font-size:12px;color:#9A762D;font-weight:700;letter-spacing:1px;margin-bottom:12px;}
    .cc-feature h3{font-size:23px!important;margin:0 0 10px;}
    .cc-feature p{font-size:15px!important;line-height:1.7;color:#52647A!important;}
    .cc-process{padding:20px 0;border-top:1px solid #DFE7ED;}
    .cc-process strong{display:block;font-size:17px;color:#102A43;margin:8px 0;}
    .cc-process p{color:#52647A!important;font-size:14px!important;line-height:1.7;}
    .cc-footer{margin-top:34px;padding:22px 0;border-top:1px solid #E1E7ED;font-size:12px;color:#63788C;display:flex;justify-content:space-between;gap:16px;flex-wrap:wrap;}
    .cc-work-title h1{font-size:30px!important;line-height:1.3;margin:5px 0 12px;}
    .cc-work-title p{color:#52647A!important;margin-bottom:22px;font-size:15px!important;}
    .st-key-cc_steps{margin:10px 0 15px;}
    @media(max-width:760px){
      .block-container{padding-left:1rem;padding-right:1rem;}
      .stApp h1.cc-home-title{font-size:35px!important;letter-spacing:-.7px;}
      .cc-doc-stack{margin:18px 0 0;padding:18px;}
      .st-key-cc_landing{padding:10px 0 20px;}
      .st-key-cc_header [data-baseweb="radio"]{padding:7px 9px;}
      .st-key-cc_header [role="radiogroup"]{gap:3px;}
    }
    </style>''',unsafe_allow_html=True)

def brand_html(logo):
    img=''
    if logo and Path(logo).exists():
        mime='image/png' if Path(logo).suffix.lower()=='.png' else 'image/jpeg'
        img='<img alt="Logo nhóm" src="data:'+mime+';base64,'+base64.b64encode(Path(logo).read_bytes()).decode()+'">'
    return '<div class="cc-brand">'+img+'<div><strong>CreditCheck</strong><small>PROJECT 01 · CREDIT REVIEW</small></div></div>'

def navigation(logo,connection,go):
    page=st.session_state.get('page','Trang chủ')
    if page in WORK_PAGES:st.session_state['_last_work_page']=page
    st.session_state['_nav_section']=section_for(page)
    with st.container(key='cc_header'):
        brand,menu,config=st.columns([1.25,3.45,.85],vertical_alignment='center')
        with brand,st.container(key='cc_brand'):
            with st.container(horizontal=True,vertical_alignment='center',gap='small'):
                if logo and Path(logo).exists():st.image(str(logo),width=48)
                st.button('CreditCheck',type='tertiary',on_click=go,args=('Trang chủ',),key='brand_home')
            st.caption('PROJECT 01 · CREDIT REVIEW')
        with menu:
            st.radio('Điều hướng chính',SECTIONS,horizontal=True,key='_nav_section',
                     label_visibility='collapsed',on_change=select_section)
        with config:
            with st.popover('Gemini',help='Kết nối API key và chọn model',width='stretch'):
                connection()
    return st.session_state.page

def landing(go):
    with st.container(key='cc_landing'):
        intro,visual=st.columns([1.25,1],gap='large',vertical_alignment='center')
        with intro:
            st.markdown('''<div class="cc-home-label">CREDITCHECK · TRỢ LÝ RÀ SOÁT HỒ SƠ</div>
            <h1 class="cc-home-title">Hồ sơ rõ ràng.<br><em>Rà soát có căn cứ.</em></h1>
            <p class="cc-home-copy">Đối chiếu tài liệu vay, xem chỉ số do Python tính và kiểm tra phần diễn giải của Gemini. Một quy trình rõ ràng từ tài liệu đến báo cáo.</p>''',unsafe_allow_html=True)
            primary,secondary=st.columns([1,1])
            with primary:st.button('Bắt đầu rà soát',type='primary',width='stretch',on_click=go,args=('1 · Hồ sơ',),key='home_start')
            with secondary:st.button('Dùng thử hồ sơ mẫu',width='stretch',on_click=go,args=('1 · Hồ sơ',),key='home_sample')
            st.markdown('<div class="cc-intro-line">Bắt đầu bằng tài liệu của bạn hoặc một hồ sơ mẫu. Chưa cần API key để khám phá.</div>',unsafe_allow_html=True)
        with visual:
            st.markdown('''<div class="cc-doc-stack"><div class="cc-doc-label">BA NGUỒN · MỘT HỒ SƠ</div>
            <div class="cc-document"><span>PDF</span><div><strong>Đơn đề nghị vay</strong><small>Thông tin người vay và khoản vay</small></div></div>
            <div class="cc-document"><span>PDF</span><div><strong>Xác nhận thu nhập</strong><small>Đối chiếu công việc và mức thu nhập</small></div></div>
            <div class="cc-document"><span>CSV</span><div><strong>Sao kê ngân hàng</strong><small>Kiểm tra giao dịch và nguồn trả lương</small></div></div></div>''',unsafe_allow_html=True)
    st.markdown('<div class="cc-section-label">CHỌN VIỆC BẠN MUỐN LÀM</div>',unsafe_allow_html=True)
    left,right=st.columns(2,gap='large')
    with left,st.container(border=True):
        st.markdown('<div class="cc-feature"><div class="cc-card-number">01 / CREDIT REVIEW</div><h3>Rà soát hồ sơ vay</h3><p>Kiểm tra nguồn, xem chỉ số và cảnh báo, rồi tạo báo cáo để con người rà soát.</p></div>',unsafe_allow_html=True)
        st.button('Mở vùng làm việc →',on_click=go,args=('1 · Hồ sơ',),key='home_credit')
    with right,st.container(border=True):
        st.markdown('<div class="cc-feature"><div class="cc-card-number">02 / DATA PRIVACY</div><h3>Bảo mật dữ liệu Excel</h3><p>Giả danh hóa thông tin nhận diện, giữ nguyên năm và số liệu tài chính cần cho tính toán.</p></div>',unsafe_allow_html=True)
        st.button('Xử lý file Excel →',on_click=go,args=('Bảo mật Excel',),key='home_excel')
    st.markdown('<div class="cc-section-label">TỪ TÀI LIỆU ĐẾN BÁO CÁO</div>',unsafe_allow_html=True)
    st.subheader('Bốn bước, mỗi bước một việc rõ ràng.')
    stages=[('01','Nhận tài liệu','Chọn nguồn hoặc hồ sơ mẫu để bắt đầu.'),
            ('02','Đối chiếu & xác minh','Kiểm tra dữ liệu đã đọc và nguồn thu.'),
            ('03','Hiểu chỉ số','Xem kết quả Python và căn cứ cảnh báo.'),
            ('04','Kiểm tra báo cáo','Rà soát nội dung rồi tải bản bàn giao.')]
    for col,(n,title,body) in zip(st.columns(4),stages):
        with col:st.markdown('<div class="cc-process"><span class="cc-card-number">'+n+'</span><strong>'+title+'</strong><p>'+body+'</p></div>',unsafe_allow_html=True)
    with st.expander('LLM, Python và con người làm gì?'):
        st.write('Gemini hỗ trợ đọc tài liệu, đề xuất nhãn và diễn giải. Python tính chỉ số và kiểm tra quy tắc. Con người đối chiếu nguồn, xác minh thu nhập và kiểm tra báo cáo.')
        st.write('Các hồ sơ mẫu phục vụ học tập. Kết quả lưu sẵn khác với lần gọi API mới; ứng dụng không tự duyệt vay.')

def work_title(eyebrow,title):
    st.markdown('<div class="cc-work-title"><div class="cc-section-label">'+escape(eyebrow)+'</div><h1>'+escape(title)+'</h1><p>LLM hỗ trợ · Python tính và kiểm tra · Con người xác minh</p></div>',unsafe_allow_html=True)

def guide(go):
    st.title('Bắt đầu từ việc bạn muốn làm.')
    st.write('Chọn một tác vụ. Dữ liệu đang xử lý được giữ khi chuyển trang trong cùng phiên.')
    with st.expander('Tôi muốn rà soát hồ sơ vay',expanded=True):
        st.write('Mở Rà soát hồ sơ, chọn hồ sơ mẫu hoặc tải PDF/CSV. Chạy Gemini khi đã lưu kết nối và đồng ý gửi dữ liệu. Đối chiếu nguồn trước khi xác nhận; xác minh thu nhập rồi mới tính chỉ số.')
        st.button('Đến bước Hồ sơ',on_click=go,args=('1 · Hồ sơ',),key='guide_credit')
    with st.expander('Tôi muốn bảo vệ file Excel'):
        st.write('Mở Bảo mật Excel, chọn file từ máy hoặc data_raw.xlsx trên GitHub. Bấm xử lý rồi tải kết quả. Đây là giả danh hóa, không phải toàn bộ Excel được khóa bằng mật khẩu.')
        st.button('Đến Bảo mật Excel',on_click=go,args=('Bảo mật Excel',),key='guide_excel')
    with st.expander('Tôi muốn dùng API key riêng'):
        st.write('Bấm Gemini trên thanh đầu trang. Chọn API key của tôi, nhập key và model rồi Lưu kết nối. Không gửi key trong chat. Chỉ lưu cấu hình chưa chứng minh key có quyền gọi model; cần thử tác vụ.')
    with st.expander('Tôi muốn giữ kết quả sau khi đóng web'):
        st.write('Tải PDF/ZIP trong bước Báo cáo. Giữ file .ccenc và mật khẩu riêng nếu cần nhập lại tài liệu mã hóa. Dữ liệu và mã giả danh theo phiên có thể bắt đầu lại khi tải lại web.')

def footer():
    st.markdown('<div class="cc-footer"><span><strong>CreditCheck</strong> · Project 01</span><span>Dữ liệu giả lập phục vụ học tập · Không tự duyệt vay · v0.10</span></div>',unsafe_allow_html=True)

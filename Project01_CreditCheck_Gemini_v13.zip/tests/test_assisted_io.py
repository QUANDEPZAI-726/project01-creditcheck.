from ui_test_tools import navigate
import sys,copy,json,io,zipfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'app'))
from sample_data import load_sample
from phase2 import review_extraction_phase2,import_classification,verify_income,set_rate
from phase3 import import_summary,report_text
from traceability import sync
from assisted_io import read_result,rule_draft
from pdf_report import pdf_bytes
from pypdf import PdfReader
from streamlit.testing.v1 import AppTest
class AssistedTests(unittest.TestCase):
 def reviewed(self,cid):
  s=load_sample(cid);review_extraction_phase2(s,{'expected_version':s['version'],'checked':True,'reviewer':'TEST','reason':'Test source transcription'});sync(s)
  import_classification(s,{'expected_version':s['version'],'attest':True,'model':'ChatGPT saved candidate','result':json.loads((ROOT/'incoming'/f'{cid}_classification.json').read_text())});sync(s);return s
 def verify(self,s):
  verify_income(s,{'expected_version':s['version'],'checked':True,'coverage_checked':True,'reviewer':'TEST','reason':'TEST fixture source review','coverage_start':'2026-07-01','coverage_end':'2026-09-30','acknowledge_gap':True});sync(s)
 def test_hs03_pdf_and_no_auto_review(self):
  s=self.reviewed('HS03');self.verify(s);self.assertEqual(s['phase2']['metrics']['income_gap_pct'],50)
  rule_draft(s,{});text='\n'.join(p.extract_text() for p in PdfReader(io.BytesIO(pdf_bytes(s))).pages)
  self.assertIn('quy tắc Python',text);self.assertIn('INCOME_MISMATCH',text);self.assertIsNone(s['phase3']['content_review'])
 def test_hs04_and_hs05_still_block_income(self):
  for cid in ('HS04','HS05'):
   s=self.reviewed(cid)
   with self.assertRaises(ValueError):self.verify(s)
   rule_draft(s,{});self.assertTrue(all(v is None for v in s['phase2']['metrics'].values()));self.assertTrue(pdf_bytes(s))
 def test_missing_source_report(self):
  s=load_sample('HS02');rule_draft(s,{});self.assertEqual(s['phase3']['report_status'],'Insufficient information');self.assertTrue(pdf_bytes(s))
 def test_wrong_case_source_stale_report_and_bad_imports(self):
  s=self.reviewed('HS03');self.verify(s);rule_draft(s,{});obj=copy.deepcopy(s['phase3']['summary']['result'])
  set_rate(s,{'expected_version':s['version'],'annual_nominal_rate':.2,'reviewer':'TEST','reason':'changed assumption'});sync(s)
  with self.assertRaises(ValueError):import_summary(s,{'expected_version':s['version'],'attest':True,'model':'TEST','result':obj})
  for data in (b'bad',b'PKbad',b'x'*(10*1024*1024+1)):
   with self.assertRaises(ValueError):read_result(data,'classification')
  for cid,sha in [('HS04',None),('HS03','wrong')]:
   obj=json.loads((ROOT/'incoming'/f'{cid}_classification.json').read_text())
   if sha:obj['source_sha256']=sha
   with self.assertRaises(ValueError):import_classification(s,{'expected_version':s['version'],'attest':True,'model':'TEST','result':obj})
 def test_zip_only_reads_candidate_not_reviews(self):
  s=self.reviewed('HS03');self.verify(s);rule_draft(s,{});buf=io.BytesIO()
  with zipfile.ZipFile(buf,'w') as z:z.writestr('review_and_log.json',json.dumps(s))
  obj=read_result(buf.getvalue(),'classification');fresh=self.reviewed('HS03')
  import_classification(fresh,{'expected_version':fresh['version'],'attest':True,'model':'TEST','result':obj});sync(fresh);self.assertIsNone(fresh['phase2']['income_review'])
 def test_ui_rule_pdf_without_api(self):
  at=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
  navigate(at,'Tổng quan')
  next(x for x in at.selectbox if x.label=='Chọn hồ sơ để tiếp tục').select('HS03').run()
  next(b for b in at.button if b.label=='Mở hồ sơ đã chọn').click().run()
  navigate(at,'4 · Báo cáo')
  next(b for b in at.button if b.label=='Tạo bản nháp quy tắc · không dùng API').click().run()
  self.assertFalse(at.exception);self.assertEqual(at.session_state['dossier']['phase3']['summary']['mode'],'RULE_BASED');self.assertIsNone(at.session_state['dossier']['phase3']['content_review'])

 def test_rule_zip_cannot_be_relabelled_as_llm(self):
  s=load_sample('HS03');rule_draft(s,{});buf=io.BytesIO()
  with zipfile.ZipFile(buf,'w') as z:z.writestr('review_and_log.json',json.dumps(s))
  with self.assertRaises(ValueError):read_result(buf.getvalue(),'summary')
 def test_ui_saved_candidate_requires_and_preserves_review(self):
  at=AppTest.from_file(str(ROOT/'streamlit_app.py')).run(timeout=30)
  navigate(at,'Tổng quan')
  next(x for x in at.selectbox if x.label=='Chọn hồ sơ để tiếp tục').select('HS03').run()
  next(b for b in at.button if b.label=='Mở hồ sơ đã chọn').click().run()
  navigate(at,'2 · Kiểm tra')
  self.assertFalse(any(b.label=='Nạp ứng viên ChatGPT đã lưu · HS03' for b in at.button))
  next(x for x in at.text_input if x.label=='Người kiểm tra').input('TEST')
  next(x for x in at.text_area if x.label=='Ghi chú đối chiếu nguồn').input('Test source transcription')
  next(x for x in at.checkbox if x.label=='Tôi đã đối chiếu các trường với tài liệu nguồn.').check()
  next(b for b in at.button if b.label=='Xác nhận phần trích xuất').click().run()
  next(b for b in at.button if b.label=='Nạp ứng viên ChatGPT đã lưu · HS03').click().run()
  self.assertFalse(at.exception);self.assertEqual(len(at.session_state['dossier']['phase2']['classification']['rows']),9)
  self.assertIsNone(at.session_state['dossier']['phase2']['income_review'])

import unittest
from pathlib import Path
from streamlit.testing.v1 import AppTest
APP=Path(__file__).resolve().parents[1]/'streamlit_app.py'

class ShellUITests(unittest.TestCase):
    def fresh(self):
        at=AppTest.from_file(str(APP)).run(timeout=30)
        self.assertFalse(at.exception,[e.message for e in at.exception])
        return at

    def test_public_landing_has_start_and_no_dossier_metrics(self):
        at=self.fresh()
        self.assertEqual(at.session_state['page'],'Trang chủ')
        self.assertEqual(at.radio[0].options,['Trang chủ','Rà soát hồ sơ','Bảo mật Excel','Trợ lý','Hướng dẫn'])
        self.assertEqual(len(at.metric),0)
        self.assertTrue(any(b.label=='Bắt đầu rà soát' for b in at.button))
        self.assertTrue(any(b.label=='Dùng thử hồ sơ mẫu' for b in at.button))

    def test_cta_navigation_and_return_preserve_work_and_key(self):
        at=self.fresh()
        original=at.session_state['dossier']['case']['case_id']
        next(b for b in at.button if b.label=='Bắt đầu rà soát').click().run(timeout=30)
        self.assertFalse(at.exception);self.assertEqual(at.session_state['page'],'1 · Hồ sơ')
        next(b for b in at.button if b.label=='03 · Phân tích').click().run(timeout=30)
        self.assertEqual(at.session_state['page'],'3 · Phân tích')
        at.radio[0].set_value('Trang chủ').run(timeout=30)
        self.assertEqual(at.session_state['page'],'Trang chủ')
        at.radio[0].set_value('Rà soát hồ sơ').run(timeout=30)
        self.assertEqual(at.session_state['page'],'3 · Phân tích')
        self.assertEqual(at.session_state['dossier']['case']['case_id'],original)
        next(b for b in at.button if b.label=='CreditCheck').click().run(timeout=30)
        self.assertEqual(at.session_state['page'],'Trang chủ')

    def test_excel_and_guide_links_work_without_key(self):
        at=self.fresh()
        next(b for b in at.button if b.label=='Xử lý file Excel →').click().run(timeout=30)
        self.assertFalse(at.exception);self.assertEqual(at.session_state['page'],'Bảo mật Excel')
        self.assertTrue(any(b.label=='Xử lý bảo mật Excel' for b in at.button))
        at.radio[0].set_value('Hướng dẫn').run(timeout=30)
        self.assertFalse(at.exception);self.assertEqual(at.session_state['page'],'Hướng dẫn')
        next(b for b in at.button if b.label=='Đến bước Hồ sơ').click().run(timeout=30)
        self.assertEqual(at.session_state['page'],'1 · Hồ sơ')

    def test_connection_survives_navigation(self):
        at=self.fresh()
        next(x for x in at.text_input if x.label=='API key Gemini của bạn').set_value('fake-session-key')
        next(b for b in at.button if b.label=='Lưu kết nối').click().run(timeout=30)
        encrypted=at.session_state['_personal_key']
        for section in ['Rà soát hồ sơ','Bảo mật Excel','Trợ lý','Hướng dẫn','Trang chủ']:
            at.radio[0].set_value(section).run(timeout=30)
            self.assertFalse(at.exception,[e.message for e in at.exception])
            self.assertEqual(at.session_state['_personal_key'],encrypted)
        self.assertEqual(at.session_state['_api_key_input'],'')

if __name__=='__main__':unittest.main()

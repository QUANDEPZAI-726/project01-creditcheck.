def navigate(app,page,timeout=30):
    app.session_state['page']=page
    return app.run(timeout=timeout)

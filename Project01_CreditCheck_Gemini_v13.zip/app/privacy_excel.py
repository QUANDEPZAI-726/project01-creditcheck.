"""In-memory Excel pseudonymization. No identifiers or keys written to disk."""
import copy
import hashlib
import hmac
import io
import json
import math
import re
import unicodedata
import zipfile
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill

FINANCIAL = [
    'Doanh thu thuần', 'Phải thu khách hàng', 'Giá vốn hàng bán',
    'Tài sản ngắn hạn', 'Tài sản cố định hữu hình thuần', 'Tổng tài sản',
    'Chi phí khấu hao và phân bổ', 'Chi phí bán hàng và quản lý doanh nghiệp',
    'Nợ ngắn hạn', 'Nợ dài hạn',
    'Lợi nhuận sau thuế từ hoạt động liên tục',
    'Lưu chuyển tiền thuần từ hoạt động kinh doanh',
]
RULES = {
    'Năm':'KEEP', 'Mã hồ sơ':'HASH', 'Tên người phụ trách hồ sơ':'STAFF',
    'Tên doanh nghiệp':'COMPANY', 'Mã chứng khoán':'COMPANY',
    'Ngành':'DROP', 'Địa chỉ':'DROP', 'Người đại diện':'DROP',
    **{name:'KEEP' for name in FINANCIAL},
}

def rule_rows():
    labels={'KEEP':'Giữ nguyên','HASH':'HMAC có khóa','STAFF':'Giả danh STAFF_001…',
            'COMPANY':'Giả danh doanh nghiệp cố định','DROP':'Loại bỏ'}
    return [{'Trường dữ liệu':name,'Kỹ thuật':labels[rule],
             'Kết quả':'Giá trị gốc' if rule=='KEEP' else 'Không xuất cột' if rule=='DROP' else 'Mã giả danh'}
            for name,rule in RULES.items()]

def protect_excel(data, key, staff_map=None):
    if not isinstance(data,bytes) or not data or len(data)>10*1024*1024:
        raise ValueError('Chọn file Excel .xlsx, tối đa 10 MB.')
    if not isinstance(key,bytes) or len(key)!=32:
        raise ValueError('Không có khóa giả danh hợp lệ cho phiên này.')
    # Reject excessive decompression before passing the package to openpyxl.
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as package:
            entries=package.infolist()
            if len(entries)>1000 or sum(e.file_size for e in entries)>80*1024*1024:
                raise ValueError('Nội dung Excel giải nén quá lớn.')
            if any('vbaproject' in e.filename.lower() for e in entries):
                raise ValueError('Không xử lý file có macro.')
        book=load_workbook(io.BytesIO(data),read_only=True,data_only=False,keep_links=False)
    except ValueError:
        raise
    except Exception:
        raise ValueError('Không đọc được Excel .xlsx. Kiểm tra file và thử lại.') from None
    try:
        if len(book.worksheets)!=1:
            raise ValueError('File cần một sheet dữ liệu; chưa có rule cho các sheet khác.')
        sheet=book.active
        if sheet.max_row is None or sheet.max_column is None or sheet.max_row>5001 or sheet.max_column>20:
            raise ValueError('Tối đa 5.000 dòng và đúng 20 cột theo bảng quy tắc.')
        records=list(sheet.iter_rows(values_only=True))
        if len(records)<2:
            raise ValueError('File chưa có dòng dữ liệu.')
        headers,rows=list(records[0]),records[1:]
        if len(headers)!=20 or len(set(headers))!=20 or set(headers)!=set(RULES):
            raise ValueError('Cột Excel chưa khớp bảng quy tắc 20 trường. Không tự bỏ/giữ cột lạ.')
        pos={name:i for i,name in enumerate(headers)}
        companies,names,pairs={},{},set()
        for row in rows:
            if any(isinstance(v,str) and v.startswith('=') for v in row):
                raise ValueError('Excel chứa công thức; cần đối chiếu trước khi tạo bản chia sẻ.')
            for name in ('Mã hồ sơ','Tên người phụ trách hồ sơ','Tên doanh nghiệp','Mã chứng khoán'):
                value=row[pos[name]]
                if not isinstance(value,str) or not value.strip():
                    raise ValueError('Định danh trống hoặc sai kiểu. Cần đối chiếu nguồn.')
            year=row[pos['Năm']]
            if not isinstance(year,int) or isinstance(year,bool):
                raise ValueError('Năm phải là số nguyên.')
            for name in FINANCIAL:
                value=row[pos[name]]
                if value is not None and (isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value)):
                    raise ValueError('Trường tài chính phải là số hoặc ô trống; không tự chuyển hay thay số.')
            code=unicodedata.normalize('NFC',row[pos['Mã chứng khoán']]).strip().upper()
            name=unicodedata.normalize('NFC',row[pos['Tên doanh nghiệp']]).strip()
            if code in companies and companies[code]!=name or name in names and names[name]!=code:
                raise ValueError('Tên và mã doanh nghiệp chưa nhất quán. Chốt mã liên kết trước.')
            companies[code],names[name]=name,code
            if (code,year) in pairs:
                raise ValueError('Trùng doanh nghiệp–năm. Không tự gộp hoặc xóa dòng.')
            pairs.add((code,year))
    finally:
        book.close()
    mapping=copy.deepcopy({} if staff_map is None else staff_map)
    if (not isinstance(mapping,dict) or any(not isinstance(k,str) or not re.fullmatch(r'[0-9a-f]{64}',k)
        or not isinstance(v,str) or not re.fullmatch(r'STAFF_[0-9]{3,}',v) for k,v in mapping.items())
        or len(set(mapping.values()))!=len(mapping)):
        raise ValueError('Bảng giả danh nhân viên không hợp lệ.')
    def digest(domain,value):
        payload=json.dumps([domain,value],ensure_ascii=False).encode()
        return hmac.new(key,payload,hashlib.sha256).hexdigest()
    tokens={code:'COMP_'+digest('company',code) for code in companies}
    if len(set(tokens.values()))!=len(tokens):
        raise ValueError('Trùng mã giả danh doanh nghiệp.')
    out_headers=[name for name in headers if RULES[name]!='DROP']
    out_rows=[]
    for row in rows:
        code=unicodedata.normalize('NFC',row[pos['Mã chứng khoán']]).strip().upper()
        safe=[]
        for name in out_headers:
            value,rule=row[pos[name]],RULES[name]
            if rule=='HASH':value='CASE_'+digest('case',value)
            elif rule=='COMPANY':value=tokens[code]
            elif rule=='STAFF':
                token=digest('staff',unicodedata.normalize('NFC',value).strip())
                if token not in mapping:
                    used=set(mapping.values());n=1
                    while f'STAFF_{n:03d}' in used:n+=1
                    mapping[token]=f'STAFF_{n:03d}'
                value=mapping[token]
            safe.append(value)
        out_rows.append(safe)
    for raw,safe in zip(rows,out_rows):
        if any(raw[pos[name]]!=safe[out_headers.index(name)] for name in ['Năm']+FINANCIAL):
            raise ValueError('Năm hoặc số liệu tài chính thay đổi; không tạo file.')
    output=Workbook();ws=output.active;ws.title='Du_lieu_an_toan'
    ws.append(out_headers)
    for row in out_rows:ws.append(row)
    ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
    for cell in ws[1]:
        cell.font=Font(bold=True,color='FFFFFF')
        cell.fill=PatternFill('solid',fgColor='173B50')
        cell.alignment=Alignment(wrap_text=True,vertical='center')
    ws.row_dimensions[1].height=65
    for i,name in enumerate(out_headers,1):
        ws.column_dimensions[ws.cell(1,i).column_letter].width=30 if name in FINANCIAL else 24
        for row_index in range(2,len(out_rows)+2):
            cell=ws.cell(row_index,i)
            if name in FINANCIAL:cell.number_format='#,##0.############'
    buffer=io.BytesIO();output.save(buffer);output.close()
    return {'data':buffer.getvalue(),'headers':out_headers,'rows':out_rows,'staff_map':mapping,
            'row_count':len(rows),'company_count':len(companies),'numeric_unchanged':True}

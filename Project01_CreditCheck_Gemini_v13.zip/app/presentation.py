"""Display-only presentation of the existing underwriting state."""
from phase2 import value

def money(v):
    return 'Chưa có' if v is None else f'{v:,.0f}'.replace(',', '.')+' đ'

def ratio(v):
    return 'Chưa có' if v is None else f'{v:.2f}'.replace('.', ',')+'%'

def checkpoints(s):
    return [all(d['available'] for d in s['case']['documents']),
            s['extraction_review']['status']=='Reviewed' and s['phase2']['income_review'] is not None,
            all(v is not None for v in s['phase2']['metrics'].values()),
            s['phase3']['content_review'] is not None]

def workflow(s):
    checks=checkpoints(s)
    return [{'Bước':name,'Trạng thái':'Đã hoàn thành' if done else 'Cần xử lý'}
            for name,done in zip(['01 · Hồ sơ','02 · Kiểm tra','03 · Phân tích','04 · Báo cáo'],checks)]

def next_action(s):
    if not checkpoints(s)[0]: return 'Bổ sung tài liệu còn thiếu ở bước Hồ sơ.'
    if s['extraction_review']['status']!='Reviewed': return 'Đối chiếu nguồn và xác nhận trích xuất ở bước Kiểm tra.'
    if s['phase2']['classification'] is None: return 'Phân loại giao dịch, rồi kiểm tra nguồn thu ở bước Kiểm tra.'
    if s['phase2']['income_review'] is None: return 'Giải quyết khoản chưa rõ và xác minh nguồn thu/kỳ sao kê.'
    if s['phase3']['summary'] is None: return 'Xem chỉ số, sau đó tạo bản nháp ở bước Báo cáo.'
    if s['phase3']['content_review'] is None: return 'Đọc báo cáo và xác nhận nội dung.'
    return 'Đã kiểm tra nội dung. Tải báo cáo để bàn giao; vẫn cần người thẩm định xem xét.'

def income_rows(s):
    rows=[]
    for role,label in [('application','Khai báo trên đơn'),('income_certificate','Giấy xác nhận')]:
        v=value(s,'net_monthly_income_vnd',role)
        if v is not None:rows.append({'Nguồn':label,'Thu nhập (đ)':v})
    v=s['phase2']['metrics']['validated_monthly_income_vnd']
    if v is not None: rows.append({'Nguồn':'Sao kê đã xác minh','Thu nhập (đ)':v})
    return rows

def debt_rows(s):
    m=s['phase2']['metrics']
    if any(m[k] is None for k in ['validated_monthly_income_vnd','monthly_payment_vnd']):return []
    old=value(s,'existing_monthly_debt_vnd')
    if old is None:return []
    return [{'Khoản':'Nợ hiện tại','Số tiền (đ)':old},
            {'Khoản':'Trả góp mới','Số tiền (đ)':m['monthly_payment_vnd']},
            {'Khoản':'Còn lại sau trả nợ','Số tiền (đ)':m['validated_monthly_income_vnd']-old-m['monthly_payment_vnd']}]
